"""Actual source pages -> loopback synthetic auth transport -> disposable local PostgreSQL.
No real credentials, auth provider, SDK acceptance or production readiness asserted.
"""
import os,subprocess,json,uuid,tempfile,threading,re,time,urllib.request,base64
from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
import websocket
ROOT=Path(__file__).resolve().parents[1];DB=os.environ.get('BJ_BANK_LOCAL_DB','bj_bank_20261111')
if not DB.startswith('bj_bank_'):raise SystemExit('Disposable bj_bank_ database only')
def sql(q):
 r=subprocess.run(['psql','-X','-q','-v','ON_ERROR_STOP=1','-h','/tmp','-p','55432','-d',DB,'-At','-f','-'],input='set jit=off;\n'+q,capture_output=True,text=True)
 if r.returncode:raise ValueError(r.stderr)
 return r.stdout.strip().splitlines()[-1] if r.stdout.strip() else ''
def literal(v):
 if v is None:return 'null'
 if isinstance(v,(dict,list)):return "'"+json.dumps(v).replace("'","''")+"'::jsonb"
 if isinstance(v,bool):return str(v).lower()
 if isinstance(v,int):return str(v)
 return "'"+str(v).replace("'","''")+"'"
users={k:str(uuid.uuid4())for k in ['owner','reviewer','publisher','student']};cid=None;server=None
allowed={'bj_bank_dashboard':[],'bj_bank_staff':['p_class','p_user','p_role','p_revoke'],'bj_bank_accept':['p_grant','p_accept'],'bj_bank_draft':['p_class','p_item','p_expected','p_content'],'bj_bank_review':['p_item','p_revision','p_checks'],'bj_bank_publish':['p_item','p_revision','p_title'],'bj_dashboard':[],'bj_get_assignment':['p_id'],'bj_submit':['p_id','p_answers']}
def call(actor,name,args):
 if name not in allowed or set(args)!=set(allowed[name]):raise ValueError('RPC not allowed in local fixture')
 argsql=','.join(literal(args[k])for k in allowed[name]);u=users[actor]
 value=sql(f"begin;set local role authenticated;set local request.jwt.claim.sub='{u}';select to_json(public.{name}({argsql}));commit;")
 return json.loads(value)
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw):super().__init__(*a,directory=str(ROOT),**kw)
 def log_message(self,*a):pass
 def do_POST(self):
  try:
   data=json.loads(self.rfile.read(int(self.headers['Content-Length'])));result={'data':call(data['actor'],data['name'],data['args'])}
  except Exception as e:result={'error':{'message':str(e)}}
  raw=json.dumps(result).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(raw)
 def do_GET(self):
  if self.path.startswith('/__flow/'):
   _,_,actor,which=self.path.split('?',1)[0].split('/');assert actor in users;file='shared-bank.html' if which=='bank' else 'classroom.html'
   html=(ROOT/'platform/app'/file).read_text();html=re.sub(r'<script defer src="[^"]+"></script>',lambda m:m[0] if 'src="'+file.replace('.html','.js')+'"' in m[0] or 'src="question-bank-core.js"' in m[0] else '',html)
   mock=f"window.BRAINJOY_CONFIG={{enabled:true,sharedBankEnabled:true}};window.BRAINJOY_SHARED_BANK_CONFIG={{enabled:true}};const syntheticSession={{user:{{id:{json.dumps(users[actor])}}}}};window.supabase={{createClient:()=>({{auth:{{getSession:async()=>({{data:{{session:syntheticSession}}}}),onAuthStateChange:()=>{{}},signOut:async()=>({{}})}},rpc:async(name,args={{}})=>fetch('/__rpc',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{actor:{json.dumps(actor)},name,args}})}}).then(r=>r.json())}})}};"
   html=html.replace('<head>','<head><base href="/platform/app/"><script>'+mock+'</script>',1);raw=html.encode();self.send_response(200);self.send_header('Content-Type','text/html');self.end_headers();self.wfile.write(raw);return
  return super().do_GET()
try:
 sql('insert into auth.users(id)values'+','.join('('+literal(u)+')'for u in users.values()))
 cid=json.loads(sql(f"begin;set local role authenticated;set local request.jwt.claim.sub='{users['owner']}';select public.bj_create_class('Database-backed flow class');commit;"))['id']
 code=sql(f"select join_code from brainjoy.classes where id='{cid}'");sql(f"begin;set local role authenticated;set local request.jwt.claim.sub='{users['student']}';select public.bj_join_class('{code}');commit;")
 server=ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
 with tempfile.TemporaryDirectory(prefix='bj-db-flow-')as profile:
  proc=subprocess.Popen(['google-chrome','--headless','--no-sandbox','--disable-gpu','--disable-dev-shm-usage','--no-proxy-server','--remote-debugging-port=0','--remote-allow-origins=*','--user-data-dir='+profile],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  try:
   active=Path(profile)/'DevToolsActivePort'
   for _ in range(200):
    if active.exists():break
    time.sleep(.025)
   port=active.read_text().splitlines()[0];tab=json.load(urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:'+port+'/json/new?about:blank',method='PUT')));ws=websocket.create_connection(tab['webSocketDebuggerUrl']);seq=0
   def cmd(method,params={}):
    global seq;seq+=1;ws.send(json.dumps({'id':seq,'method':method,'params':params}))
    while True:
     result=json.loads(ws.recv())
     if result.get('id')==seq:return result.get('result',{})
   def js(s):
    r=cmd('Runtime.evaluate',{'expression':s,'returnByValue':True});
    if 'exceptionDetails'in r:raise ValueError(r['exceptionDetails'])
    return r.get('result',{}).get('value')
   def wait(s):
    for _ in range(250):
     if js(s):return
     time.sleep(.02)
    raise ValueError('Timeout '+s+' | '+str(js("document.querySelector('#notice')?.textContent")))
   def load(actor,page='bank'):
    cmd('Page.navigate',{'url':f'http://127.0.0.1:{server.server_port}/__flow/{actor}/{page}'});wait("document.readyState==='complete'&&!document.querySelector('#workspace').hidden")
   def click(text):js("[...document.querySelectorAll('button')].find(b=>b.textContent==="+json.dumps(text)+").click()")
   def confirm():wait("!!document.querySelector('dialog')");click('Confirm')
   load('owner','classroom');assert js("[...document.querySelectorAll('a')].some(a=>a.textContent==='Review and publish class questions'&&a.href.includes("+json.dumps(cid)+"))")
   load('owner');
   for actor,role in [('reviewer','reviewer'),('publisher','publisher')]:
    js("document.querySelector('#staffUser').value="+json.dumps(users[actor])+";document.querySelector('#staffRole').value="+json.dumps(role)+";document.querySelector('#staff').requestSubmit()");confirm();wait("document.querySelector('#grants').textContent.includes("+json.dumps(users[actor])+")")
   content=dict(prompt='What is 7 + 5?',choices=['10','12','14'],answer=1,explanation='Seven plus five is twelve.',topic='addition',prerequisites=[],audience='Early practice; check suitability',alignment='Not verified',origin='original',source='Original sample',rights='Original wording')
   js("document.querySelector('#content').value="+json.dumps(json.dumps(content))+";document.querySelector('#draft').requestSubmit()");confirm();wait("document.querySelector('#items').textContent.includes('What is 7 + 5?')")
   load('reviewer');click('Accept reviewer');confirm();wait("!![...document.querySelectorAll('button')].find(b=>b.textContent==='Review exact revision')");js("document.querySelectorAll('#items input[type=checkbox]').forEach(i=>i.checked=true)");click('Review exact revision');confirm();wait("document.querySelector('#items').textContent.includes('currently authorized')")
   load('publisher');click('Accept publisher');confirm();wait("!![...document.querySelectorAll('button')].find(b=>b.textContent==='Publish to this class')");click('Publish to this class');confirm();wait("document.querySelector('#items').textContent.includes('Frozen classroom assignment')")
   load('student','classroom');wait("document.querySelector('#studentAssignments').textContent.includes('What is 7 + 5?')");click('Open assignment');wait("!!document.querySelector('#answers input')");assert not js("document.querySelector('#answers').textContent.includes('Seven plus five')");print('Learner form',js("document.querySelector('#answers').innerText"));print('Inputs',js("[...document.querySelectorAll('#answers input')].map(i=>({type:i.type,value:i.value}))"));js("document.querySelector('#answers input[value=\"1\"]').click();document.querySelector('#answers').requestSubmit()");wait("document.querySelector('#answers').textContent.includes('1 / 1')||document.querySelector('#notice').textContent.includes('1 / 1')")
   cmd('Emulation.setDeviceMetricsOverride',{'width':390,'height':950,'deviceScaleFactor':1,'mobile':True});js("document.querySelector('#player').scrollIntoView({block:'start'})");time.sleep(.1);Path('/tmp/bj-aj-real-learner.png').write_bytes(base64.b64decode(cmd('Page.captureScreenshot',{'format':'png'})['data']))
   assert sql(f"select count(*)from brainjoy.attempts where student_id='{users['student']}' and score=1 and total=1")=='1'
   print('PASS actual owner classroom entry -> real SQL grant/draft -> independent reviewer acceptance/review -> publisher acceptance/publication -> existing learner assignment form -> real SQL immutable score1/1. Local auth transport, not hosted/provider acceptance.')
   ws.close()
  finally:proc.terminate();proc.wait()
finally:
 if server:server.shutdown();server.server_close()
 if cid:
  sql(f"delete from brainjoy.attempts where assignment_id in(select id from brainjoy.assignments where class_id='{cid}');delete from brainjoy.bank_publications where item_id in(select id from brainjoy.bank_items where class_id='{cid}');delete from brainjoy.bank_reviews where item_id in(select id from brainjoy.bank_items where class_id='{cid}');delete from brainjoy.bank_revisions where item_id in(select id from brainjoy.bank_items where class_id='{cid}');delete from brainjoy.bank_items where class_id='{cid}';delete from brainjoy.bank_staff where class_id='{cid}';delete from brainjoy.assignments where class_id='{cid}';delete from brainjoy.members where class_id='{cid}';delete from brainjoy.classes where id='{cid}';")
 sql('delete from auth.users where id in('+','.join(literal(u)for u in users.values())+')')
