> Current status, 2026-11-11 00:27 Asia/Dubai: migration005 is installed after exact-source hosted rollback tests. Independent synthetic teacher/learner browser sessions verified classroom publication and server 3/3, realtime game join/start/answer/reveal/next/finish for MCQ/true-false/short answer, hidden player keys/scores during questions, outsider game/signal/private-table isolation, and finished-game reconnect. A channel reuse issue found on actual resume was fixed with unique per-connection names and pagehide cleanup, then retested live. All synthetic fixtures, two Auth users, auth sessions, vault credentials and temporary preview harness removed; baseline3 existing users retained. Ordinary frontend enabled=false/liveEnabled=false. Main site/DNS/payment/signup settings unchanged. Historical source-only sections below describe earlier checkpoints, not current install status. Public release, owner pilot and role/onboarding work remain incomplete.

# BrainJoy platform security gates

Do not enable cloud mode until all gates pass on the existing database.

1. Inventory existing tables, policies, grants and auth settings read-only. Do not replace existing schemas or users.
2. Add new namespaced tables only after reviewing collisions and dependencies.
3. Teachers can read/write only their owned content. Changing a profile or selecting a UI role must never grant teacher/admin authority.
4. Students can see question text and options, never answer keys before submitting. Server-side grading owns scores. Repeated submissions must not duplicate points.
5. Teacher access to attempts requires ownership of the corresponding assignment/class. Parent access requires an explicit verified link, not guessing a student's email or ID.
6. New user profiles cannot set admin roles. Administrative access comes from a separately verified owner grant.
7. No service-role keys in browser code, Git history, previews or logs. Public/publishable keys do not bypass RLS.
8. All generated HTML uses escaped text or textContent. Validate question types, lengths and count on the server as well as client.
9. Test authorization with synthetic fixtures in a transaction that is rolled back. No real-student signups, private record mutation or payment tests.
10. Publish no multiuser claims until two independent authenticated sessions and unauthorized-access negative tests pass.

Money and safety: no payment activation, seller commitments, subscription upgrades or AI quota calls without source-grounded authority. All learning resources must be original or properly licensed. Do not claim NWEA/MAP-equivalent validation or guaranteed learning growth.

## Existing database inventory, Nov 10 2026
- Project restored from paused Free state, data retained.
- Public tables: lesson_plans, profiles, quizzes, arenas, players, all with RLS.
- quizzes: id UUID PK, title/subject/difficulty text, questions JSONB, created_by UUID FK to auth.users(id), created_at timestamptz. Exactly 0 quiz rows at preflight.
- profiles: id UUID, email/full_name/avatar_url/role text, created_at timestamptz. Exactly 0 profile rows; 3 auth users, no private row data read.
- Original quiz policy: all actions to PUBLIC where auth.role()='authenticated', no ownership. Narrowed live to authenticated creator only (001).
- Profiles owner ALL policy checks auth.uid()=id; role column is user-editable. Never trust it for administrative authorization.
- Other 3 public tables have no policies, so RLS should deny normal API access despite broad default grants. Confirm actual API behavior before enabling features.

## Installed classroom milestone, 22:34 Dubai
Migration002 applied after exact-source MD5 verification, schema dry-run and live rollback-only synthetic authorization tests. Eight private RLS tables and checked RPC functions. Direct client table access revoked; anonymous dashboard RPC denied. Parent requests need specific student approval, single-use/expiring codes, rejection/removal. No real-student fixtures retained. Migration003 removed only client TRUNCATE grants, preserving ordinary CRUD and records.

Frontend remains disabled. Independent authenticated teacher/learner session tests passed on synthetic fixtures, then fixtures were removed. Adult pilot and public minor onboarding/consent remain release gates. See QA-20261110.md. Local UI mocks are not authenticated-session evidence. Owner email source evidence recovered from authenticated WhatsApp Nov3 07:35. Fresh unique confirmed match verified and migration004 applied to that owner only; read-back admins=1, verified_owner_admins=1. No profile role is trusted. Existing profile.role is never trusted. Static preview does not enable payment, signup or cloud classrooms.

Source-only migration staging brainjoy_build was verified against both original source-bundle hashes and removed with RESTRICT, not CASCADE, after install.

## Source-only live games
Migration005 is local-tested only, not live-installed. Uses three private RLS tables, checked authenticated RPCs and a public ID/revision-only signal table guarded by membership/host and expiry RLS. Answer keys and player scoreboard are absent during active questions. Server clock, row locks and unique constraints own deadlines/first submission. No speed bonuses or classroom-grade mutation. Realtime publication must exist or migration rolls back. Emergency disable revokes RPC/signal access and unpublishes signals while retaining data. Requires verified network delivery, reconnect behavior, abuse controls and ordinary account/minor release gates before public use.
