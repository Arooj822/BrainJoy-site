> Current status, 2026-11-11 00:27 Asia/Dubai: migration005 is installed after exact-source hosted rollback tests. Independent synthetic teacher/learner browser sessions verified classroom publication and server 3/3, realtime game join/start/answer/reveal/next/finish for MCQ/true-false/short answer, hidden player keys/scores during questions, outsider game/signal/private-table isolation, and finished-game reconnect. A channel reuse issue found on actual resume was fixed with unique per-connection names and pagehide cleanup, then retested live. All synthetic fixtures, two Auth users, auth sessions, vault credentials and temporary preview harness removed; baseline3 existing users retained. Ordinary frontend enabled=false/liveEnabled=false. Main site/DNS/payment/signup settings unchanged. Historical source-only sections below describe earlier checkpoints, not current install status. Public release, owner pilot and role/onboarding work remain incomplete.

# Preserved feature inventory

Development checklist, not a release claim. Existing feature labels remain. Adjacent copy identifies the available manual/shared-screen version where AI or network functionality is still planned.

| Entry | Action | Open work |
| --- | --- | --- |
| Study Guides | `location.href='resources/atomic-structure-sample.html'` | Integration/release QA; planned AI/network features remain unfinished |
| BrainJoy AI Tutor | `requireAuthAction()` | Full feature not implemented |
| Flashcards | `location.href='flashcards.html'` | Integration/release QA; planned AI/network features remain unfinished |
| Games & Quizzes | `practice.html` | Self-paced samples ready for preview; real multi-device play remains unfinished |
| AI Lesson Planner | `location.href='lesson-planner.html'` | Integration/release QA; planned AI/network features remain unfinished |
| Live Review Game | `location.href='review-game.html'` | Integration/release QA; planned AI/network features remain unfinished |
| Quiz Builder AI | `location.href='quiz-builder.html'` | Integration/release QA; planned AI/network features remain unfinished |
| Classroom Dashboard | `platform/app/classroom.html?view=teacher` | Private class/publish/assignment management tested; ordinary access still gated |
| Student Analytics | `platform/app/classroom.html?view=teacher#insightsTitle` | Descriptive authorized-score summary, not mastery or engagement tracking |
| BrainBlast Mode | `location.href='review-game.html'` | Integration/release QA; planned AI/network features remain unfinished |
| Progress Reports | `platform/app/classroom.html?view=parent` | Specific-request approval/revocation and authorized submitted scores, no automatic weekly report |
| Curriculum Guide | `requireAuthAction()` | Full feature not implemented |
| Reward System | `requireAuthAction()` | Full feature not implemented |
| Screen Time Limits | `requireAuthAction()` | Full feature not implemented |

Release gates: adult owner pilot; minor onboarding/consent; true multi-device live game; adaptive/AI service and quota control; approved paid packs/licences/refunds/merchant setup; parent rewards/time-limit enforcement; district admin imports and reports.

Backend owner-only admin membership is mapped. No new signup or production classroom access has been enabled.

Additional completed preview work: searchable original/same-browser practice library; exact-arithmetic six-question number-sense sample; duplicate-grade guard and expected-answer review; read-only classroom visible-result averages with sign-out purge. AI, adaptive assessment, verified guardian onboarding, rewards enforcement, true device/screen-time controls, district imports and live multi-device games remain unfinished.

Additional preview workflow: raw quiz-storage backup and read-only legacy recovery (no reset), plus worksheet studio with separately printed teacher key. These do not open student accounts, payments, AI or true multi-device gameplay.

Live-game source-only milestone: host private lobby from owned assignment, nickname join, server countdown/immutable responses and reveal/score progression, ID/revision realtime refresh, no polling. Local SQL/concurrency and browser mock tests pass. Not installed or deployed; public signup remains closed. This is distinct from the working shared-screen review.

Original resource mini-unit: Particle detectives (atoms, ions, isotopes), 12 questions, separate two-page student PDF and two-page teacher guide/key, 45-minute outline, downloadable PDF/JSON bundle. Free classroom/home sample, not a paid offer. Linked to worksheet studio, flashcards, shared-screen review and browser-only practice. All original resource-plan cards/buttons retained. General practice, no exam-board alignment or validated-assessment claim.

## Role integration, 2026-11-11
Homepage role sidebar dashboards now point to the matching classroom view, teacher assignment tracker/classrooms/analytics point to their actual gated workspace, and practice/builder/review entries point to working account-free tools. Original cards and labels remain. AI tutor, curriculum map, rewards, device screen-time enforcement, imports, staff permissions and engagement metrics now show exact unavailability with a relevant working tool, not a misleading signup prompt. This is useful routing, not completion of those features.

Classroom has separate teacher-owned assignment management and student joined-class assignments; read-only question preview for teachers (including closed assignments), confirmed close/reopen with existing scores retained, and explicit refresh. Requested student/teacher/parent view survives actual sign-in; Admin query or hidden-tab click cannot grant an admin view without the server flag. View changes remain presentation, not permission. Nearby builder/worksheet/practice/review links are available while accounts are closed. New source workflow is local-synthetic tested and visually checked; no additional backend or account changes. Sixteen local browser suites plus units pass.
