> Current status, 2026-11-11 00:27 Asia/Dubai: migration005 is installed after exact-source hosted rollback tests. Independent synthetic teacher/learner browser sessions verified classroom publication and server 3/3, realtime game join/start/answer/reveal/next/finish for MCQ/true-false/short answer, hidden player keys/scores during questions, outsider game/signal/private-table isolation, and finished-game reconnect. A channel reuse issue found on actual resume was fixed with unique per-connection names and pagehide cleanup, then retested live. All synthetic fixtures, two Auth users, auth sessions, vault credentials and temporary preview harness removed; baseline3 existing users retained. Ordinary frontend enabled=false/liveEnabled=false. Main site/DNS/payment/signup settings unchanged. Historical source-only sections below describe earlier checkpoints, not current install status. Public release, owner pilot and role/onboarding work remain incomplete.

# Preserved feature inventory

Development checklist, not a release claim. Existing feature labels remain. Adjacent copy identifies the available manual/shared-screen version where AI or network functionality is still planned.

| Entry | Action | Open work |
| --- | --- | --- |
| Study Guides | `location.href='resources/atomic-structure-sample.html'` | Integration/release QA; planned AI/network features remain unfinished |
| BrainJoy AI Tutor | `requireAuthAction()` | Full feature not implemented |
| Flashcards | `location.href='flashcards.html'` | Integration/release QA; planned AI/network features remain unfinished |
| Games & Quizzes | `practice.html` | Self-paced samples ready; hosted private multi-device core verified, ordinary access still gated |
| AI Lesson Planner | `location.href='lesson-planner.html'` | Integration/release QA; planned AI/network features remain unfinished |
| Live Review Game | `location.href='review-game.html'` | Integration/release QA; planned AI/network features remain unfinished |
| Quiz Builder AI | `location.href='quiz-builder.html'` | Integration/release QA; planned AI/network features remain unfinished |
| Classroom Dashboard | `platform/app/classroom.html?view=teacher` | Private class/publish/assignment management tested; ordinary access still gated |
| Student Analytics | `platform/app/classroom.html?view=teacher#insightsTitle` | Descriptive authorized-score summary, not mastery or engagement tracking |
| BrainBlast Mode | `location.href='review-game.html'` | Integration/release QA; planned AI/network features remain unfinished |
| Progress Reports | `platform/app/classroom.html?view=parent` | Specific-request approval/revocation and authorized submitted scores, no automatic weekly report |
| Curriculum Guide | `requireAuthAction()` | Full feature not implemented |
| Reward System | `requireAuthAction()` | Full feature not implemented |
| Screen Time Limits | `requireAuthAction()` | Full feature not implemented |

Release gates: adult owner pilot; minor onboarding/consent; true multi-device live game; adaptive/AI service and quota control; approved paid packs/licences/refunds/merchant setup; parent rewards/time-limit enforcement; district admin imports and reports.

Backend owner-only admin membership is mapped. No new signup or production classroom access has been enabled.

Additional completed preview work: searchable original/same-browser practice library; exact-arithmetic six-question number-sense sample; duplicate-grade guard and expected-answer review; read-only classroom visible-result averages with sign-out purge. AI, adaptive assessment, verified guardian onboarding, rewards enforcement, true device/screen-time controls, district imports and live multi-device games remain unfinished.

Additional preview workflow: raw quiz-storage backup and read-only legacy recovery (no reset), plus worksheet studio with separately printed teacher key. These do not open student accounts, payments, AI or true multi-device gameplay.

Live-game source-only milestone: host private lobby from owned assignment, nickname join, server countdown/immutable responses and reveal/score progression, ID/revision realtime refresh, no polling. Local SQL/concurrency and browser mock tests pass. Not installed or deployed; public signup remains closed. This is distinct from the working shared-screen review.

Original resource mini-unit: Particle detectives (atoms, ions, isotopes), 12 questions, separate two-page student PDF and two-page teacher guide/key, 45-minute outline, downloadable PDF/JSON bundle. Free classroom/home sample, not a paid offer. Linked to worksheet studio, flashcards, shared-screen review and browser-only practice. All original resource-plan cards/buttons retained. General practice, no exam-board alignment or validated-assessment claim.

## Role integration, 2026-11-11
Homepage role sidebar dashboards now point to the matching classroom view, teacher assignment tracker/classrooms/analytics point to their actual gated workspace, and practice/builder/review entries point to working account-free tools. Original cards and labels remain. AI tutor, curriculum map, rewards, device screen-time enforcement, imports, staff permissions and engagement metrics now show exact unavailability with a relevant working tool, not a misleading signup prompt. This is useful routing, not completion of those features.

Classroom has separate teacher-owned assignment management and student joined-class assignments; read-only question preview for teachers (including closed assignments), confirmed close/reopen with existing scores retained, and explicit refresh. Requested student/teacher/parent view survives actual sign-in; Admin query or hidden-tab click cannot grant an admin view without the server flag. View changes remain presentation, not permission. Nearby builder/worksheet/practice/review links are available while accounts are closed. New source workflow is local-synthetic tested and visually checked; no additional backend or account changes. Sixteen local browser suites plus units pass.

## Tool search and honest commercial gates, 2026-11-11 00:41 Dubai
The existing homepage search now opens a local public-tool finder with intersected search terms, clear empty state and real routes to tools, labs, resources and gated role dashboards. Mobile sidebar has the same finder. Search sends nothing and does not index private account records. Inputs and result strings use textContent and fixed internal links. Native modal focus/escape and always-reachable sticky close control; desktop/mobile pixels inspected. Hamburger, role selector and modal close controls gained accessible labels. Sixteen browser suites plus units cover safe/no-result/multi-term search and existing-role routing.

Original pricing plans/cards/buttons remain, now clearly labeled inactive development content. Upgrade/contact-sales/donation actions show no-charge/no-subscription status with free resources, not a misleading sign-in prompt or placeholder Stripe checkout. No merchant or payment setting changed. These gates do not implement payments.

## Classroom-to-live route integration, 2026-11-11 00:49 Dubai
When both existing feature flags are explicitly enabled for an approved pilot, teacher-owned assignments link to a game setup page with that assignment selected. A route hint is accepted only when the current account's server dashboard already lists it as owned; invalid/unowned hints cause no lookup or game creation. Student view has a private-code join route; the game has a classroom return link. Navigation never creates a game or joins a player automatically. Existing closed flags hide both classroom routes and keep the standalone game from making any service call. No flags/backend/settings changed. Local synthetic routing and existing17 suites/units pass. Teacher and mobile host-setup pixels inspected. New route itself is not independently hosted-session tested yet.

## Parent-role progress integration, 2026-11-11 01:10 Dubai
Parent view now limits results and CSV to server-approved linked students, with per-student cards/filter and a descriptive quiz-percentage summary. Student view shows own submissions; Teacher view shows owned-class submissions. CSV refreshes access before building a file and stops when a selected revoked child would change the scope. Exact-parent access removal requires confirmation. Refresh purges revoked links/filter state; signout purges private scope. Shared scores do not prove guardianship, curriculum mastery or verified minor consent. No automated emails, student answers, join codes or device data are shared.

Eighteen local browser suites plus quiz units pass; parent desktop/mobile pixels inspected. The expanded rollback-only authorization matrix passes a disposable local PostgreSQL database. Hosted preflight confirmed all8 related function bodies match archived migration hashes. Hosted behavioral matrix NOT executed: editor text input repeatedly timed out/truncated; exact verification prevented Run. No synthetic hosted rows, credentials or changes were created in this attempt. Prior installed002 authorization evidence remains distinct. Both ordinary flags stay false; owner pilot and guardian onboarding remain release gates.

01:12 correction before r publication: responsive submitted-results table preserves header/date readability using a740px minimum table in its own keyboard-focusable horizontal scroll region, no-wrap headers/date cells, swipe/arrow hint. Actual390CSS-pixel captures inspected at both scroll edges; page scrollWidth390, table740, scroll region320. Full dates/times and Assignment/Submitted headers readable. Previous basic headless capture layout viewport was larger than its image width; replaced with explicit viewport evidence.18suites/units pass including table overflow and no-wrap checks.

## Teacher filters and scoped progress, 2026-11-11 01:22 Dubai
Teacher assignment management has owned-class/open/closed/title filters with safe empty state and a View submitted scores action. Matching assignments also scope teacher result summaries, per-assignment selection and CSV. Refresh preserves valid class/result/publish selections; removed/changed selected scope stops export for review. Signout clears filters/private counts. No roster or enrollment data is inferred from submissions. Filters are local views of the already-authorized dashboard and do not mutate assignments. Fixed export button finally-state so zero-result exports stay disabled.

19local browser suites plus quiz units pass, including owned-only filtering, combined filters, safe/empty title input, CSV scope, refresh selection, stale scope export abort and signout purge. Actual1200/390CSS-pixel teacher views inspected; mobile page width390, table region320, table740 with readable horizontal scrolling. No hosted backend, account, signup, AI/payment or main-site changes. These new filters are synthetic-local tested, not independently hosted-session reverified.

## Student saved-score and assignment race safeguards, 2026-11-11 01:25 Dubai
Student assignment cards distinguish submitted scores from ready/closed work. View saved score refreshes authorized dashboard state, shows the immutable first score and does not fetch earlier answers/questions or resubmit. Async assignment opens are request-scoped: an older response cannot replace a newer assignment or reopen a closed player. A submission completing after another assignment is opened remains saved but cannot overwrite the newer form, and a notice explains its result is available. Signout/account changes invalidate pending player state.20local suites plus units pass, including out-of-order reads, close-during-load, submit-after-new-open and saved-score no-extra-access checks. Actual390CSS-pixel saved-score screen inspected. No backend/schema/account/AI/payment or release-flag change. Hosted-session revalidation of these new UI paths remains pending.

## Owner-only membership read path, SOURCE ONLY, 2026-11-11 01:34 Dubai
Migration006 adds a checked owner-only bj_class_roster(uuid) read function returning member account IDs, join timestamps and submitted assignment IDs within that class. No names/emails/answers/parent links/scores or other classes. Nonowners, member students, approved parents, missing identity and anonymous callers denied in disposable local rollback tests. No global role grants or existing records changed. Emergency disable revokes function execution, retaining data/source. NOT hosted-installed or independent-session verified.

Frontend rosterEnabled=false readiness flag independent of existing false classroom/live flags. Only explicitly enabled owned-class buttons request the roster. Role switch/refresh/signout invalidate and purge it; stale pending responses ignored.21local browser suites plus quiz units pass. Actual390CSS-pixel membership/submission view inspected with escaped adversarial synthetic account label. No enrollment/legal-identity/mastery claim. This is preparatory source, not a finished hosted roster or release approval.
