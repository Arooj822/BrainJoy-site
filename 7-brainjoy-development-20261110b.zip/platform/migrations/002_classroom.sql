-- Additive classroom backend. No changes to legacy tables or users.
-- Preflight must prove schema/function names unused before live application.
begin;
create schema brainjoy;
revoke all on schema brainjoy from public, anon, authenticated;
create table brainjoy.classes(id uuid primary key default gen_random_uuid(), owner_id uuid not null references auth.users(id), title text not null check(length(title) between 1 and 160), join_code text unique not null default replace(gen_random_uuid()::text,'-',''), created_at timestamptz not null default now());
create table brainjoy.members(class_id uuid references brainjoy.classes(id), student_id uuid references auth.users(id), joined_at timestamptz not null default now(), primary key(class_id,student_id));
create table brainjoy.assignments(id uuid primary key default gen_random_uuid(), class_id uuid not null references brainjoy.classes(id), title text not null, questions jsonb not null, created_at timestamptz not null default now(), closed boolean not null default false);
create table brainjoy.attempts(assignment_id uuid references brainjoy.assignments(id), student_id uuid references auth.users(id), answers jsonb not null, score integer not null, total integer not null, submitted_at timestamptz not null default now(), primary key(assignment_id,student_id));
create table brainjoy.parent_codes(student_id uuid primary key references auth.users(id), code text unique not null default replace(gen_random_uuid()::text,'-',''), expires_at timestamptz not null default now()+interval '24 hours');
create table brainjoy.parent_links(student_id uuid references auth.users(id),parent_id uuid references auth.users(id),primary key(student_id,parent_id),check(student_id<>parent_id));
create table brainjoy.parent_requests(student_id uuid references auth.users(id),parent_id uuid references auth.users(id),created_at timestamptz not null default now(),primary key(student_id,parent_id),check(student_id<>parent_id));
create table brainjoy.admins(user_id uuid primary key references auth.users(id));
-- Defense in depth: no direct API table access, even if exposed later.
alter table brainjoy.classes enable row level security;
alter table brainjoy.members enable row level security;
alter table brainjoy.assignments enable row level security;
alter table brainjoy.attempts enable row level security;
alter table brainjoy.parent_codes enable row level security;
alter table brainjoy.parent_links enable row level security;
alter table brainjoy.parent_requests enable row level security;
alter table brainjoy.admins enable row level security;
revoke all on all tables in schema brainjoy from public,anon,authenticated;

create function public.bj_create_class(p_title text) returns jsonb language plpgsql security definer set search_path=pg_catalog as $$
declare r brainjoy.classes; u uuid:=auth.uid();
begin
 if u is null then raise exception 'Sign in first'; end if;
 insert into brainjoy.classes(owner_id,title) values(u,trim(p_title)) returning * into r;
 return jsonb_build_object('id',r.id,'title',r.title,'join_code',r.join_code);
end $$;
create function public.bj_join_class(p_code text) returns jsonb language plpgsql security definer set search_path=pg_catalog as $$
declare c brainjoy.classes; u uuid:=auth.uid();
begin
 if u is null then raise exception 'Sign in first'; end if;
 select * into c from brainjoy.classes where join_code=trim(p_code);
 if not found then raise exception 'Class code not found'; end if;
 if c.owner_id=u then raise exception 'You already own this class'; end if;
 insert into brainjoy.members(class_id,student_id) values(c.id,u) on conflict do nothing;
 return jsonb_build_object('id',c.id,'title',c.title);
end $$;
create function public.bj_publish(p_class uuid,p_title text,p_questions jsonb) returns uuid language plpgsql security definer set search_path=pg_catalog as $$
declare q jsonb; n integer; v uuid;
begin
 if auth.uid() is null or not exists(select 1 from brainjoy.classes where id=p_class and owner_id=auth.uid()) then raise exception 'Class not available'; end if;
 if p_title is null or length(trim(p_title)) not between 1 and 160 or jsonb_typeof(p_questions)<>'array' then raise exception 'Invalid quiz'; end if;
 n:=jsonb_array_length(p_questions);
 if n not between 1 and 100 then raise exception 'Use 1 to 100 questions'; end if;
 for q in select value from jsonb_array_elements(p_questions) loop
  if jsonb_typeof(q) is distinct from 'object' or coalesce(q->>'type','') not in ('mcq','tf','short') or jsonb_typeof(q->'text') is distinct from 'string' or coalesce(length(trim(q->>'text')),0) not between 1 and 2000 then raise exception 'Invalid question'; end if;
  if q->>'type'='mcq' then
   if jsonb_typeof(q->'options') is distinct from 'array' then raise exception 'Invalid choices'; end if;
   if jsonb_array_length(q->'options') not between 2 and 6 or jsonb_typeof(q->'correct') is distinct from 'number' or (q->>'correct')!~'^[0-5]$' then raise exception 'Invalid choices'; end if;
   if (q->>'correct')::int>=jsonb_array_length(q->'options') or exists(select 1 from jsonb_array_elements(q->'options') x where jsonb_typeof(x)<>'string' or length(trim(x#>>'{}')) not between 1 and 500) then raise exception 'Invalid choices'; end if;
   if (select count(distinct lower(trim(x))) from jsonb_array_elements_text(q->'options') x)<>jsonb_array_length(q->'options') then raise exception 'Duplicate choices'; end if;
  elsif q->>'type'='tf' and jsonb_typeof(q->'correct') is distinct from 'boolean' then raise exception 'Invalid true/false answer';
  elsif q->>'type'='short' and (jsonb_typeof(q->'answer') is distinct from 'string' or coalesce(length(trim(q->>'answer')),0) not between 1 and 500) then raise exception 'Invalid short answer'; end if;
 end loop;
 insert into brainjoy.assignments(class_id,title,questions) values(p_class,trim(p_title),p_questions) returning id into v;
 return v;
end $$;
create function public.bj_get_assignment(p_id uuid) returns jsonb language plpgsql security definer set search_path=pg_catalog as $$
declare a brainjoy.assignments; qs jsonb;
begin
 select * into a from brainjoy.assignments where id=p_id;
 if not found or auth.uid() is null or not exists(select 1 from brainjoy.classes c where c.id=a.class_id and (c.owner_id=auth.uid() or exists(select 1 from brainjoy.members m where m.class_id=c.id and m.student_id=auth.uid()))) then raise exception 'Assignment not available'; end if;
 select jsonb_agg(jsonb_build_object('type',q->>'type','text',q->>'text','options',q->'options')) into qs from jsonb_array_elements(a.questions) q;
 return jsonb_build_object('id',a.id,'title',a.title,'questions',qs,'closed',a.closed);
end $$;
create function public.bj_submit(p_id uuid,p_answers jsonb) returns jsonb language plpgsql security definer set search_path=pg_catalog as $$
declare a brainjoy.assignments; r brainjoy.attempts; q jsonb; ans jsonb; s integer:=0; i integer:=0; u uuid:=auth.uid();
begin
 select * into a from brainjoy.assignments where id=p_id for share;
 if not found or u is null or not exists(select 1 from brainjoy.members where class_id=a.class_id and student_id=u) then raise exception 'Assignment not available'; end if;
 select * into r from brainjoy.attempts where assignment_id=p_id and student_id=u;
 if found then return jsonb_build_object('score',r.score,'total',r.total,'already_submitted',true); end if;
 if a.closed then raise exception 'Assignment is closed'; end if;
 if jsonb_typeof(p_answers) is distinct from 'array' or jsonb_array_length(p_answers)<>jsonb_array_length(a.questions) then raise exception 'Answer every question'; end if;
 for q in select value from jsonb_array_elements(a.questions) loop
  ans:=p_answers->i;
  if (q->>'type' in ('mcq','tf') and ans=q->'correct') or (q->>'type'='short' and jsonb_typeof(ans)='string' and lower(trim(ans#>>'{}'))=lower(trim(q->>'answer'))) then s:=s+1; end if;
  i:=i+1;
 end loop;
 insert into brainjoy.attempts values(p_id,u,p_answers,s,i,now()) on conflict do nothing;
 select * into r from brainjoy.attempts where assignment_id=p_id and student_id=u;
 return jsonb_build_object('score',r.score,'total',r.total,'already_submitted',false);
end $$;
create function public.bj_parent_code() returns text language plpgsql security definer set search_path=pg_catalog as $$
declare v text; begin
 if auth.uid() is null then raise exception 'Sign in first'; end if;
 insert into brainjoy.parent_codes(student_id) values(auth.uid()) on conflict(student_id) do update set code=replace(gen_random_uuid()::text,'-',''),expires_at=now()+interval '24 hours' returning code into v;
 return v;
end $$;
create function public.bj_link_parent(p_code text) returns boolean language plpgsql security definer set search_path=pg_catalog as $$
declare v uuid; begin
 if auth.uid() is null then raise exception 'Sign in first'; end if;
 delete from brainjoy.parent_codes where code=trim(p_code) and expires_at>now() and student_id<>auth.uid() returning student_id into v;
 if v is null then raise exception 'Link code is invalid or expired'; end if;
 insert into brainjoy.parent_requests(student_id,parent_id) values(v,auth.uid()) on conflict do nothing;
 return true;
end $$;
create function public.bj_approve_parent(p_parent uuid) returns boolean language plpgsql security definer set search_path=pg_catalog as $$
begin
 if auth.uid() is null then raise exception 'Sign in first'; end if;
 delete from brainjoy.parent_requests where student_id=auth.uid() and parent_id=p_parent and created_at>now()-interval '24 hours';
 if not found then raise exception 'Parent request not found'; end if;
 insert into brainjoy.parent_links values(auth.uid(),p_parent) on conflict do nothing;
 return true;
end $$;
create function public.bj_unlink_parent(p_parent uuid) returns boolean language plpgsql security definer set search_path=pg_catalog as $$
begin delete from brainjoy.parent_links where student_id=auth.uid() and parent_id=p_parent; return found; end $$;
create function public.bj_dashboard() returns jsonb language plpgsql security definer set search_path=pg_catalog as $$
declare u uuid:=auth.uid(); v jsonb;
begin
 if u is null then raise exception 'Sign in first'; end if;
 select jsonb_build_object(
 'classes',coalesce((select jsonb_agg(jsonb_build_object('id',c.id,'title',c.title,'owner',c.owner_id=u,'join_code',case when c.owner_id=u then c.join_code end)) from brainjoy.classes c where c.owner_id=u or exists(select 1 from brainjoy.members m where m.class_id=c.id and m.student_id=u)),'[]'::jsonb),
 'assignments',coalesce((select jsonb_agg(jsonb_build_object('id',a.id,'class_id',a.class_id,'title',a.title,'closed',a.closed)) from brainjoy.assignments a join brainjoy.classes c on c.id=a.class_id where c.owner_id=u or exists(select 1 from brainjoy.members m where m.class_id=c.id and m.student_id=u)),'[]'::jsonb),
 'results',coalesce((select jsonb_agg(jsonb_build_object('assignment_id',r.assignment_id,'student_id',r.student_id,'score',r.score,'total',r.total,'submitted_at',r.submitted_at)) from brainjoy.attempts r join brainjoy.assignments a on a.id=r.assignment_id join brainjoy.classes c on c.id=a.class_id where r.student_id=u or c.owner_id=u or exists(select 1 from brainjoy.parent_links l where l.student_id=r.student_id and l.parent_id=u)),'[]'::jsonb),
 'linked_students',coalesce((select jsonb_agg(student_id) from brainjoy.parent_links where parent_id=u),'[]'::jsonb),
 'pending_parents',coalesce((select jsonb_agg(parent_id) from brainjoy.parent_requests where student_id=u and created_at>now()-interval '24 hours'),'[]'::jsonb),
 'linked_parents',coalesce((select jsonb_agg(parent_id) from brainjoy.parent_links where student_id=u),'[]'::jsonb),
 'admin',exists(select 1 from brainjoy.admins where user_id=u)) into v;
 return v;
end $$;
-- Default EXECUTE to PUBLIC must be removed for every entry point.
revoke all on function public.bj_create_class(text),public.bj_join_class(text),public.bj_publish(uuid,text,jsonb),public.bj_get_assignment(uuid),public.bj_submit(uuid,jsonb),public.bj_parent_code(),public.bj_link_parent(text),public.bj_unlink_parent(uuid),public.bj_approve_parent(uuid),public.bj_dashboard() from public,anon;
grant execute on function public.bj_create_class(text),public.bj_join_class(text),public.bj_publish(uuid,text,jsonb),public.bj_get_assignment(uuid),public.bj_submit(uuid,jsonb),public.bj_parent_code(),public.bj_link_parent(text),public.bj_unlink_parent(uuid),public.bj_approve_parent(uuid),public.bj_dashboard() to authenticated;
commit;
