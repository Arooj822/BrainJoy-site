"""Build a strict static allowlist. Never publish the repository root or credentials."""
from pathlib import Path
import re,zipfile
root=Path(__file__).resolve().parents[2]
files=['quiz-builder.html','quiz-play.html','quiz-store.js','ph-scale-litmus.html','enzyme-ph.html','titration-lab.html','sim-styles.css','logo.png','classroom-tools.html','classroom-tools.js','resource-library.html','resources/atomic-structure-sample.html','resources/atomic-structure-sample.json','platform/app/classroom.html','platform/app/classroom.js','platform/app/classroom.css','platform/app/config.js']
with zipfile.ZipFile('/tmp/brainjoy-preview.zip','w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('index.html','''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>BrainJoy development preview</title><style>body{font:18px system-ui;max-width:760px;margin:60px auto;padding:24px;color:#251a41;background:#faf8ff}a{color:#6a10ba}li{margin:20px 0}</style><h1>BrainJoy development preview</h1><p>Internal testing site. The live BrainJoy website is unchanged. Cloud accounts and classroom features are not enabled here.</p><ul><li><a href="quiz-builder.html">Quiz builder and practice</a></li><li><a href="classroom-tools.html">Playful classroom timer and tools</a></li><li><a href="resource-library.html">Resource library and original free sample</a></li><li><a href="platform/app/classroom.html">Classroom development preview (cloud sign-in disabled)</a></li><li><a href="ph-scale-litmus.html">pH and litmus lab</a></li><li><a href="enzyme-ph.html">Enzyme and pH lab</a></li><li><a href="titration-lab.html">Titration lab</a></li></ul><p><a href="https://brainjoy.site/">Existing BrainJoy website</a></p></html>''')
 z.writestr('_headers','/*\n  X-Robots-Tag: noindex, nofollow\n  X-Content-Type-Options: nosniff\n  Referrer-Policy: strict-origin-when-cross-origin\n')
 for f in files:
  data=(root/f).read_bytes()
  if f.endswith('.html'):
   s=data.decode()
   import posixpath
   s=re.sub(r'href="([^"#?:]+\.html)"',lambda m:'href="'+(m[1] if posixpath.normpath(posixpath.join(posixpath.dirname(f),m[1])) in files or posixpath.normpath(posixpath.join(posixpath.dirname(f),m[1]))=='index.html' else 'https://brainjoy.site/'+posixpath.normpath(posixpath.join(posixpath.dirname(f),m[1])))+'"',s)
   data=s.encode()
  z.writestr(f,data)
print('/tmp/brainjoy-preview.zip')
