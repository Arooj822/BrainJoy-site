"""Read-only check of the packaged static preview. Run after package-preview.py."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import json,posixpath,re,zipfile
archive=Path('/tmp/brainjoy-preview.zip')
z=zipfile.ZipFile(archive);names=set(z.namelist());problems=[];live_links=[]
class Links(HTMLParser):
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  for key in ['href','src']:
   value=a.get(key,'');u=urlsplit(value)
   if not value or value.startswith(('#','data:','javascript:','mailto:','tel:')):continue
   if u.scheme or u.netloc:
    if u.netloc=='brainjoy.site':live_links.append((current,value))
    continue
   target=posixpath.normpath(posixpath.join(posixpath.dirname(current),unquote(u.path)))
   if target not in names and target+'/index.html' not in names:problems.append(current+': unresolved '+value)
for current in sorted(names):
 if current.endswith('.html'):Links().feed(z.read(current).decode())
for name in names:
 if any(x in name for x in ['.env','.git/','tests/','synthetic','api/','node_modules','platform/migrations/']):problems.append('Private/development artifact: '+name)
config=z.read('platform/app/config.js').decode()
for flag in ['enabled','liveEnabled','rosterEnabled']:
 if not re.search('"'+flag+'"\s*:\s*false',config):problems.append('Access flag not explicitly false: '+flag)
for n in ['auth.html','login.html','landing.html','parent-dashboard.html','admin-dashboard.html']:
 s=z.read(n).decode()
 if 'createClient(' in s or 'signInWithPassword(' in s or 'signUp(' in s:problems.append('Legacy account execution: '+n)
js=z.read('SignUp_LogIn_Form.js').decode()
if any(t in js for t in ['hardcodedRoles','mock_role','signUp(']):problems.append('Legacy role/account bypass')
home=z.read('home-development.html').decode()
if re.search(r'<video[^>]+\ssrc=',home):problems.append('Homepage placeholder video still active')
for name in names:
 if name.endswith(('.js','.html','.css','.json')):
  body=z.read(name).decode()
  if re.search(r'AIza[0-9A-Za-z_-]{30,}|sk-(?:proj-)?[0-9A-Za-z_-]{25,}|sb_secret_[0-9A-Za-z_-]+',body):problems.append('Possible credential material: '+name)
print(json.dumps({'file_count':len(names),'problems':problems,'explicit_existing_site_links':len(live_links)},indent=2))
if problems:raise SystemExit(1)
