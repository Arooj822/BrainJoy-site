# BrainJoy release checklist

This is a finite release plan, not a claim that the whole requested platform is complete. Keep the existing site and content available until the replacement is accepted. Free tools and private classroom access are different release tracks.

## Track A: free tools, no account or paid provider

- [x] Write/import/export and play three supported question types, clearly distinguishing same-browser practice from cloud assignments.
- [x] Flashcards, worksheet with separate key, timed lesson plan, shared-screen review, classroom timer and picker.
- [x] Original particle mini-unit with separate student and teacher files, safe tool links and practice samples.
- [x] Editable topic-sequence guide with reviewed imports, local-save disclosure, portable backup and print. Not official alignment, mastery or an adaptive tutor.
- [x] Preserve original homepage cards and role buttons with accurate routing and limits.
- [x] Remove legacy mock-login bypass behavior; no role granted by chosen view or profile metadata.
- [x] Repair missing student/teacher entry routes; legacy parent/admin/landing/login do not claim queried metrics or send credentials.
- [x] Package only an explicit static allowlist. No credentials, test sessions, private migration files or development fixtures.
- [x] Automated packaged-page local-link audit, closed access flags and account-route guards.
- [x] Actual mobile/desktop checks of core tools and new sequence; worksheet/resource/sequence print checks.
- [ ] Finish keyboard/accessibility and cross-tool round-trip acceptance checks on the final packaged version.
- [ ] Check all included legacy simulations/content for loading and intended controls, not only new tools.
- [ ] Final source/preview integrity and content-preservation check.
- [ ] Owner acceptance and production deployment decision. The preview is not the public launch.

## Track B: existing-account private classroom pilot

- [x] Server-owned class membership, fixed assignments, immutable first scores and minimal owner roster.
- [x] Parent access requires an exact request and explicit student approval; revocation checked before export.
- [x] Admin membership separately approved; view/profile choices do not grant it.
- [x] Independent synthetic sessions: teacher publish, learner join and3/3, parent pending/approve/remove and stale-export denial.
- [x] Private live game: three question types, server score, realtime progression, hidden keys, outsider isolation and reconnect evidence.
- [x] Exact test-record/account cleanup and original-user preservation.
- [ ] Final standalone navigation/login/session acceptance using an authorized adult pilot. Isolated synthetic sessions are not this acceptance.
- [ ] Agree eligible audience, account provisioning, access/removal/support process and retention. No public signup is opened by this checklist.
- [ ] Owner acceptance and explicit access-release decision.

## Separate full-product work

These do not disappear because a manual alternative exists:

- AI tutor, AI generation/adaptive assessment: provider age/use conditions, privacy, quotas and operational approval, then actual implementation/evaluation.
- Account-linked goals/rewards: consent, data visibility, workflow and revocation requirements, then implementation. Game points are not real-world rewards.
- Screen-time enforcement: another device cannot be controlled by a normal website timer. Requires a supported device-management product and explicit scope.
- School imports, staff provisioning and district reports: identity/role and data-handling workflow, then implementation and authorization tests.
- Paid resources/subscriptions: rights, merchant eligibility, receiving-payment setup, fees, refund/support terms and owner approval before any sale.

## Repeatable checks

1. Run `python tests/run-local.py` from the project.
2. Run `python platform/scripts/package-preview.py`, then `python platform/scripts/audit-preview.py`.
3. Inspect the resulting preview at actual desktop/mobile size. Check printed output for affected pages.
4. Verify the published source archive and deployed changed files against their recorded hashes/bytes.
5. Confirm no temporary test pages, accounts or data remain. Keep all access flags closed until the corresponding decision and acceptance are complete.

The existing scholarship/article listings and original video are preserved content. Their availability, factual currency and rights are not implied by testing the new tools. The preserved video contains mole/molar-mass examples rather than the original atomic-structure page label; that mismatch is now stated alongside it. Full audio/content/alignment review remains open.
