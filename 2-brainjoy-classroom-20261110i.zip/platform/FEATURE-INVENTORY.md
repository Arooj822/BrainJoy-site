# Preserved feature inventory

Development checklist, not a release claim. Existing feature labels remain. Adjacent copy identifies the available manual/shared-screen version where AI or network functionality is still planned.

| Entry | Action | Open work |
| --- | --- | --- |
| Study Guides | `location.href='resources/atomic-structure-sample.html'` | Integration/release QA; planned AI/network features remain unfinished |
| BrainJoy AI Tutor | `requireAuthAction()` | Full feature not implemented |
| Flashcards | `location.href='flashcards.html'` | Integration/release QA; planned AI/network features remain unfinished |
| Games & Quizzes | `practice.html` | Self-paced samples ready for preview; real multi-device play remains unfinished |
| AI Lesson Planner | `location.href='lesson-planner.html'` | Integration/release QA; planned AI/network features remain unfinished |
| Live Review Game | `location.href='review-game.html'` | Integration/release QA; planned AI/network features remain unfinished |
| Quiz Builder AI | `location.href='quiz-builder.html'` | Integration/release QA; planned AI/network features remain unfinished |
| Classroom Dashboard | `requireAuthAction()` | Full feature not implemented |
| Student Analytics | `requireAuthAction()` | Full feature not implemented |
| BrainBlast Mode | `location.href='review-game.html'` | Integration/release QA; planned AI/network features remain unfinished |
| Progress Reports | `requireAuthAction()` | Full feature not implemented |
| Curriculum Guide | `requireAuthAction()` | Full feature not implemented |
| Reward System | `requireAuthAction()` | Full feature not implemented |
| Screen Time Limits | `requireAuthAction()` | Full feature not implemented |

Release gates: adult owner pilot; minor onboarding/consent; true multi-device live game; adaptive/AI service and quota control; approved paid packs/licences/refunds/merchant setup; parent rewards/time-limit enforcement; district admin imports and reports.

Backend owner-only admin membership is mapped. No new signup or production classroom access has been enabled.

Additional completed preview work: searchable original/same-browser practice library; exact-arithmetic six-question number-sense sample; duplicate-grade guard and expected-answer review; read-only classroom visible-result averages with sign-out purge. AI, adaptive assessment, verified guardian onboarding, rewards enforcement, true device/screen-time controls, district imports and live multi-device games remain unfinished.
