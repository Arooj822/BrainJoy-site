"""Run synthetic browser/unit suites against an ephemeral loopback-only server.
Requires google-chrome and node. Does not sign in or call a real backend.
SQL/realtime independent-session verification is separate.
"""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from functools import partial
import os, re, subprocess, tempfile, threading
ROOT=Path(__file__).resolve().parents[1]
class Quiet(SimpleHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_GET(self):
        if self.path.split('?')[0]=='/tests/classroom-route-fixture.html':
            html=(ROOT/'platform/app/classroom.html').read_text()
            mock=(ROOT/'tests/classroom-route-mock.js').read_text()
            html=re.sub(r'<script defer src="[^"]+"></script>',lambda m:m[0] if 'classroom.js' in m[0] else '',html)
            html=html.replace('<head>','<head><base href="/platform/app/"><script>'+mock+'</script>',1)
            data=html.encode();self.send_response(200);self.send_header('Content-Type','text/html');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
        if self.path.split('?')[0]=='/tests/live-route-fixture.html':
            html=(ROOT/'live-game.html').read_text()
            mock=(ROOT/'tests/live-route-mock.js').read_text()
            html=re.sub(r'<script defer src="[^"]+"></script>',lambda m:m[0] if 'live-game.js' in m[0] else '',html)
            html=html.replace('<head>','<head><base href="/"><script>'+mock+'</script>',1)
            data=html.encode();self.send_response(200);self.send_header('Content-Type','text/html');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
        if self.path.split('?')[0]=='/tests/parent-route-fixture.html':
            html=(ROOT/'platform/app/classroom.html').read_text()
            mock=(ROOT/'tests/parent-route-mock.js').read_text()
            html=re.sub(r'<script defer src="[^"]+"></script>',lambda m:m[0] if 'classroom.js' in m[0] else '',html)
            html=html.replace('<head>','<head><base href="/platform/app/"><script>'+mock+'</script>',1)
            data=html.encode();self.send_response(200);self.send_header('Content-Type','text/html');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
        if self.path.split('?')[0]=='/tests/teacher-filter-fixture.html':
            html=(ROOT/'platform/app/classroom.html').read_text()
            mock=(ROOT/'tests/teacher-filter-mock.js').read_text()
            html=re.sub(r'<script defer src="[^"]+"></script>',lambda m:m[0] if 'classroom.js' in m[0] else '',html)
            html=html.replace('<head>','<head><base href="/platform/app/"><script>'+mock+'</script>',1)
            data=html.encode();self.send_response(200);self.send_header('Content-Type','text/html');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
        return super().do_GET()
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(ROOT)))
threading.Thread(target=server.serve_forever,daemon=True).start()
failed=[]
try:
    for test in ['curriculum-ui','legacy-entry-ui','quiz-http','classroom-ui','role-routing-ui','parent-ui','teacher-filters-ui','assignment-races-ui','roster-ui','tools-ui','library-ui','flashcards-ui','lesson-ui','home-ui','review-ui','practice-ui','recovery-ui','worksheet-ui','live-game-ui','live-host-ui','live-routing-ui','live-gated-ui','resource-pack-ui']:
        with tempfile.TemporaryDirectory(prefix='bj-synthetic-') as profile:
            p=subprocess.run(['google-chrome','--headless','--no-sandbox','--disable-gpu','--disable-dev-shm-usage','--no-proxy-server','--user-data-dir='+profile,'--virtual-time-budget=15000','--dump-dom',f'http://127.0.0.1:{server.server_port}/tests/{test}.html'],capture_output=True,text=True,timeout=60)
        m=re.search(r'<pre id="result">([^<]*)',p.stdout)
        result=m.group(1) if m else 'FAIL: no result'
        print(test+': '+result,flush=True)
        if p.returncode or not result.startswith('PASS:'):failed.append(test)
    unit=subprocess.run(['node','tests/quiz-store.test.cjs'],cwd=ROOT,check=False)
    if unit.returncode:failed.append('quiz-store units')
finally:server.shutdown();server.server_close()
if failed:raise SystemExit('FAILED: '+', '.join(failed))
print('PASS: 23 browser suites plus quiz-store units. Mocks/local tools only; not live integration/release proof.')
