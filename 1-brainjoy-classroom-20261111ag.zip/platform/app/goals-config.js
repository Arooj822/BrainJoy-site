// Source only. Unresolved policy values are not consent. Not deployed or linked by ordinary pages.
window.BRAINJOY_GOALS_CONFIG=Object.freeze({enabled:false,audience:null,studentAgeRange:null,guardianPolicy:null,retentionPolicy:null});
