// SOURCE ONLY. No ordinary route points here. No migration installed or access enabled.
window.BRAINJOY_SCHOOL_CONFIG=Object.freeze({enabled:false,audience:null,studentAgeRange:null,guardianPolicy:null,retentionPolicy:null});
