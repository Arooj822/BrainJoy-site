/* Source-only school milestone. Not loaded by deployed pages. Pure validation, no storage or network. */
(function(root){'use strict';
const MAX_BYTES=50000,MAX_ROWS=200,uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
function parseCSV(input){
 if(typeof input!=='string'||new TextEncoder().encode(input).length>MAX_BYTES)throw Error('Use a UTF-8 CSV file no larger than 50 KB.');
 const text=input.replace(/^\uFEFF/,'');if(text.includes('\0'))throw Error('The CSV contains an unsupported null character.');
 const rows=[];let row=[],cell='',quoted=false,closed=false,lineNumber=1,rowStart=1;
 function endCell(){row.push(cell);cell='';closed=false;}
 function endRow(){endCell();if(row.some(v=>v.trim()!=='')){Object.defineProperty(row,'lineNumber',{value:rowStart});rows.push(row);}row=[];if(rows.length>MAX_ROWS+1)throw Error('Use at most 200 account rows.');}
 for(let i=0;i<text.length;i++){
  const c=text[i];
  if(quoted){if(c==='"'){if(text[i+1]==='"'){cell+='"';i++;}else{quoted=false;closed=true;}}else{cell+=c;if(c==='\n'||(c==='\r'&&text[i+1]!=='\n'))lineNumber++;}continue;}
  if(closed&&c!==','&&c!=='\r'&&c!=='\n')throw Error('Unexpected text after a quoted CSV value.');
  if(c==='"'){if(cell)throw Error('Quote a whole CSV value, not part of one.');quoted=true;}
  else if(c===',')endCell();else if(c==='\r'||c==='\n'){if(c==='\r'&&text[i+1]==='\n')i++;endRow();lineNumber++;rowStart=lineNumber;}else cell+=c;
 }
 if(quoted)throw Error('A quoted CSV value is not closed.');if(cell||row.length||closed)endRow();return rows;
}
function review(input,{classId,ownerId}={}){
 if(!uuid.test(classId||'')||!uuid.test(ownerId||''))throw Error('Choose a currently owned class and signed-in account.');
 const rows=parseCSV(input);if(!rows.length||rows[0].length!==1||rows[0][0].trim()!=='student_account_id')throw Error('Use exactly one column headed student_account_id. Do not include names, emails, ages or other personal details.');
 const accounts=[],errors=[],seen=new Map();for(let i=1;i<rows.length;i++){
  const row=rows[i],value=(row[0]||'').trim().toLowerCase(),line=row.lineNumber||i+1;
  if(row.length!==1){errors.push({row:line,message:'Expected only the account ID column.'});continue;}
  if(!uuid.test(value)){errors.push({row:line,message:'Enter a complete valid account ID, not a name or email.'});continue;}
  if(value===ownerId.toLowerCase()){errors.push({row:line,message:'The class owner cannot be imported as a student.'});continue;}
  if(seen.has(value)){errors.push({row:line,message:'Duplicate account ID. First appears on row '+seen.get(value)+'.'});continue;}
  seen.set(value,line);accounts.push(value);
 }
 if(rows.length===1)errors.push({row:2,message:'Add at least one existing student account ID.'});
 return Object.freeze({version:1,class_id:classId.toLowerCase(),reviewed_by:ownerId.toLowerCase(),accounts:Object.freeze(accounts),errors:Object.freeze(errors.map(Object.freeze)),ready:errors.length===0});
}
function manifest(result,{currentClassId,currentOwnerId,confirmed=false}={}){
 if(!result||!result.ready||result.errors.length||!confirmed)throw Error('Review and explicitly confirm an error-free list first.');
 if(result.class_id!==currentClassId?.toLowerCase()||result.reviewed_by!==currentOwnerId?.toLowerCase())throw Error('The account or class changed. Review the file again.');
 // Revalidate rather than trust caller-owned state.
 const checked=review('student_account_id\n'+result.accounts.join('\n'),{classId:currentClassId,ownerId:currentOwnerId});
 if(!checked.ready)throw Error('The reviewed list changed. Review the original file again.');
 return{version:1,purpose:'roster-review-only',class_id:checked.class_id,student_account_ids:[...checked.accounts],creates_accounts:false,sends_invitations:false,grants_membership:false,audience_and_privacy_approval:'unresolved'};
}
const api=Object.freeze({parseCSV,review,manifest,MAX_BYTES,MAX_ROWS});if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.BrainJoyRosterImport=api;
})(typeof window!=='undefined'?window:globalThis);
