# Private study goals and self-reported progress

Source-only, disabled milestone. Migration008 is not installed, no goals page is deployed or linked by ordinary pages, and no existing account or sharing policy is changed.

## Implemented

- Server-owned goal records tied to the signed-in account, private by default. Short160-character task title, 1..100 planned steps, 0..target self-reported completed steps, revision and update time. No names/emails or extra profile data are requested. Goal text can still contain personal information, so the UI asks for nonsensitive learning tasks.
-40active and200total stored goals per account. Create/restore counts are serialized on the existing account row in the proposed migration. Concurrent final-slot creates cannot exceed40active goals.
- Student-owned progress updates with optimistic revision checks. A stale edit is rejected for refresh, not silently applied over newer progress. Two concurrent same-revision edits cannot both succeed.
- Reversible archive, not deletion. Archiving removes every parent goal-sharing grant; restoring remains private. No completed work is erased by restoring or lowering a self-reported count.
- Exact per-goal/per-parent sharing opt-in. The recipient must already have a current approved parent link AND the student must separately share this goal with that exact account. Existing quiz-score sharing alone never includes goals. Confirmation names the goal and recipient account and describes title/count/update-time disclosure. This is permission logic to be released only after appropriate audience/guardian policy, not proof of legal guardianship.
- Parents have read-only shared goal title, student account ID, counts and update time. No answers, grades, other parent accounts, revision/owner controls or goal editing. Teachers, school managers and platform-admin labels receive no new goal rights.
- Current approved link is checked on every dashboard read/share operation. Source migration adds a parent-unlink cleanup trigger that permanently removes goal grants for the removed link. Relinking never revives old goal access. Existing classroom function bodies are not replaced.
- Source-only UI with create/update/archive/restore, active/archive filter, explicit sharing/removal, and approved shared-student filter. Text-only rendering, labeled progress, default-cancel confirmations, immediate account-change/signout purge, request/revision guards and default-disabled service gate.
- Shared records/filter are cleared before every refresh, including failed refresh; stale data cannot be redisplayed through a filter after that failure. Hiding the page clears private goal DOM/state; returning rechecks server access. No polling or notifications.

## Not implemented or implied

These are self-reported study steps, not measured learning, standardized assessment, mastery, an adaptive tutor, verified effort or evidence of attendance. There are no points with monetary value, prizes, obligations, streak pressure, spending, parent-written tasks, teacher assignment links, automatic emails or reminders. This does not complete the requested broader reward system. Parent writing and real-world rewards would need their own scope/approval.

There is no live enrollment, public signup, legal-guardian verification or account recovery workflow here. Student audience/ages/country, lawful guardian permission, support/removal and retention policy remain unresolved and null in config. A source record or passing test does not authorize collecting real children's goal text. No arbitrary retention default or public release is inferred.

Parent revocation stops future authorized reads; it cannot recall screenshots or copies already made. A currently open visible view is not realtime monitored: it rechecks on explicit Refresh and when returning to a hidden page. Users are told to refresh before relying on shared information. No claim of instant remote erasure or notification is made.

Archive is reversible storage, not a personal-data deletion request. Actual retention/deletion policy and implementation remain separate work.200stored-goal bound prevents unbounded source behavior but is not a promised production quota or retention period.

## Proposed migration boundaries

`008_study_goals.sql`: new private RLS tables, four fixed-search-path definer RPCs, no direct authenticated/anonymous table access, explicit anonymous/public execute revocation, and a private unlink-cleanup trigger. Per-account/goal/link row locks and revision checks protect proposed writes. No installed schema/RPC is changed during this milestone. `008_study_goals.disable.sql` closes new RPC execution without deleting records and preserves the unlink cleanup trigger if ever installed.

Before real use: audience/privacy/guardian/support/retention decisions, source/name-collision/security review, real-service authorization/concurrency and account acceptance, and explicit release. Check proposed trigger behavior against the actual deployed parent-link lifecycle before installation. Ordinary site/app/access/provider/payment settings remain unchanged.

## Evidence

- `tests/study-goals.sql`: disposable local SQL with rollback-only synthetic users. Private defaults; pending/approved-but-not-goal-shared parent denial; exact per-goal reads; parent/teacher/outsider edit and self-grant denial; unlink/relink and archive/restore sharing removal; stale revision/count/total bounds; null/anonymous/direct-table denial; minimal shared fields.
- `tests/study-goals-concurrency.py`: local-only disposable database, exact fixture cleanup. Two independent same-revision edits yield exactly one success. Concurrent last-slot creates preserve40active limit. Not a hosted concurrency certification.
- `tests/goals-ui.html`: actual source page with synthetic RPC fixture, exact share/cancel, safe text, progress/revision, archive/restore privacy, read-only shared view, failed-refresh/revoked-filter purge, stale auth read and disabled gate.
-32local browser suites plus quiz-store/roster-import units pass. One prior actual-SDK suite run timed out waiting for INITIAL_SESSION; isolated rerun, five repeat SDK runs and the subsequent full run passed without changing production code. Intermittent event/test startup timing is not declared permanently fixed.
-390px/1200px source-only pixels inspected. Ordinary static candidate and preview exclude all goals files/migration/tests and remain the earlier ad bytes.
