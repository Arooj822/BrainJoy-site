-- SOURCE ONLY. NOT INSTALLED. Audience/privacy/account-release decisions unresolved.
-- Additive organization/staff metadata. No Auth account creation, mail, enrollment, grades, payments or existing-RPC permission changes.
-- Apply only after independent source/collision/authorization and owner release checks.
begin;
create table brainjoy.schools(id uuid primary key default gen_random_uuid(),owner_id uuid not null references auth.users(id),title text not null check(length(trim(title)) between 1 and 160),created_at timestamptz not null default now());
create table brainjoy.school_staff(school_id uuid not null references brainjoy.schools(id),user_id uuid not null references auth.users(id),staff_role text not null check(staff_role in ('manager','teacher')),granted_by uuid not null references auth.users(id),accepted_at timestamptz,created_at timestamptz not null default now(),primary key(school_id,user_id));
create table brainjoy.school_classes(school_id uuid not null references brainjoy.schools(id),class_id uuid not null unique references brainjoy.classes(id),attached_by uuid not null references auth.users(id),attached_at timestamptz not null default now(),primary key(school_id,class_id));
alter table brainjoy.schools enable row level security;
alter table brainjoy.school_staff enable row level security;
alter table brainjoy.school_classes enable row level security;
revoke all on brainjoy.schools,brainjoy.school_staff,brainjoy.school_classes from public,anon,authenticated;
create function public.bj_school_create(p_title text) returns uuid language plpgsql security definer set search_path=pg_catalog as $$
declare v uuid;u uuid:=auth.uid();begin
 if u is null then raise exception 'Sign in first';end if;
 if p_title is null or length(trim(p_title)) not between 1 and 160 then raise exception 'Use a school name of 1 to 160 characters';end if;
 insert into brainjoy.schools(owner_id,title)values(u,trim(p_title))returning id into v;return v;
end $$;
create function public.bj_school_staff_grant(p_school uuid,p_user uuid,p_role text) returns boolean language plpgsql security definer set search_path=pg_catalog as $$
declare u uuid:=auth.uid();s brainjoy.schools;begin
 select * into s from brainjoy.schools where id=p_school for update;
 if not found or u is null or not(s.owner_id=u or exists(select 1 from brainjoy.school_staff where school_id=p_school and user_id=u and staff_role='manager' and accepted_at is not null)) then raise exception 'School not available';end if;
 if p_role is null or p_role not in ('manager','teacher') or p_user is null or p_user=s.owner_id then raise exception 'Invalid staff grant';end if;
 if s.owner_id<>u and (p_role<>'teacher' or exists(select 1 from brainjoy.school_staff where school_id=p_school and user_id=p_user and staff_role='manager'))then raise exception 'Only the school owner manages managers';end if;
 if not exists(select 1 from auth.users where id=p_user)then raise exception 'Staff account not available';end if;
 -- Every grant/regrant is pending again. A changed role never silently inherits old acceptance.
 insert into brainjoy.school_staff(school_id,user_id,staff_role,granted_by)values(p_school,p_user,p_role,u)on conflict(school_id,user_id)do update set staff_role=excluded.staff_role,granted_by=u,accepted_at=null,created_at=now();
 return true;
end $$;
create function public.bj_school_staff_accept(p_school uuid,p_expected_role text) returns boolean language plpgsql security definer set search_path=pg_catalog as $$
declare u uuid:=auth.uid();begin
 if u is null then raise exception 'Sign in first';end if;
 -- Role is echoed from reviewed pending grant, not selected by the recipient.
 perform 1 from brainjoy.schools where id=p_school for update;
 update brainjoy.school_staff set accepted_at=now()where school_id=p_school and user_id=u and staff_role=p_expected_role and accepted_at is null;
 if not found then raise exception 'Pending staff grant changed or is not available';end if;return true;
end $$;
create function public.bj_school_staff_remove(p_school uuid,p_user uuid)returns boolean language plpgsql security definer set search_path=pg_catalog as $$
declare u uuid:=auth.uid();s brainjoy.schools;r text;begin
 select * into s from brainjoy.schools where id=p_school for update;
 if not found or u is null then raise exception 'School not available';end if;
 select staff_role into r from brainjoy.school_staff where school_id=p_school and user_id=p_user;
 if p_user is null or p_user=s.owner_id or not(u=s.owner_id or u=p_user or (coalesce(r='teacher',false) and exists(select 1 from brainjoy.school_staff where school_id=p_school and user_id=u and staff_role='manager' and accepted_at is not null)))then raise exception 'Staff grant not available';end if;
 delete from brainjoy.school_classes sc using brainjoy.classes c where sc.school_id=p_school and sc.class_id=c.id and c.owner_id=p_user;
 delete from brainjoy.school_staff where school_id=p_school and user_id=p_user;return found;
end $$;
create function public.bj_school_class_attach(p_school uuid,p_class uuid)returns boolean language plpgsql security definer set search_path=pg_catalog as $$
declare u uuid:=auth.uid();s brainjoy.schools;begin
 select * into s from brainjoy.schools where id=p_school for update;
 if not found or u is null or not(s.owner_id=u or exists(select 1 from brainjoy.school_staff where school_id=p_school and user_id=u and accepted_at is not null))then raise exception 'School not available';end if;
 if not exists(select 1 from brainjoy.classes where id=p_class and owner_id=u)then raise exception 'Only the class owner can attach this class';end if;
 if exists(select 1 from brainjoy.school_classes where class_id=p_class and school_id<>p_school)then raise exception 'Detach the class from its current school first';end if;
 insert into brainjoy.school_classes(school_id,class_id,attached_by)values(p_school,p_class,u)on conflict do nothing;return true;
end $$;
create function public.bj_school_class_detach(p_school uuid,p_class uuid)returns boolean language plpgsql security definer set search_path=pg_catalog as $$
declare u uuid:=auth.uid();s brainjoy.schools;begin
 select * into s from brainjoy.schools where id=p_school for update;
 if not found or u is null or not(s.owner_id=u or exists(select 1 from brainjoy.classes where id=p_class and owner_id=u))then raise exception 'Class association not available';end if;
 delete from brainjoy.school_classes where school_id=p_school and class_id=p_class;return found;
end $$;
create function public.bj_school_dashboard()returns jsonb language plpgsql security definer set search_path=pg_catalog as $$
declare u uuid:=auth.uid();begin
 if u is null then raise exception 'Sign in first';end if;
 return jsonb_build_object('schools',coalesce((select jsonb_agg(jsonb_build_object('id',s.id,'title',s.title,'role',case when s.owner_id=u then 'owner' else f.staff_role end,'accepted',s.owner_id=u or f.accepted_at is not null,
 'staff',case when s.owner_id=u or (f.staff_role='manager' and f.accepted_at is not null) then coalesce((select jsonb_agg(jsonb_build_object('account_id',x.user_id,'role',x.staff_role,'accepted',x.accepted_at is not null) order by x.created_at,x.user_id)from brainjoy.school_staff x where x.school_id=s.id),'[]'::jsonb)else '[]'::jsonb end,
 'classes',case when s.owner_id=u or f.accepted_at is not null then coalesce((select jsonb_agg(jsonb_build_object('id',c.id,'title',c.title,'owned',c.owner_id=u))from brainjoy.school_classes sc join brainjoy.classes c on c.id=sc.class_id where sc.school_id=s.id and (c.owner_id=u or s.owner_id=u or f.staff_role='manager') and (c.owner_id=s.owner_id or exists(select 1 from brainjoy.school_staff active where active.school_id=s.id and active.user_id=c.owner_id and active.accepted_at is not null))),'[]'::jsonb)else '[]'::jsonb end) order by s.created_at,s.id)from brainjoy.schools s left join brainjoy.school_staff f on f.school_id=s.id and f.user_id=u where s.owner_id=u or f.user_id=u),'[]'::jsonb));
end $$;
-- PUBLIC execute defaults must be removed for every new function.
revoke all on function public.bj_school_create(text),public.bj_school_staff_grant(uuid,uuid,text),public.bj_school_staff_accept(uuid,text),public.bj_school_staff_remove(uuid,uuid),public.bj_school_class_attach(uuid,uuid),public.bj_school_class_detach(uuid,uuid),public.bj_school_dashboard()from public,anon;
grant execute on function public.bj_school_create(text),public.bj_school_staff_grant(uuid,uuid,text),public.bj_school_staff_accept(uuid,text),public.bj_school_staff_remove(uuid,uuid),public.bj_school_class_attach(uuid,uuid),public.bj_school_class_detach(uuid,uuid),public.bj_school_dashboard()to authenticated;
commit;
