-- Source-only emergency close, no deletion of schools/staff/classes/student data.
begin;
revoke all on function public.bj_school_create(text),public.bj_school_staff_grant(uuid,uuid,text),public.bj_school_staff_accept(uuid,text),public.bj_school_staff_remove(uuid,uuid),public.bj_school_class_attach(uuid,uuid),public.bj_school_class_detach(uuid,uuid),public.bj_school_dashboard()from public,anon,authenticated;
commit;
