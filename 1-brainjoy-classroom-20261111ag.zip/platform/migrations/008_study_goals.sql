-- SOURCE ONLY. NOT INSTALLED. No existing parent-sharing scope is widened.
-- Private student-owned goals. Parent reads require exact per-goal grant AND current approved parent link.
begin;
create table brainjoy.study_goals(id uuid primary key default gen_random_uuid(),student_id uuid not null references auth.users(id),title text not null check(length(trim(title)) between 1 and 160),target integer not null check(target between 1 and 100),completed integer not null default 0 check(completed>=0 and completed<=target),revision integer not null default 1,archived boolean not null default false,created_at timestamptz not null default now(),updated_at timestamptz not null default now());
create table brainjoy.goal_shares(goal_id uuid not null references brainjoy.study_goals(id),parent_id uuid not null references auth.users(id),granted_at timestamptz not null default now(),primary key(goal_id,parent_id));
alter table brainjoy.study_goals enable row level security;alter table brainjoy.goal_shares enable row level security;
revoke all on brainjoy.study_goals,brainjoy.goal_shares from public,anon,authenticated;
create function public.bj_goal_create(p_title text,p_target integer)returns jsonb language plpgsql security definer set search_path=pg_catalog as $$
declare u uuid:=auth.uid();g brainjoy.study_goals;begin
 if u is null then raise exception 'Sign in first';end if;
 -- Per-account serialization prevents concurrent requests from bypassing active-goal limit.
 perform 1 from auth.users where id=u for update;
 if p_title is null or length(trim(p_title)) not between 1 and 160 or p_target is null or p_target not between 1 and 100 then raise exception 'Use a goal title and 1 to 100 self-reported steps';end if;
 if(select count(*)from brainjoy.study_goals where student_id=u)>=200 then raise exception 'This account has reached the 200-goal storage limit';end if;
 if(select count(*)from brainjoy.study_goals where student_id=u and not archived)>=40 then raise exception 'Archive an existing goal before adding more';end if;
 insert into brainjoy.study_goals(student_id,title,target)values(u,trim(p_title),p_target)returning *into g;return jsonb_build_object('id',g.id,'revision',g.revision);
end $$;
create function public.bj_goal_update(p_id uuid,p_revision integer,p_completed integer,p_archived boolean)returns integer language plpgsql security definer set search_path=pg_catalog as $$
declare u uuid:=auth.uid();g brainjoy.study_goals;begin
 select *into g from brainjoy.study_goals where id=p_id and student_id=u for update;
 if not found or u is null then raise exception 'Goal not available';end if;
 if p_revision is distinct from g.revision then raise exception 'Goal changed. Refresh before editing';end if;
 if p_completed is null or p_completed<0 or p_completed>g.target or p_archived is null then raise exception 'Invalid goal progress';end if;
 if g.archived and not p_archived then
  perform 1 from auth.users where id=u for update;
  if(select count(*)from brainjoy.study_goals where student_id=u and not archived)>=40 then raise exception 'Archive another goal before restoring this one';end if;
 end if;
 update brainjoy.study_goals set completed=p_completed,archived=p_archived,revision=revision+1,updated_at=now()where id=g.id returning revision into g.revision;
 -- Archive is reversible, but shares are intentionally not restored automatically.
 if p_archived then delete from brainjoy.goal_shares where goal_id=g.id;end if;return g.revision;
end $$;
create function public.bj_goal_share(p_id uuid,p_parent uuid,p_share boolean)returns boolean language plpgsql security definer set search_path=pg_catalog as $$
declare u uuid:=auth.uid();g brainjoy.study_goals;begin
 select *into g from brainjoy.study_goals where id=p_id and student_id=u for update;
 if not found or u is null or p_share is null or p_parent is null then raise exception 'Goal not available';end if;
 if p_share then
  if g.archived then raise exception 'Restore the goal before sharing it';end if;
  -- Lock the currently approved link against concurrent unlink. Never consumes a parent code.
  perform 1 from brainjoy.parent_links where student_id=u and parent_id=p_parent for share;
  if not found then raise exception 'This parent account is not currently approved';end if;
  insert into brainjoy.goal_shares(goal_id,parent_id)values(g.id,p_parent)on conflict do nothing;
 else delete from brainjoy.goal_shares where goal_id=g.id and parent_id=p_parent;end if;return true;
end $$;
create function public.bj_goal_dashboard()returns jsonb language plpgsql security definer set search_path=pg_catalog as $$
declare u uuid:=auth.uid();begin
 if u is null then raise exception 'Sign in first';end if;
 return jsonb_build_object(
 'own',coalesce((select jsonb_agg(jsonb_build_object('id',g.id,'title',g.title,'target',g.target,'completed',g.completed,'revision',g.revision,'archived',g.archived,'updated_at',g.updated_at,'shared_with',coalesce((select jsonb_agg(s.parent_id order by s.parent_id)from brainjoy.goal_shares s join brainjoy.parent_links l on l.parent_id=s.parent_id and l.student_id=u where s.goal_id=g.id),'[]'::jsonb))order by g.created_at,g.id)from brainjoy.study_goals g where g.student_id=u),'[]'::jsonb),
 'approved_parents',coalesce((select jsonb_agg(parent_id order by parent_id)from brainjoy.parent_links where student_id=u),'[]'::jsonb),
 'shared',coalesce((select jsonb_agg(jsonb_build_object('id',g.id,'student_id',g.student_id,'title',g.title,'target',g.target,'completed',g.completed,'updated_at',g.updated_at)order by g.student_id,g.created_at,g.id)from brainjoy.study_goals g join brainjoy.goal_shares s on s.goal_id=g.id and s.parent_id=u join brainjoy.parent_links l on l.student_id=g.student_id and l.parent_id=u where not g.archived),'[]'::jsonb));
end $$;
-- An unlink permanently clears the added goal grant. Relinking never restores goal visibility.
create function brainjoy.clear_goal_shares_on_parent_unlink()returns trigger language plpgsql security definer set search_path=pg_catalog as $$
begin delete from brainjoy.goal_shares s using brainjoy.study_goals g where s.goal_id=g.id and g.student_id=old.student_id and s.parent_id=old.parent_id;return old;end $$;
revoke all on function brainjoy.clear_goal_shares_on_parent_unlink()from public,anon,authenticated;
create trigger clear_goal_shares_after_parent_unlink after delete on brainjoy.parent_links for each row execute function brainjoy.clear_goal_shares_on_parent_unlink();
revoke all on function public.bj_goal_create(text,integer),public.bj_goal_update(uuid,integer,integer,boolean),public.bj_goal_share(uuid,uuid,boolean),public.bj_goal_dashboard()from public,anon;
grant execute on function public.bj_goal_create(text,integer),public.bj_goal_update(uuid,integer,integer,boolean),public.bj_goal_share(uuid,uuid,boolean),public.bj_goal_dashboard()to authenticated;
commit;
