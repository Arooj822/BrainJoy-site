-- Source-only close. Preserves goals and sharing-removal trigger. No data deletion.
begin;
revoke all on function public.bj_goal_create(text,integer),public.bj_goal_update(uuid,integer,integer,boolean),public.bj_goal_share(uuid,uuid,boolean),public.bj_goal_dashboard()from public,anon,authenticated;
commit;
