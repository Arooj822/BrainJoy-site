# School/staff and roster preparation

Source-only, disabled milestone. No migration007 or school page is deployed. The normal website, its access flags, existing class permissions and provider settings are unchanged.

## Implemented

- School records with owner membership separate from platform administrators. A record is a user-created organizational label, not institution or identity verification.
- Exact-account pending staff grants for manager or teacher. Only the school owner can grant/remove manager authority. An accepted manager can prepare teacher grants, not promote staff or manage another manager. Every grant/regrant requires exact-role acceptance again.
- Pending grants show their own school/title/role, not class metadata or staff lists. Accepted teachers see only their own attached classes; accepted managers/owner see associated class titles. No student membership, scores, answers, names, email addresses, parent links or join codes are returned by the school API.
- Only an actual class owner can attach it. A school role never becomes class ownership. Attachment requires explicit confirmation of class-title sharing. Detachment preserves the class and every original permission. Removal/leave clears that person's school-class associations but does not delete their original classes or records.
- School roles cannot use another owner's class roster, publish assignments, read its results or become platform admins through existing RPCs. Those authorization rules are unchanged.
- Disabled workspace with pending-grant acceptance/decline, explicit confirmations, staff grants/removal, class attach/detach, source-only existing-account sign-in, immediate account-change/signout purge and stale-response guards.
- Local-only CSV review for currently owned classes: one column `student_account_id`, existing UUIDs only, strict quoting/schema, 50 KB/200-row bounds, accurate physical-row errors, duplicates/self-ID/extra-column rejection. No names or emails. Text-only rendering.
- Explicitly confirmed review-manifest download, scoped to the current account/class and invalidated on refresh, file/class/account change or signout. File reads are request-scoped. Export revalidates contents, states `grants_membership:false`, `creates_accounts:false`, `sends_invitations:false`, and keeps audience/privacy approval `unresolved`.

## Not implemented or implied

No enrollment import is applied. No account existence/identity verification is performed by CSV review. No emails, invitations, account creation or student membership writes. A review manifest is not consent or an import authorization. No new data-retention value, approved audience, legal guardian workflow or institution verification is invented. No owner transfer, institution-wide student analytics, delegated class management, district reporting or SIS synchronization is implemented here. Those remain work, not completed by showing school titles.

The school owner is not a platform administrator. Staff account IDs and class titles are still private operational data: eventual release must have suitable authority and policies for that audience. Leaving the role field unresolved in config does not establish lawful consent.

## Reversible implementation and release gates

`migrations/007_school_preparation.sql` is additive, with RLS and no direct API table access. Fixed-search-path security-definer RPCs explicitly revoke anonymous/public execution. School-row locking serializes staff acceptance/regrant/removal and class association changes. Existing classroom RPCs are not replaced. `007_school_preparation.disable.sql` closes all new RPC execution without deleting data.

Default `app/school-config.js` is disabled and has null audience, age, guardian and retention policy fields. No ordinary route links to it, and static package allowlists exclude all school files and migration007. A source page existing in the archive does not mean it is deployed or callable.

Before any real use: finish intended-audience/country/age and privacy/onboarding decisions; verify institution/staff authority; establish account provisioning/support/removal and retention; run migration collision/source/security review and authorized real-service acceptance; explicitly approve release. Do not treat a displayed staff account or manual ID handoff as verified identity. No activation follows automatically from tests passing.

## Evidence

- Disposable local PostgreSQL database with synthetic `auth.users`/`auth.uid`, base002 and006, then source007. `tests/school-permissions.sql` rolls back all fixture rows. Checks pending/accepted role isolation, exact-role acceptance, manager escalation denial, class-owner association, no inherited roster/publish/admin authority, teacher removal/leave and class preservation, outsider/null/anon/direct-table denial.
- `tests/roster-import.test.cjs` covers parsing, quoted/CRLF/BOM input, bounds, invalid/duplicate/self IDs, stale account/class and confirmation/revalidation.
- `tests/school-ui.html` uses the actual source page with synthetic RPCs. Checks role controls, cancellation/exact grants, text injection safety, no automatic mutations, reviewed local export/no authority, private-state purge and default closed state.
- Mobile390px and desktop1200px source-only captures inspected. These are not hosted real-account or legal acceptance tests.
-31browser suites plus quiz-store and roster-import units pass locally. School-specific tests exercise source-only files; the ordinary packaged candidate remains the prior ad app, not a school release.
