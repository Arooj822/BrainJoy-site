// Actual Supabase SDK, synthetic loopback-only service. All token strings are inert, not credentials.
const SDK=window.supabase,service='https://brainjoy-synthetic.invalid';
window.BRAINJOY_CONFIG={enabled:true,liveEnabled:true,rosterEnabled:true,url:service,anonKey:'inert-public-test-key'};
window.sdkEvents=[];window.sdkCalls=[];window.insideCallback=false;
function encoded(value){return btoa(JSON.stringify(value)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}
function token(id){return encoded({alg:'HS256',typ:'JWT'})+'.'+encoded({sub:id,aud:'authenticated',role:'authenticated',iat:Math.floor(Date.now()/1000),exp:Math.floor(Date.now()/1000)+3600})+'.inert-signature';}
function user(id){return{id,aud:'authenticated',role:'authenticated',email:id+'@example.invalid',app_metadata:{},user_metadata:{},created_at:'2026-11-10T19:00:00Z'};}
function response(body,status=200){return new Response(status===204?null:JSON.stringify(body),{status,headers:{'Content-Type':'application/json'}});}
function owner(headers){const value=new Headers(headers).get('Authorization')?.replace('Bearer ','');try{return JSON.parse(atob(value.split('.')[1].replace(/-/g,'+').replace(/_/g,'/'))).sub;}catch(_){return null;}}
async function localService(input,options={}){
 const url=new URL(typeof input==='string'?input:input.url);if(url.origin!==service)throw Error('Unexpected external service');if(window.insideCallback)throw Error('Request inside auth callback');
 const body=typeof options.body==='string'?JSON.parse(options.body):{},id=owner(options.headers);window.sdkCalls.push({path:url.pathname,grant:url.searchParams.get('grant_type'),id});
 if(url.pathname==='/auth/v1/token'){const account=url.searchParams.get('grant_type')==='refresh_token'?(body.refresh_token.startsWith('synthetic-b')?'synthetic-b':'synthetic-a'):(body.email.startsWith('b')?'synthetic-b':'synthetic-a');return response({access_token:token(account),refresh_token:account+'-inert-refresh',expires_in:3600,token_type:'bearer',user:user(account)});}
 if(url.pathname==='/auth/v1/logout')return response(null,204);
 if(url.pathname==='/auth/v1/user')return response(user(id));
 if(!id)return response({message:'No synthetic account'},401);
 if(url.pathname==='/rest/v1/rpc/bj_dashboard')return response({classes:[{id:id+'-class',owner:true,title:id+' class',join_code:id+'-private'}],assignments:[{id:id+'-quiz',class_id:id+'-class',title:id+' assignment',closed:false}],results:[],pending_parents:[],linked_parents:[],linked_students:[],admin:false});
 if(url.pathname==='/rest/v1/rpc/bj_live_list')return response([{id:id+'-game',host:true,title:id+' recent game',state:'lobby'}]);
 throw Error('Unexpected mutation or RPC: '+url.pathname);
}
window.supabase={createClient:(url,key)=>{
 const client=SDK.createClient(url,key,{global:{fetch:localService},auth:{storageKey:'brainjoy-synthetic-sdk-only',autoRefreshToken:false,detectSessionInUrl:false}});window.sdkClient=client;
 const subscribe=client.auth.onAuthStateChange.bind(client.auth);client.auth.onAuthStateChange=fn=>subscribe((event,next)=>{window.sdkEvents.push({event,id:next?.user.id});window.insideCallback=true;try{return fn(event,next);}finally{window.insideCallback=false;}});
 return client;
}};
