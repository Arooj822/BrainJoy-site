-- Disposable local DB only; never a live-account fixture.
begin;
do $$
declare o uuid:=gen_random_uuid();m uuid:=gen_random_uuid();t uuid:=gen_random_uuid();x uuid:=gen_random_uuid();learner uuid:=gen_random_uuid();s uuid;s2 uuid;c jsonb;other jsonb;r jsonb;denied boolean;
begin
 insert into auth.users(id)values(o),(m),(t),(x),(learner);
 perform set_config('role','authenticated',true);perform set_config('request.jwt.claim.sub',o::text,true);
 s:=public.bj_school_create('Synthetic school');c:=public.bj_create_class('Owner class');
 perform public.bj_school_staff_grant(s,m,'manager');perform public.bj_school_staff_grant(s,t,'teacher');
 perform set_config('request.jwt.claim.sub',m::text,true);r:=public.bj_school_dashboard();
 if r->'schools'->0->>'accepted'<>'false' or r->'schools'->0->'classes'<>'[]' or r->'schools'->0->'staff'<>'[]' then raise exception 'FAIL pending grant exposure';end if;
 denied:=false;begin perform public.bj_school_staff_grant(s,x,'teacher');exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL pending manager authority';end if;
 denied:=false;begin perform public.bj_school_staff_accept(s,'teacher');exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL role mismatch accepted';end if;
 perform public.bj_school_staff_accept(s,'manager');perform public.bj_school_staff_grant(s,x,'teacher');
 denied:=false;begin perform public.bj_school_staff_grant(s,t,'manager');exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL manager escalation';end if;
 denied:=false;begin perform public.bj_school_class_attach(s,(c->>'id')::uuid);exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL manager claims owner class';end if;
 perform set_config('request.jwt.claim.sub',t::text,true);perform public.bj_school_staff_accept(s,'teacher');other:=public.bj_create_class('Teacher class');perform public.bj_school_class_attach(s,(other->>'id')::uuid);
 denied:=false;begin perform public.bj_school_staff_grant(s,learner,'teacher');exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL teacher grants staff';end if;
 r:=public.bj_school_dashboard();if jsonb_array_length(r->'schools'->0->'classes')<>1 or r->'schools'->0->'staff'<>'[]' then raise exception 'FAIL teacher scope';end if;
 perform set_config('request.jwt.claim.sub',o::text,true);perform public.bj_school_class_attach(s,(c->>'id')::uuid);r:=public.bj_school_dashboard();
 if jsonb_array_length(r->'schools'->0->'classes')<>2 then raise exception 'FAIL owner association';end if;
 if (r::text) like '%join_code%' or (r::text) like '%score%' or (r::text) like '%email%' then raise exception 'FAIL excess private data';end if;
 perform set_config('request.jwt.claim.sub',m::text,true);r:=public.bj_school_dashboard();if jsonb_array_length(r->'schools'->0->'classes')<>2 then raise exception 'FAIL accepted manager metadata';end if;
 denied:=false;begin perform public.bj_class_roster((other->>'id')::uuid);exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL manager gets student roster';end if;
 denied:=false;begin perform public.bj_publish((other->>'id')::uuid,'No privilege','[{"type":"tf","text":"Test","correct":true}]');exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL manager gets assignment ownership';end if;
 if (public.bj_dashboard()->>'admin')::boolean then raise exception 'FAIL school role platform admin';end if;
 denied:=false;begin perform public.bj_school_staff_remove(s,gen_random_uuid());exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL manager absent-role default';end if;perform public.bj_school_staff_remove(s,t);r:=public.bj_school_dashboard();if jsonb_array_length(r->'schools'->0->'classes')<>1 then raise exception 'FAIL removal leaves association';end if;
 perform set_config('request.jwt.claim.sub',t::text,true);r:=public.bj_school_dashboard();if r->'schools'<>'[]' then raise exception 'FAIL removed staff visibility';end if;
 -- Class itself and its original ownership survive staff removal.
 perform public.bj_publish((other->>'id')::uuid,'Class retained','[{"type":"tf","text":"Still owned","correct":true}]');
 perform set_config('request.jwt.claim.sub',o::text,true);perform public.bj_school_staff_grant(s,m,'teacher');
 perform set_config('request.jwt.claim.sub',m::text,true);r:=public.bj_school_dashboard();if r->'schools'->0->>'accepted'<>'false' then raise exception 'FAIL changed role kept acceptance';end if;
 denied:=false;begin perform public.bj_school_staff_accept(s,'manager');exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL stale role accepted';end if;
 perform public.bj_school_staff_accept(s,'teacher');perform public.bj_school_staff_remove(s,m);if public.bj_school_dashboard()->'schools'<>'[]' then raise exception 'FAIL leave failed';end if;
 perform set_config('request.jwt.claim.sub',x::text,true);s2:=public.bj_school_create('Other school');r:=public.bj_school_dashboard();
 if jsonb_array_length(r->'schools')<>2 then raise exception 'FAIL own and pending only';end if;
 denied:=false;begin perform public.bj_school_staff_grant(s,o,'teacher');exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL outsider mutates school';end if;
 perform set_config('request.jwt.claim.sub',learner::text,true);if public.bj_school_dashboard()->'schools'<>'[]' then raise exception 'FAIL outsider reads school';end if;
 denied:=false;begin perform public.bj_school_staff_accept(s,'teacher');exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL self join';end if;
 denied:=false;begin insert into brainjoy.school_staff values(s,learner,'manager',learner,now(),now());exception when insufficient_privilege then denied:=true;end;if not denied then raise exception 'FAIL direct role write';end if;
 perform set_config('request.jwt.claim.sub','',true);denied:=false;begin perform public.bj_school_dashboard();exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL null identity';end if;
 perform set_config('role','none',true);perform set_config('role','anon',true);denied:=false;begin perform public.bj_school_dashboard();exception when insufficient_privilege then denied:=true;end;if not denied then raise exception 'FAIL anonymous execute';end if;
 perform set_config('role','none',true);
end $$;
do $$
declare u uuid:=gen_random_uuid();a uuid;b uuid;c jsonb;denied boolean;
begin
 insert into auth.users values(u);perform set_config('role','authenticated',true);perform set_config('request.jwt.claim.sub',u::text,true);
 a:=public.bj_school_create('One school');b:=public.bj_school_create('Other school');c:=public.bj_create_class('Preserve association');perform public.bj_school_class_attach(a,(c->>'id')::uuid);
 denied:=false;begin perform public.bj_school_class_attach(b,(c->>'id')::uuid);exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL silent cross-school move';end if;
 perform public.bj_school_class_detach(a,(c->>'id')::uuid);perform public.bj_school_class_attach(b,(c->>'id')::uuid);
 denied:=false;begin perform public.bj_school_staff_grant(a,gen_random_uuid(),'teacher');exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL unknown account created';end if;
 denied:=false;begin perform public.bj_school_staff_grant(a,u,'owner');exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL owner role granted';end if;
 perform set_config('role','none',true);
end $$;
rollback;
select 'PASS pending/accepted staff scope, no escalation/self grant/admin/roster/grades, exact-role acceptance, removal/leave, class preservation, direct-table/anon denial; transaction rolled back' result;
