-- Disposable local DB only. Never a real account cycle.
begin;
do $$
declare s uuid:=gen_random_uuid();p uuid:=gen_random_uuid();other uuid:=gen_random_uuid();t uuid:=gen_random_uuid();g uuid;v integer;r jsonb;k text;denied boolean;i integer;
begin
 insert into auth.users(id)values(s),(p),(other),(t);
 perform set_config('role','authenticated',true);perform set_config('request.jwt.claim.sub',s::text,true);
 g:=(public.bj_goal_create('Read and explain a concept',3)->>'id')::uuid;
 r:=public.bj_goal_dashboard();if jsonb_array_length(r->'own')<>1 or r->'own'->0->'shared_with'<>'[]' then raise exception 'FAIL private default';end if;
 denied:=false;begin perform public.bj_goal_share(g,p,true);exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL unapproved parent';end if;
 k:=public.bj_parent_code();perform set_config('request.jwt.claim.sub',p::text,true);perform public.bj_link_parent(k);
 if public.bj_goal_dashboard()->'shared'<>'[]' then raise exception 'FAIL pending sees goal';end if;
 perform set_config('request.jwt.claim.sub',s::text,true);perform public.bj_approve_parent(p);
 perform set_config('request.jwt.claim.sub',p::text,true);if public.bj_goal_dashboard()->'shared'<>'[]' then raise exception 'FAIL old score grant expanded';end if;
 denied:=false;begin perform public.bj_goal_update(g,1,3,false);exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL parent writes goal';end if;
 perform set_config('request.jwt.claim.sub',s::text,true);perform public.bj_goal_share(g,p,true);v:=public.bj_goal_update(g,1,2,false);
 denied:=false;begin perform public.bj_goal_update(g,1,3,false);exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL stale update';end if;
 denied:=false;begin perform public.bj_goal_update(g,v,4,false);exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL excess progress';end if;
 perform set_config('request.jwt.claim.sub',p::text,true);r:=public.bj_goal_dashboard();if jsonb_array_length(r->'shared')<>1 or r->'shared'->0->>'completed'<>'2' then raise exception 'FAIL exact share';end if;
 if r->'shared'->0 ?| array['answers','score','revision','shared_with','parent_id','email'] then raise exception 'FAIL excessive shared fields';end if;
 perform set_config('request.jwt.claim.sub',other::text,true);if public.bj_goal_dashboard()->'shared'<>'[]' or public.bj_goal_dashboard()->'own'<>'[]' then raise exception 'FAIL outsider sees goal';end if;
 denied:=false;begin perform public.bj_goal_share(g,other,true);exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL outsider grants self';end if;
 perform set_config('request.jwt.claim.sub',s::text,true);perform public.bj_unlink_parent(p);
 perform set_config('request.jwt.claim.sub',p::text,true);if public.bj_goal_dashboard()->'shared'<>'[]' then raise exception 'FAIL unlink keeps access';end if;
 perform set_config('request.jwt.claim.sub',s::text,true);k:=public.bj_parent_code();perform set_config('request.jwt.claim.sub',p::text,true);perform public.bj_link_parent(k);perform set_config('request.jwt.claim.sub',s::text,true);perform public.bj_approve_parent(p);
 perform set_config('request.jwt.claim.sub',p::text,true);if public.bj_goal_dashboard()->'shared'<>'[]' then raise exception 'FAIL relink revives share';end if;
 perform set_config('request.jwt.claim.sub',s::text,true);perform public.bj_goal_share(g,p,true);v:=public.bj_goal_update(g,v,2,true);
 perform set_config('request.jwt.claim.sub',p::text,true);if public.bj_goal_dashboard()->'shared'<>'[]' then raise exception 'FAIL archived exposed';end if;
 perform set_config('request.jwt.claim.sub',s::text,true);v:=public.bj_goal_update(g,v,2,false);
 perform set_config('request.jwt.claim.sub',p::text,true);if public.bj_goal_dashboard()->'shared'<>'[]' then raise exception 'FAIL restore revives share';end if;
 perform set_config('request.jwt.claim.sub',s::text,true);perform public.bj_goal_share(g,p,true);perform public.bj_goal_share(g,p,false);
 perform set_config('request.jwt.claim.sub',p::text,true);if public.bj_goal_dashboard()->'shared'<>'[]' then raise exception 'FAIL pergoal revoke';end if;
 perform set_config('request.jwt.claim.sub',t::text,true);denied:=false;begin perform public.bj_goal_update(g,v,0,true);exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL teacher writes';end if;
 denied:=false;begin select jsonb_agg(title)into r from brainjoy.study_goals;exception when insufficient_privilege then denied:=true;end;if not denied then raise exception 'FAIL direct table reads';end if;
 perform set_config('request.jwt.claim.sub',s::text,true);for i in 2..40 loop perform public.bj_goal_create('Goal '||i,1);end loop;
 denied:=false;begin perform public.bj_goal_create('Forty first',1);exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL count bound';end if;
 v:=public.bj_goal_update(g,v,2,true);perform public.bj_goal_create('New goal',1);
 denied:=false;begin perform public.bj_goal_update(g,v,2,false);exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL restore bypasses count bound';end if;
 perform set_config('request.jwt.claim.sub','',true);denied:=false;begin perform public.bj_goal_dashboard();exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL null identity';end if;
 perform set_config('role','none',true);perform set_config('role','anon',true);denied:=false;begin perform public.bj_goal_dashboard();exception when insufficient_privilege then denied:=true;end;if not denied then raise exception 'FAIL anon';end if;perform set_config('role','none',true);
end $$;
do $$
declare u uuid:=gen_random_uuid();g uuid;i integer;denied boolean;
begin
 insert into auth.users values(u);perform set_config('role','authenticated',true);perform set_config('request.jwt.claim.sub',u::text,true);
 for i in 1..200 loop g:=(public.bj_goal_create('Bounded archive',1)->>'id')::uuid;perform public.bj_goal_update(g,1,0,true);end loop;
 denied:=false;begin perform public.bj_goal_create('Over stored limit',1);exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL stored200limit';end if;
 perform set_config('role','none',true);
end $$;
rollback;
select 'PASS private/student-owned goals, exact per-goal+current-link read, no automatic score-scope expansion, parent/teacher/outsider write denial, unlink/relink/archive/restore revoke, bounds/stale edits/table/anon denial; fixtures rolled back' result;
