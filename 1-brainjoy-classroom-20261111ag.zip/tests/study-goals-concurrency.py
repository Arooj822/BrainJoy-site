"""Disposable local PostgreSQL ONLY. Set BJ_GOALS_LOCAL_DB to a local disposable database.
Never accepts a host/network connection; no actual provider accounts used.
"""
import os,subprocess,json,uuid,concurrent.futures
DB=os.environ.get('BJ_GOALS_LOCAL_DB','bj_goals_20261111')
if not DB.startswith('bj_goals_'):raise SystemExit('Use a disposable bj_goals_ local database only')
def sql(text,check=True):
 return subprocess.run(['psql','-X','-v','ON_ERROR_STOP=1','-h','/tmp','-p','55432','-d',DB,'-At','-f','-'],input=text,capture_output=True,text=True,check=check)
u=str(uuid.uuid4())
try:
 sql(f"insert into auth.users(id)values('{u}')")
 g=sql(f"begin;set local role authenticated;select set_config('request.jwt.claim.sub','{u}',true);select public.bj_goal_create('Concurrent synthetic goal',3)->>'id';commit;").stdout.splitlines()[-2]
 uuid.UUID(g)
 def update(count):return sql(f"begin;set local role authenticated;select set_config('request.jwt.claim.sub','{u}',true);select public.bj_goal_update('{g}',1,{count},false);select pg_sleep(0.1);commit;",False)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:results=list(pool.map(update,[1,2]))
 assert sum(r.returncode==0 for r in results)==1,[(r.returncode,r.stderr)for r in results]
 assert any('Goal changed' in r.stderr for r in results if r.returncode),[r.stderr for r in results]
 row=sql(f"select revision,completed from brainjoy.study_goals where id='{g}'").stdout.strip().split('|');assert row[0]=='2'and row[1]in['1','2'],row
 # Fill39additional active slots, then race two creates for the last remaining slot after archiving.
 sql(f"begin;set local role authenticated;select set_config('request.jwt.claim.sub','{u}',true);do $$begin for i in 1..38 loop perform public.bj_goal_create('Bounded synthetic goal',1);end loop;end $$;commit;")
 def create(_):return sql(f"begin;set local role authenticated;select set_config('request.jwt.claim.sub','{u}',true);select public.bj_goal_create('Race last slot',1);select pg_sleep(0.1);commit;",False)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:results=list(pool.map(create,[1,2]))
 assert sum(r.returncode==0 for r in results)==1,[(r.returncode,r.stderr)for r in results]
 assert sql(f"select count(*)from brainjoy.study_goals where student_id='{u}'and not archived").stdout.strip()=='40'
 print('PASS local concurrent revision edits: exactly one wins; concurrent final-slot creates: active40limit retained')
finally:
 sql(f"delete from brainjoy.goal_shares where goal_id in(select id from brainjoy.study_goals where student_id='{u}');delete from brainjoy.study_goals where student_id='{u}';delete from auth.users where id='{u}';",False)
