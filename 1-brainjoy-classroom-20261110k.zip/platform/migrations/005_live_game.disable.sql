-- Read-only emergency disable. Retains all game/class/user data.
begin;
revoke execute on function public.bj_live_can_read(uuid),public.bj_live_create(uuid,int),public.bj_live_join(text,text),public.bj_live_control(uuid,text),public.bj_live_answer(uuid,int,jsonb),public.bj_live_state(uuid) from authenticated,anon,public;
revoke select on public.bj_live_signals from authenticated,anon,public;
alter publication supabase_realtime drop table public.bj_live_signals;
commit;
