-- Disposable LOCAL database only, after 002 + 005. All identities/records rolled back.
\set ON_ERROR_STOP on
begin;
insert into auth.users(id) values('11111111-1111-4111-8111-111111111111'),('22222222-2222-4222-8222-222222222222'),('33333333-3333-4333-8333-333333333333'),('44444444-4444-4444-8444-444444444444');
create function public.live_assert(ok boolean,msg text) returns void language plpgsql as $$begin if ok is distinct from true then raise exception 'FAIL: %',msg;end if;end$$;
create function public.live_deny(stmt text) returns void language plpgsql as $$begin begin execute stmt;exception when others then return;end;raise exception 'FAIL: allowed %',stmt;end$$;
set local role authenticated;
select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
select public.bj_create_class('Local synthetic game') as c \gset
select (:'c'::jsonb->>'id') as cid \gset
select public.bj_publish(:'cid','Local original questions','[{"type":"mcq","text":"Water?","options":["H2O","CO2"],"correct":0},{"type":"tf","text":"True?","correct":true},{"type":"short","text":"Unit?","answer":"mol"}]') as aid \gset
select public.bj_live_create(:'aid',30) as game \gset
select (:'game'::jsonb->>'id') as sid,(:'game'::jsonb->>'code') as code \gset
select public.live_assert((public.bj_live_state(:'sid')->>'host')::boolean,'teacher is host');
select public.live_assert(public.bj_live_state(:'sid')->'question'='null'::jsonb,'no question in lobby');
select public.live_assert((select count(*) from public.bj_live_signals)=1,'host signal access');
select set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
select public.live_assert((select count(*) from public.bj_live_signals)=0,'outsider signal RLS');
select public.live_deny(format('select public.bj_live_state(%L)',:'sid'));
select public.live_deny(format('select public.bj_live_control(%L,%L)',:'sid','start'));
select public.live_deny(format('select public.bj_live_create(%L,30)',:'aid'));
select public.bj_live_join(:'code','Comet');
select public.live_assert((select count(*) from public.bj_live_signals)=1,'member signal access');
select public.live_assert(public.bj_live_state(:'sid')->>'code' is null,'member cannot reshare code from state');
select public.live_assert(public.bj_live_state(:'sid')->'scores' is null,'no member lobby scoreboard');
select public.live_deny(format('select public.bj_live_answer(%L,0,%L)',:'sid','0'));
select public.live_deny('select * from brainjoy.live_answers');
select public.live_deny('update public.bj_live_signals set revision=1');
select public.live_deny('insert into public.bj_live_signals values(gen_random_uuid(),1)');
select set_config('request.jwt.claim.sub','33333333-3333-4333-8333-333333333333',true);
select public.live_deny(format('select public.bj_live_join(%L,%L)',:'code','comet'));
select public.bj_live_join(:'code','Orbit');
select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
select public.bj_live_control(:'sid','start');
select public.live_assert((public.bj_live_state(:'sid')->>'response_count')::int=0,'starts empty');
select set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
select public.live_assert((public.bj_live_state(:'sid')->'question') ? 'correct'=false,'no MCQ key');
select public.live_assert(public.bj_live_state(:'sid')->'answer_key'='null'::jsonb,'key hidden during question');
select public.live_assert(public.bj_live_state(:'sid')->'scores' is null,'no correctness oracle scoreboard');
select public.live_deny(format('select public.bj_live_answer(%L,0,%L)',:'sid','9'));
select public.live_deny(format('select public.bj_live_answer(%L,0,%L)',:'sid','true'));
select public.live_deny(format('select public.bj_live_answer(%L,0,null)',:'sid'));
select public.bj_live_answer(:'sid',0,'0');
select public.bj_live_answer(:'sid',0,'1');
select public.live_assert((public.bj_live_state(:'sid')->>'submitted')::boolean,'submission exists');
select public.live_assert((public.bj_live_state(:'sid')->>'response_count')::int=1,'duplicate not counted');
select public.live_assert(public.bj_live_state(:'sid')->'scores' is null,'still no oracle after submit');
select set_config('request.jwt.claim.sub','44444444-4444-4444-8444-444444444444',true);
select public.live_deny(format('select public.bj_live_join(%L,%L)',:'code','Late'));
select public.live_deny(format('select public.bj_live_answer(%L,0,%L)',:'sid','0'));
select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
select public.live_deny(format('select public.bj_live_control(%L,%L)',:'sid','next'));
select public.bj_live_control(:'sid','reveal');
select set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
select public.live_assert(public.bj_live_state(:'sid')->>'answer_key'='H2O','revealed key correct');
select public.live_assert((public.bj_live_state(:'sid')->'scores'->0->>'points')::int=1,'first answer unchanged');
select public.live_deny(format('select public.bj_live_answer(%L,0,%L)',:'sid','0'));
select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
select public.bj_live_control(:'sid','next');
select set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
select public.live_deny(format('select public.bj_live_answer(%L,0,%L)',:'sid','0'));
select public.live_deny(format('select public.bj_live_answer(%L,1,%L)',:'sid','"true"'));
select public.bj_live_answer(:'sid',1,'true');
select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
select public.bj_live_control(:'sid','reveal');
select public.bj_live_control(:'sid','next');
select set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
select public.live_assert((public.bj_live_state(:'sid')->'question') ? 'answer'=false,'no short key');
select public.live_deny(format('select public.bj_live_answer(%L,2,%L)',:'sid','"  "'));
select public.bj_live_answer(:'sid',2,'" MOL "');
select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
select public.bj_live_control(:'sid','reveal');
select public.bj_live_control(:'sid','next');
select public.live_assert(public.bj_live_state(:'sid')->>'state'='finished','last next finishes');
select public.live_assert((public.bj_live_state(:'sid')->'scores'->0->>'points')::int=3,'server grades all types');
select public.live_deny(format('select public.bj_live_control(%L,%L)',:'sid','start'));
-- A separate question has a server-enforced deadline even before reveal.
select public.bj_live_create(:'aid',10) as timedgame \gset
select (:'timedgame'::jsonb->>'id') as timedid,(:'timedgame'::jsonb->>'code') as timedcode \gset
select set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
select public.bj_live_join(:'timedcode','Timed');
select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
select public.bj_live_control(:'timedid','start');
reset role;
update brainjoy.live_sessions set ends_at=clock_timestamp()-interval '1 second' where id=:'timedid';
set local role authenticated;
select set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
select public.live_deny(format('select public.bj_live_answer(%L,0,%L)',:'timedid','0'));
select public.live_assert(public.bj_live_state(:'timedid')->'answer_key'='null'::jsonb,'deadline does not leak key');
select public.live_deny(format('select public.bj_live_answer(%L,null,%L)',:'timedid','0'));
select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
select public.live_deny(format('select public.bj_live_create(%L,9)',:'aid'));
select public.bj_live_create(:'aid',30);
select public.bj_live_create(:'aid',30);
select public.live_deny(format('select public.bj_live_create(%L,30)',:'aid'));
reset role;
select public.live_assert((select revision>5 from public.bj_live_signals where session_id=:'sid'),'signals change');
update brainjoy.live_sessions set expires_at=now()-interval '1 minute' where id=:'sid';
set local role authenticated;
select public.live_deny(format('select public.bj_live_state(%L)',:'sid'));
select public.live_assert((select count(*) from public.bj_live_signals where session_id=:'sid')=0,'expired signal hidden');
reset role;
select public.live_assert((select count(*) from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='bj_live_signals')=1,'safe signal surface is published');
select public.live_assert((select count(*) from brainjoy.live_answers)=3,'duplicate/late/invalid answers absent');
select public.live_assert((select count(*) from pg_publication_tables where pubname='supabase_realtime' and schemaname='brainjoy')=0,'no private game tables published');
set local role anon;
select public.live_deny(format('select public.bj_live_state(%L)',:'timedid'));
select public.live_deny('select * from public.bj_live_signals');
reset role;
rollback;
\echo 'PASS: host controls, outsider/RLS/direct-write denial, key stripping, no score oracle, nickname collision, one submission, server scoring all types, state gates, signal revision and expiry. LOCAL SQL ONLY; realtime/independent-session integration still unverified.'
