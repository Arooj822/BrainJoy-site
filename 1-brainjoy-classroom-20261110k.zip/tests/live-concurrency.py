"""LOCAL ONLY: requires psycopg2 and an empty installed bj_live_test_* DB on /tmp:55432.
Never connects to a remote host. Fixtures committed for concurrent sessions, then exact-ID cleanup.
"""
import concurrent.futures, json, threading, uuid, sys
import psycopg2
DB=sys.argv[1] if len(sys.argv)>1 else 'bj_live_test_20261110'
assert DB.startswith('bj_live_test_')
ids=[str(uuid.uuid4()) for _ in range(4)]
cls=assignment=game=None

def connection(user=None):
    c=psycopg2.connect(host='/tmp',port=55432,user='sandbox',dbname=DB)
    if user:
        with c.cursor() as q:q.execute('set local role authenticated');q.execute("select set_config('request.jwt.claim.sub',%s,true)",(user,))
    return c

def call(user,sql,args):
    with connection(user) as c:
        with c.cursor() as q:q.execute(sql,args);return q.fetchone()[0]
try:
    with connection() as c:
        with c.cursor() as q:
            for u in ids:q.execute('insert into auth.users(id) values(%s)',(u,))
    cls=call(ids[0],"select public.bj_create_class(%s)",('Synthetic concurrency',))['id']
    assignment=call(ids[0],"select public.bj_publish(%s,%s,%s::jsonb)",(cls,'Concurrency',json.dumps([{'type':'tf','text':'Synthetic true','correct':True}])))
    created=call(ids[0],'select public.bj_live_create(%s,300)',(assignment,));game=created['id'];code=created['code']
    barrier=threading.Barrier(2)
    def join(i):
        barrier.wait()
        try:return call(ids[i],'select public.bj_live_join(%s,%s)',(code,'Same' if i==1 else 'same'))
        except psycopg2.Error:return None
    with concurrent.futures.ThreadPoolExecutor(2) as pool:joined=list(pool.map(join,[1,2]))
    assert sum(x is not None for x in joined)==1,'nickname race'
    player=ids[1 if joined[0] else 2]
    call(ids[0],'select public.bj_live_control(%s,%s)',(game,'start'))
    barrier=threading.Barrier(10)
    def answer(i):
        barrier.wait();return call(player,'select public.bj_live_answer(%s,0,%s::jsonb)',(game,json.dumps(i%2==0)))
    with concurrent.futures.ThreadPoolExecutor(10) as pool:assert all(pool.map(answer,range(10)))
    with connection() as c:
        with c.cursor() as q:
            q.execute('select count(*),count(distinct answer::text) from brainjoy.live_answers where session_id=%s',(game,));assert q.fetchone()==(1,1),'duplicate race'
    call(ids[0],'select public.bj_live_control(%s,%s)',(game,'reveal'))
    state=call(player,'select public.bj_live_state(%s)',(game,));assert state['response_count']==1 and state['scores'][0]['points'] in [0,1]
    print('PASS: independent LOCAL DB sessions serialize case-insensitive nickname collision and 10 simultaneous competing answers; exactly one immutable answer and one response. Not live auth/realtime verification.')
finally:
    with connection() as c:
        with c.cursor() as q:
            if game:
                for table in ['live_answers','live_members']:q.execute('delete from brainjoy.'+table+' where session_id=%s',(game,))
                q.execute('delete from public.bj_live_signals where session_id=%s',(game,));q.execute('delete from brainjoy.live_sessions where id=%s',(game,))
            if assignment:q.execute('delete from brainjoy.assignments where id=%s',(assignment,))
            if cls:q.execute('delete from brainjoy.classes where id=%s',(cls,))
            for u in ids:q.execute('delete from auth.users where id=%s',(u,))
    with connection() as c:
        with c.cursor() as q:
            q.execute('select count(*) from auth.users where id=any(%s::uuid[])',(ids,));assert q.fetchone()[0]==0
    print('PASS: exact-created LOCAL fixtures removed and identity read-back zero.')
