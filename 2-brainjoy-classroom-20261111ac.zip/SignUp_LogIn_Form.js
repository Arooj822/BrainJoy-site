// Account entry has moved to the permission-checked classroom.
if(!document.querySelector('script[src="legacy-entry.js"]')){const s=document.createElement('script');s.src='legacy-entry.js';s.dataset.entry='auth';document.body.append(s);}
