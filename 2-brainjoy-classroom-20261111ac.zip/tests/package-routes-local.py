"""Check actual extracted static candidate routes. Set BRAINJOY_TEST_ROOT to extracted candidate; no account/backend requests allowed. Requires requests and websocket-client with local Chrome."""
from pathlib import Path
import tempfile,subprocess,time,json,base64,requests,websocket
namespace={'__file__':str(Path(__file__).resolve().with_name('run-local.py'))}
exec(Path(namespace['__file__']).read_text().split('failed=[]')[0],namespace)
server=namespace['server'];port=server.server_port
with tempfile.TemporaryDirectory(prefix='bj-cdp-') as profile:
 proc=subprocess.Popen(['google-chrome','--headless','--no-sandbox','--disable-gpu','--disable-dev-shm-usage','--no-proxy-server','--remote-debugging-port=0','--remote-allow-origins=*','--user-data-dir='+profile],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  for i in range(100):
   p=Path(profile)/'DevToolsActivePort'
   if p.exists():break
   time.sleep(.05)
  debug=p.read_text().splitlines()[0];tab=requests.put('http://127.0.0.1:'+debug+'/json/new?about:blank').json();ws=websocket.create_connection(tab['webSocketDebuggerUrl']);n=0
  def cmd(method,params={}):
   global n;n+=1;ws.send(json.dumps({'id':n,'method':method,'params':params}))
   while True:
    r=json.loads(ws.recv())
    if r.get('id')==n:
     if 'error' in r:raise RuntimeError(r['error'])
     return r.get('result',{})
  def js(s):return cmd('Runtime.evaluate',{'expression':s,'returnByValue':True})['result'].get('value')
  def key(k,code):
   cmd('Input.dispatchKeyEvent',{'type':'keyDown','key':k,'code':code,'windowsVirtualKeyCode':{'Tab':9,'Enter':13,'Escape':27}[k]})
   if k=='Enter':cmd('Input.dispatchKeyEvent',{'type':'char','text':'\r','key':'Enter','windowsVirtualKeyCode':13})
   cmd('Input.dispatchKeyEvent',{'type':'keyUp','key':k,'code':code,'windowsVirtualKeyCode':{'Tab':9,'Enter':13,'Escape':27}[k]})
  def tab_to(id):
   for i in range(180):
    if js('document.activeElement.id')==id:return
    key('Tab','Tab')
   raise RuntimeError('Not keyboard reachable: '+id)
  def go(page):
   cmd('Page.navigate',{'url':f'http://127.0.0.1:{port}/'+page})
   for i in range(200):
    if js("document.readyState==='complete'"):break
    time.sleep(.025)
   time.sleep(.1)
  import zipfile
  pages=[n for n in zipfile.ZipFile('/tmp/brainjoy-site-candidate.zip').namelist() if n.endswith('.html')]
  cmd('Page.enable',{})
  cmd('Page.addScriptToEvaluateOnNewDocument',{'source':"window.__pageErrors=[];window.__externalCalls=[];addEventListener('error',e=>__pageErrors.push(e.message));addEventListener('unhandledrejection',e=>__pageErrors.push(String(e.reason)));const realFetch=fetch;window.fetch=(u,o)=>{const url=new URL(u,location.href);if(url.origin!==location.origin){__externalCalls.push(url.origin);return Promise.reject(Error('External request blocked in package acceptance'));}return realFetch(u,o);};"})
  cmd('Network.enable',{})
  cmd('Network.setBlockedURLs',{'urls':['*supabase.co*','*generativelanguage.googleapis.com*']})
  results=[]
  for page in pages:
   cmd('Emulation.setDeviceMetricsOverride',{'width':390,'height':900,'deviceScaleFactor':1,'mobile':True})
   go(page)
   item=js("({path:location.pathname,errors:window.__pageErrors,calls:window.__externalCalls,width:innerWidth,doc:document.documentElement.scrollWidth,empty:document.body.innerText.trim().length<20})")
   results.append(item)
  if any(x['errors'] or x['calls'] or x['empty'] or x['width']>390 or x['doc']>390 for x in results):raise RuntimeError('Package route acceptance failed: '+json.dumps(results))
  print(json.dumps({'pages':len(results),'errors':[x for x in results if x['errors'] or x['calls'] or x['empty']],'overflow':[x for x in results if x['width']>390 or x['doc']>390]},indent=2))
  Path('/tmp/brainjoy-package-route-report.json').write_text(json.dumps(results,indent=2))
  ws.close()
 finally:proc.terminate();proc.wait();time.sleep(.25)
server.shutdown()
