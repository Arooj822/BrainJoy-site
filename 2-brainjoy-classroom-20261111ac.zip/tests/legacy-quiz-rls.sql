-- Run once in the SQL editor only after confirming these synthetic IDs are absent.
-- No email, password, signup, or real student records are used.
begin;
insert into auth.users(id) values ('bbbbbbbb-0000-4000-8000-000000000001'),('bbbbbbbb-0000-4000-8000-000000000002');
insert into public.quizzes(id,title,created_by,questions) values('cccccccc-0000-4000-8000-000000000001','Synthetic RLS check','bbbbbbbb-0000-4000-8000-000000000001','[]');
set local role authenticated;
select set_config('request.jwt.claim.sub','bbbbbbbb-0000-4000-8000-000000000001',true);
do $$begin if (select count(*) from public.quizzes where id='cccccccc-0000-4000-8000-000000000001')<>1 then raise exception 'FAIL owner read'; end if; end$$;
select 'owner_visible' as check_name,count(*) as actual,1 as expected from public.quizzes where id='cccccccc-0000-4000-8000-000000000001';
select set_config('request.jwt.claim.sub','bbbbbbbb-0000-4000-8000-000000000002',true);
select 'other_user_hidden' as check_name,count(*) as actual,0 as expected from public.quizzes where id='cccccccc-0000-4000-8000-000000000001';
do $$begin
 if exists(select 1 from public.quizzes where id='cccccccc-0000-4000-8000-000000000001') then raise exception 'FAIL cross-user read'; end if;
 update public.quizzes set title='Unauthorized' where id='cccccccc-0000-4000-8000-000000000001';
 if found then raise exception 'FAIL cross-user update'; end if;
 begin
  insert into public.quizzes(title,created_by,questions) values('Synthetic mismatch','bbbbbbbb-0000-4000-8000-000000000001','[]');
  raise exception 'FAIL cross-user insert';
 exception when insufficient_privilege then null; end;
end $$;
reset role;
set local role anon;
do $$begin if exists(select 1 from public.quizzes where id='cccccccc-0000-4000-8000-000000000001') then raise exception 'FAIL anonymous read'; end if; end$$;
reset role;
rollback;
select 'rollback_verified' as check_name,(select count(*) from auth.users where id in ('bbbbbbbb-0000-4000-8000-000000000001','bbbbbbbb-0000-4000-8000-000000000002')) as fixture_users,(select count(*) from public.quizzes where id='cccccccc-0000-4000-8000-000000000001') as fixture_quizzes;
