"""Optional real-keyboard smoke check. Requires local Chrome, requests and websocket-client. No accounts or external writes."""
from pathlib import Path
import tempfile,subprocess,time,json,base64,requests,websocket
namespace={'__file__':str(Path(__file__).resolve().with_name('run-local.py'))}
exec(Path(namespace['__file__']).read_text().split('failed=[]')[0],namespace)
server=namespace['server'];port=server.server_port
with tempfile.TemporaryDirectory(prefix='bj-cdp-') as profile:
 proc=subprocess.Popen(['google-chrome','--headless','--no-sandbox','--disable-gpu','--disable-dev-shm-usage','--no-proxy-server','--remote-debugging-port=0','--remote-allow-origins=*','--user-data-dir='+profile],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  for i in range(100):
   p=Path(profile)/'DevToolsActivePort'
   if p.exists():break
   time.sleep(.05)
  debug=p.read_text().splitlines()[0];tab=requests.put('http://127.0.0.1:'+debug+'/json/new?about:blank').json();ws=websocket.create_connection(tab['webSocketDebuggerUrl']);n=0
  def cmd(method,params={}):
   global n;n+=1;ws.send(json.dumps({'id':n,'method':method,'params':params}))
   while True:
    r=json.loads(ws.recv())
    if r.get('id')==n:
     if 'error' in r:raise RuntimeError(r['error'])
     return r.get('result',{})
  def js(s):return cmd('Runtime.evaluate',{'expression':s,'returnByValue':True})['result'].get('value')
  def key(k,code):
   cmd('Input.dispatchKeyEvent',{'type':'keyDown','key':k,'code':code,'windowsVirtualKeyCode':{'Tab':9,'Enter':13,'Escape':27}[k]})
   if k=='Enter':cmd('Input.dispatchKeyEvent',{'type':'char','text':'\r','key':'Enter','windowsVirtualKeyCode':13})
   cmd('Input.dispatchKeyEvent',{'type':'keyUp','key':k,'code':code,'windowsVirtualKeyCode':{'Tab':9,'Enter':13,'Escape':27}[k]})
  def tab_to(id):
   for i in range(180):
    if js('document.activeElement.id')==id:return
    key('Tab','Tab')
   raise RuntimeError('Not keyboard reachable: '+id)
  def go(page):
   cmd('Page.navigate',{'url':f'http://127.0.0.1:{port}/'+page})
   for i in range(200):
    if js("document.readyState==='complete'"):break
    time.sleep(.025)
   time.sleep(.1)
  cmd('Emulation.setDeviceMetricsOverride',{'width':390,'height':900,'deviceScaleFactor':1,'mobile':True})
  go('quiz-builder.html');tab_to('sampleBtn');key('Enter','Enter')
  print('after Enter sample',js("({title:document.getElementById('qTitle').value,focus:document.activeElement.id,msg:document.getElementById('saveMsg').textContent})"));time.sleep(.2)
  assert js("document.getElementById('qTitle').value")== 'Chemistry warm-up'
  tab_to('saveBtn');key('Enter','Enter');time.sleep(.2)
  assert js("document.getElementById('qId').value.startsWith('local-')")
  go('curriculum-guide.html');tab_to('sample');key('Enter','Enter');tab_to('apply');key('Enter','Enter')
  assert js("document.getElementById('steps').children.length")==4
  print('PASS: actual Tab/Enter reaches quiz sample/save and curriculum sample/apply at390px, saves original quiz and applies4step guide, no pointer or scripted click.')
  res=cmd('Page.captureScreenshot',{'format':'png'});Path('/tmp/brainjoy-keyboard-390.png').write_bytes(base64.b64decode(res['data']))
  ws.close()
 finally:proc.terminate();proc.wait()
server.shutdown()
