-- Synthetic identities only. Run in a disposable local database after 002.
\set ON_ERROR_STOP on
begin;
insert into auth.users(id) values ('11111111-1111-4111-8111-111111111111'),('22222222-2222-4222-8222-222222222222'),('33333333-3333-4333-8333-333333333333'),('44444444-4444-4444-8444-444444444444');
create function public.test_assert(ok boolean,msg text) returns void language plpgsql as $$begin if ok is distinct from true then raise exception 'FAIL: %',msg; end if;end$$;
set local role authenticated;
select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
select public.bj_create_class('Chemistry') as c \gset
select (:'c'::jsonb->>'id') as classid, (:'c'::jsonb->>'join_code') as code \gset
select public.bj_publish(:'classid','Warm up','[{"type":"mcq","text":"Water?","options":["H2O","CO2"],"correct":0},{"type":"tf","text":"True?","correct":true},{"type":"short","text":"Unit?","answer":"mol"}]') as aid \gset
select public.test_assert((public.bj_dashboard()->'assignments'->0->>'id')=:'aid','owner sees assignment');
select set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
select public.bj_join_class(:'code');
select public.test_assert((public.bj_get_assignment(:'aid')->'questions'->0) ? 'correct'=false,'no MCQ answer leak');
select public.test_assert((public.bj_get_assignment(:'aid')->'questions'->2) ? 'answer'=false,'no short answer leak');
select public.test_assert((public.bj_submit(:'aid','[0,true," MOL "]')->>'score')::int=3,'server grades correctly');
select public.test_assert((public.bj_submit(:'aid','[1,false,"bad"]')->>'score')::int=3,'resubmit does not alter score');
select public.bj_parent_code() as pcode \gset
select set_config('request.jwt.claim.sub','33333333-3333-4333-8333-333333333333',true);
select public.test_assert(jsonb_array_length(public.bj_dashboard()->'results')=0,'unlinked parent sees no results');
select public.bj_link_parent(:'pcode');
select public.test_assert(jsonb_array_length(public.bj_dashboard()->'results')=0,'request alone shares nothing');
select set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
select public.bj_approve_parent('33333333-3333-4333-8333-333333333333');
select set_config('request.jwt.claim.sub','33333333-3333-4333-8333-333333333333',true);
select public.test_assert(jsonb_array_length(public.bj_dashboard()->'results')=1,'student-approved parent sees result');
select set_config('request.jwt.claim.sub','44444444-4444-4444-8444-444444444444',true);
select public.test_assert(jsonb_array_length(public.bj_dashboard()->'assignments')=0,'outsider sees no assignment');
select public.test_assert((public.bj_dashboard()->>'admin')::boolean=false,'outsider cannot self become admin');
do $$begin
 begin perform public.bj_get_assignment((select id from brainjoy.assignments limit 1)); raise exception 'FAIL: raw tables readable'; exception when insufficient_privilege then null; end;
end$$;
reset role;
select set_config('test.aid',:'aid',true),set_config('test.classid',:'classid',true);
set local role authenticated;
do $$begin
 begin perform public.bj_get_assignment(current_setting('test.aid')::uuid); raise exception 'FAIL: outsider read'; exception when raise_exception then if sqlerrm like 'FAIL:%' then raise; end if; end;
 begin perform public.bj_publish(current_setting('test.classid')::uuid,'Hack','[]'); raise exception 'FAIL: outsider write'; exception when raise_exception then if sqlerrm like 'FAIL:%' then raise; end if; end;
 begin perform public.bj_submit(current_setting('test.aid')::uuid,'[0,true,"mol"]'); raise exception 'FAIL: outsider submit'; exception when raise_exception then if sqlerrm like 'FAIL:%' then raise; end if; end;
end$$;
select set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
select public.bj_unlink_parent('33333333-3333-4333-8333-333333333333');
select set_config('request.jwt.claim.sub','33333333-3333-4333-8333-333333333333',true);
select public.test_assert(jsonb_array_length(public.bj_dashboard()->'results')=0,'unlink revokes parent access');
reset role;
set local role anon;
do $$begin
 begin perform public.bj_dashboard(); raise exception 'FAIL: anon function allowed'; exception when insufficient_privilege then null; end;
end$$;
reset role;
rollback;
\echo 'PASS: server grading, answer hiding, idempotency, parent opt-in/revocation, outsider isolation, no self-admin, no direct table/anon access. Synthetic fixtures rolled back.'
