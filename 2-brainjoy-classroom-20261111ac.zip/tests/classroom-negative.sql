\set ON_ERROR_STOP on
begin;
insert into auth.users values('11111111-1111-4111-8111-111111111111'),('22222222-2222-4222-8222-222222222222'),('33333333-3333-4333-8333-333333333333'),('44444444-4444-4444-8444-444444444444');
create function public.expect_error(stmt text) returns void language plpgsql as $$begin begin execute stmt; exception when others then return; end; raise exception 'FAIL: allowed %',stmt;end$$;
set local role authenticated;
select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
select public.bj_create_class('Test') as c \gset
select (:'c'::jsonb->>'id') as cid,(:'c'::jsonb->>'join_code') as code \gset
select public.bj_publish(:'cid','Test','[{"type":"short","text":"Unit?","answer":"mol"}]') as aid \gset
select public.expect_error(format('select public.bj_publish(%L,%L,null)',:'cid','Bad'));
select public.expect_error(format('select public.bj_publish(%L,%L,%L)',:'cid','Bad','[{}]'));
select public.expect_error(format('select public.bj_publish(%L,%L,%L)',:'cid','Bad','[{"type":"tf","text":"?","correct":"true"}]'));
select public.expect_error(format('select public.bj_publish(%L,%L,%L)',:'cid','Bad','[{"type":"mcq","text":"?","options":["A","a"],"correct":0}]'));
select public.expect_error(format('select public.bj_publish(%L,%L,%L)',:'cid','Bad','[{"type":"short","text":"?","answer":42}]'));
select public.bj_rotate_class_code(:'cid') as newcode \gset
select set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
select public.expect_error(format('select public.bj_join_class(%L)',:'code'));
select public.bj_join_class(:'newcode');
select public.expect_error('select public.bj_admin_summary()');
select public.expect_error(format('select public.bj_submit(%L,null)',:'aid'));
select public.expect_error(format('select public.bj_submit(%L,%L)',:'aid','[]'));
select public.bj_parent_code() as code1 \gset
reset role;
update brainjoy.parent_codes set expires_at=now()-interval '1 minute';
set local role authenticated;
select set_config('request.jwt.claim.sub','33333333-3333-4333-8333-333333333333',true);
select public.expect_error(format('select public.bj_link_parent(%L)',:'code1'));
select set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
select public.bj_parent_code() as code2 \gset
select set_config('request.jwt.claim.sub','33333333-3333-4333-8333-333333333333',true);
select public.bj_link_parent(:'code2');
select public.expect_error(format('select public.bj_link_parent(%L)',:'code2'));
reset role;
update brainjoy.parent_requests set created_at=now()-interval '25 hours';
set local role authenticated;
select set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
select public.expect_error('select public.bj_approve_parent(''33333333-3333-4333-8333-333333333333'')');
select public.bj_parent_code() as code3 \gset
select set_config('request.jwt.claim.sub','33333333-3333-4333-8333-333333333333',true);
select public.bj_link_parent(:'code3');
select set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
select public.bj_reject_parent('33333333-3333-4333-8333-333333333333');
select public.expect_error('select public.bj_approve_parent(''33333333-3333-4333-8333-333333333333'')');
select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
select public.bj_close_assignment(:'aid',true);
select set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
select public.expect_error(format('select public.bj_submit(%L,%L)',:'aid','["mol"]'));
select public.expect_error(format('select public.bj_close_assignment(%L,false)',:'aid'));
reset role;
insert into brainjoy.admins values('11111111-1111-4111-8111-111111111111');
set local role authenticated;
select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
select public.bj_admin_summary();
reset role;
rollback;
\echo 'PASS: malformed/null quiz payloads, invalid answers, duplicate choices, private code rotation, parent single-use/expiry/rejection, closed assignment and admin authorization.'
