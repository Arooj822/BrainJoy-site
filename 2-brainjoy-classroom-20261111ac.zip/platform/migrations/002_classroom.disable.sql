-- Non-destructive rollback: stop client entry points, retain all classroom data.
begin;
revoke execute on function public.bj_create_class(text),public.bj_join_class(text),public.bj_publish(uuid,text,jsonb),public.bj_get_assignment(uuid),public.bj_submit(uuid,jsonb),public.bj_parent_code(),public.bj_link_parent(text),public.bj_unlink_parent(uuid),public.bj_approve_parent(uuid),public.bj_dashboard(),public.bj_close_assignment(uuid,boolean),public.bj_rotate_class_code(uuid),public.bj_reject_parent(uuid),public.bj_admin_summary() from public,anon,authenticated;
commit;
-- Keep frontend config enabled=false. Restore grants only after the failure is understood.
