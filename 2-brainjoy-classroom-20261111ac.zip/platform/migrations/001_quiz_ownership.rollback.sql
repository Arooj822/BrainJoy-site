-- Historical rollback only. This restores the insecure broad policy.
-- Do not apply except as an explicit incident rollback decision.
BEGIN;
ALTER POLICY quizzes_auth_policy ON public.quizzes TO public
  USING (auth.role() = 'authenticated'::text) WITH CHECK (auth.role() = 'authenticated'::text);
COMMIT;
