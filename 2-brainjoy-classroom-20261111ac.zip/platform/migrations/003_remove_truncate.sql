-- Narrow only client TRUNCATE. Preserve SELECT/INSERT/UPDATE/DELETE and all data.
begin;
revoke truncate on public.arenas,public.lesson_plans,public.players,public.profiles,public.quizzes from anon,authenticated;
commit;
