-- Installed 2026-11-11 after collision/source/hosted rollback isolation checks.
-- Read-only owner roster. Do not reapply over an existing function.
begin;
create function public.bj_class_roster(p_class uuid) returns jsonb
language plpgsql security definer set search_path=pg_catalog as $$
declare u uuid:=auth.uid();
begin
 if u is null or not exists(select 1 from brainjoy.classes where id=p_class and owner_id=u) then
  raise exception 'Class not available';
 end if;
 return jsonb_build_object('class_id',p_class,'members',coalesce((
  select jsonb_agg(jsonb_build_object('student_id',m.student_id,'joined_at',m.joined_at,
   'submitted_assignments',coalesce((select jsonb_agg(r.assignment_id order by r.assignment_id)
    from brainjoy.attempts r join brainjoy.assignments a on a.id=r.assignment_id
    where a.class_id=p_class and r.student_id=m.student_id),'[]'::jsonb)) order by m.joined_at,m.student_id)
  from brainjoy.members m where m.class_id=p_class),'[]'::jsonb));
end $$;
revoke all on function public.bj_class_roster(uuid) from public,anon;
grant execute on function public.bj_class_roster(uuid) to authenticated;
commit;
