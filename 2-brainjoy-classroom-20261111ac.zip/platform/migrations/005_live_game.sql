-- Installed on existing hosted project 2026-11-11 after exact-source rollback tests.
-- Public frontend remains disabled. Requires 002 classroom functions/tables.
-- Preflight schema/table/function collisions and publication before applying.
begin;
create table brainjoy.live_sessions(
 id uuid primary key default gen_random_uuid(),owner_id uuid not null references auth.users(id),
 assignment_id uuid not null references brainjoy.assignments(id),title text not null,questions jsonb not null,
 code text unique not null default upper(substr(replace(gen_random_uuid()::text,'-',''),1,12)),
 state text not null default 'lobby' check(state in ('lobby','question','reveal','finished')),
 question_index int not null default 0,seconds int not null check(seconds between 10 and 300),
 ends_at timestamptz,created_at timestamptz not null default now(),expires_at timestamptz not null default now()+interval '8 hours'
);
create table brainjoy.live_members(session_id uuid references brainjoy.live_sessions(id),user_id uuid references auth.users(id),nickname text not null check(length(nickname) between 1 and 40),joined_at timestamptz not null default now(),primary key(session_id,user_id),unique(session_id,nickname));
create table brainjoy.live_answers(session_id uuid,user_id uuid,question_index int not null,answer jsonb not null,correct boolean not null,submitted_at timestamptz not null default now(),primary key(session_id,user_id,question_index),foreign key(session_id,user_id) references brainjoy.live_members(session_id,user_id));
alter table brainjoy.live_sessions enable row level security;
alter table brainjoy.live_members enable row level security;
alter table brainjoy.live_answers enable row level security;
revoke all on brainjoy.live_sessions,brainjoy.live_members,brainjoy.live_answers from public,anon,authenticated;
-- This table contains ONLY IDs/revisions, never a quiz key, code, identity or score.
create table public.bj_live_signals(session_id uuid primary key references brainjoy.live_sessions(id),revision bigint not null default 1);
alter table public.bj_live_signals enable row level security;
revoke all on public.bj_live_signals from public,anon,authenticated;
grant select on public.bj_live_signals to authenticated;
create function public.bj_live_can_read(p_id uuid) returns boolean language sql stable security definer set search_path=pg_catalog as $$
 select auth.uid() is not null and exists(select 1 from brainjoy.live_sessions s where s.id=p_id and s.expires_at>now() and (s.owner_id=auth.uid() or exists(select 1 from brainjoy.live_members m where m.session_id=s.id and m.user_id=auth.uid())))
$$;
create policy bj_live_signals_read on public.bj_live_signals for select to authenticated using(public.bj_live_can_read(session_id));
create function brainjoy.live_touch() returns trigger language plpgsql security definer set search_path=pg_catalog as $$
declare v uuid;
begin
 v:=case when tg_table_name='live_sessions' then (to_jsonb(new)->>'id')::uuid else (to_jsonb(new)->>'session_id')::uuid end;
 insert into public.bj_live_signals(session_id) values(v) on conflict(session_id) do update set revision=public.bj_live_signals.revision+1;return new;
end$$;
create trigger bj_live_session_signal after insert or update on brainjoy.live_sessions for each row execute function brainjoy.live_touch();
create trigger bj_live_member_signal after insert on brainjoy.live_members for each row execute function brainjoy.live_touch();
create trigger bj_live_answer_signal after insert on brainjoy.live_answers for each row execute function brainjoy.live_touch();
create function public.bj_live_create(p_assignment uuid,p_seconds int) returns jsonb language plpgsql security definer set search_path=pg_catalog as $$
declare a brainjoy.assignments;s brainjoy.live_sessions;u uuid:=auth.uid();
begin
 if u is null or p_seconds is null or p_seconds not between 10 and 300 then raise exception 'Use 10 to 300 seconds and sign in';end if;
 perform pg_advisory_xact_lock(hashtextextended(u::text,72));
 select a0.* into a from brainjoy.assignments a0 join brainjoy.classes c on c.id=a0.class_id where a0.id=p_assignment and c.owner_id=u;
 if not found then raise exception 'Owned assignment required';end if;
 if (select count(*) from brainjoy.live_sessions where owner_id=u and expires_at>now() and state<>'finished')>=3 then raise exception 'Finish an existing game before creating another';end if;
 insert into brainjoy.live_sessions(owner_id,assignment_id,title,questions,seconds) values(u,a.id,a.title,a.questions,p_seconds) returning * into s;
 return jsonb_build_object('id',s.id,'code',s.code,'title',s.title);
end$$;
create function public.bj_live_join(p_code text,p_nickname text) returns uuid language plpgsql security definer set search_path=pg_catalog as $$
declare s brainjoy.live_sessions;u uuid:=auth.uid();n text:=trim(p_nickname);
begin
 if u is null or n is null or length(n) not between 1 and 40 then raise exception 'Sign in and use a nickname up to 40 characters';end if;
 select * into s from brainjoy.live_sessions where code=upper(trim(p_code)) and expires_at>now() for update;
 if not found then raise exception 'Game not available';end if;
 if s.owner_id=u then raise exception 'You are the host';end if;
 if exists(select 1 from brainjoy.live_members where session_id=s.id and user_id=u) then return s.id;end if;
 if s.state<>'lobby' then raise exception 'This game has already started';end if;
 if (select count(*) from brainjoy.live_members where session_id=s.id)>=50 then raise exception 'This game is full';end if;
 if exists(select 1 from brainjoy.live_members where session_id=s.id and lower(nickname)=lower(n)) then raise exception 'Choose a different nickname';end if;
 insert into brainjoy.live_members values(s.id,u,n,now());return s.id;
end$$;
create function public.bj_live_control(p_id uuid,p_action text) returns boolean language plpgsql security definer set search_path=pg_catalog as $$
declare s brainjoy.live_sessions;u uuid:=auth.uid();
begin
 select * into s from brainjoy.live_sessions where id=p_id and owner_id=u and expires_at>now() for update;
 if not found then raise exception 'Host access required';end if;
 if p_action='finish' and s.state<>'finished' then update brainjoy.live_sessions set state='finished',ends_at=null where id=p_id;
 elsif p_action='start' and s.state='lobby' then update brainjoy.live_sessions set state='question',ends_at=clock_timestamp()+make_interval(secs=>s.seconds) where id=p_id;
 elsif p_action='reveal' and s.state='question' then update brainjoy.live_sessions set state='reveal',ends_at=null where id=p_id;
 elsif p_action='next' and s.state='reveal' and s.question_index+1<jsonb_array_length(s.questions) then update brainjoy.live_sessions set state='question',question_index=question_index+1,ends_at=clock_timestamp()+make_interval(secs=>s.seconds) where id=p_id;
 elsif p_action='next' and s.state='reveal' then update brainjoy.live_sessions set state='finished',ends_at=null where id=p_id;
 else raise exception 'Action is not available in this game state';end if;return true;
end$$;
create function public.bj_live_answer(p_id uuid,p_question int,p_answer jsonb) returns boolean language plpgsql security definer set search_path=pg_catalog as $$
declare s brainjoy.live_sessions;q jsonb;ok boolean:=false;u uuid:=auth.uid();
begin
 select * into s from brainjoy.live_sessions where id=p_id and expires_at>now() for share;
 if not found or u is null or not exists(select 1 from brainjoy.live_members where session_id=p_id and user_id=u) then raise exception 'Game not available';end if;
 if p_question is null or s.state<>'question' or s.question_index<>p_question or clock_timestamp()>=s.ends_at then raise exception 'Answer window is closed';end if;
 if exists(select 1 from brainjoy.live_answers where session_id=p_id and user_id=u and question_index=p_question) then return true;end if;
 q:=s.questions->p_question;
 if p_answer is null or pg_column_size(p_answer)>3000 then raise exception 'Invalid answer';end if;
 if q->>'type'='mcq' and (jsonb_typeof(p_answer) is distinct from 'number' or (p_answer#>>'{}')!~'^[0-5]$' or (p_answer#>>'{}')::int>=jsonb_array_length(q->'options')) then raise exception 'Choose one listed option';end if;
 if q->>'type'='tf' and jsonb_typeof(p_answer) is distinct from 'boolean' then raise exception 'Choose True or False';end if;
 if q->>'type'='short' and (jsonb_typeof(p_answer) is distinct from 'string' or length(trim(p_answer#>>'{}')) not between 1 and 500) then raise exception 'Enter an answer up to 500 characters';end if;
 ok:=case when q->>'type'='short' then lower(trim(p_answer#>>'{}'))=lower(trim(q->>'answer')) else p_answer=q->'correct' end;
 insert into brainjoy.live_answers values(p_id,u,p_question,p_answer,coalesce(ok,false),clock_timestamp()) on conflict do nothing;
 -- Never return correctness during an active question, including duplicate submissions.
 return true;
end$$;
create function public.bj_live_state(p_id uuid) returns jsonb language plpgsql security definer set search_path=pg_catalog as $$
declare s brainjoy.live_sessions;q jsonb;u uuid:=auth.uid();host boolean;result jsonb;qs jsonb;answer_key jsonb;
begin
 if not public.bj_live_can_read(p_id) then raise exception 'Game not available';end if;
 select * into s from brainjoy.live_sessions where id=p_id;host:=s.owner_id=u;q:=s.questions->s.question_index;
 if s.state in ('question','reveal') then qs:=jsonb_build_object('type',q->>'type','text',q->>'text','options',q->'options');end if;
 if s.state='reveal' then answer_key:=case when q->>'type'='short' then q->'answer' when q->>'type'='tf' then q->'correct' else q->'options'->((q->>'correct')::int) end;end if;
 result:=jsonb_build_object('id',s.id,'title',s.title,'host',host,'code',case when host then s.code end,'state',s.state,'question_index',s.question_index,'question_count',jsonb_array_length(s.questions),'question',qs,'answer_key',answer_key,'ends_at',s.ends_at,'server_now',clock_timestamp(),'expires_at',s.expires_at,'submitted',exists(select 1 from brainjoy.live_answers where session_id=p_id and user_id=u and question_index=s.question_index),'member_count',(select count(*) from brainjoy.live_members where session_id=p_id),'response_count',(select count(*) from brainjoy.live_answers where session_id=p_id and question_index=s.question_index));
 if host or s.state in ('reveal','finished') then result:=result||jsonb_build_object('scores',coalesce((select jsonb_agg(jsonb_build_object('nickname',m.nickname,'points',(select count(*) from brainjoy.live_answers a where a.session_id=p_id and a.user_id=m.user_id and a.correct and (s.state='finished' or a.question_index<=s.question_index)) ) order by m.joined_at) from brainjoy.live_members m where m.session_id=p_id),'[]'::jsonb));end if;
 return result;
end$$;
create function public.bj_live_list() returns jsonb language sql stable security definer set search_path=pg_catalog as $$
 select coalesce(jsonb_agg(jsonb_build_object('id',s.id,'title',s.title,'state',s.state,'host',s.owner_id=auth.uid(),'expires_at',s.expires_at) order by s.created_at desc),'[]'::jsonb)
 from brainjoy.live_sessions s where auth.uid() is not null and s.expires_at>now() and (s.owner_id=auth.uid() or exists(select 1 from brainjoy.live_members m where m.session_id=s.id and m.user_id=auth.uid()))
$$;
revoke all on function public.bj_live_list(),public.bj_live_can_read(uuid),public.bj_live_create(uuid,int),public.bj_live_join(text,text),public.bj_live_control(uuid,text),public.bj_live_answer(uuid,int,jsonb),public.bj_live_state(uuid) from public,anon;
grant execute on function public.bj_live_list(),public.bj_live_can_read(uuid),public.bj_live_create(uuid,int),public.bj_live_join(text,text),public.bj_live_control(uuid,text),public.bj_live_answer(uuid,int,jsonb),public.bj_live_state(uuid) to authenticated;
revoke all on function brainjoy.live_touch() from public,anon,authenticated;
-- Fail closed if realtime publication is missing. Its existence does not prove delivery.
do $$begin if not exists(select 1 from pg_publication where pubname='supabase_realtime') then raise exception 'Supabase realtime publication is required';end if;execute 'alter publication supabase_realtime add table public.bj_live_signals';end$$;
commit;
