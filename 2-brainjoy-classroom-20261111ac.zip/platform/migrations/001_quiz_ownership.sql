-- Preflight verified on 2026-11-10: public.quizzes has 0 rows.
-- created_by UUID has FK to auth.users(id); all tables have RLS enabled.
-- Narrow existing broad ALL-authenticated policy without altering rows/schema.
BEGIN;
ALTER POLICY quizzes_auth_policy ON public.quizzes TO authenticated
  USING ((SELECT auth.uid()) = created_by)
  WITH CHECK ((SELECT auth.uid()) = created_by);
COMMIT;
