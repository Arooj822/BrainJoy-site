-- Bind only established owner email, verified and uniquely matched during preflight.
-- Never use profiles.role or raw_user_meta_data for administrative authority.
insert into brainjoy.admins(user_id)
select id from auth.users where lower(email)='jamesarooj@gmail.com' and email_confirmed_at is not null
and (select count(*) from auth.users where lower(email)='jamesarooj@gmail.com')=1
on conflict do nothing;
