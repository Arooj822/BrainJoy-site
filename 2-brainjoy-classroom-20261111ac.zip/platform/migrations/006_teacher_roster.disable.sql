-- Disable without deleting memberships, attempts or function source.
begin;
revoke all on function public.bj_class_roster(uuid) from public,anon,authenticated;
commit;
