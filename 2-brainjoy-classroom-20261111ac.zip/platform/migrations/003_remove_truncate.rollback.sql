-- Historical grants captured 2026-11-10. Restores the prior privilege only.
grant truncate on public.arenas,public.lesson_plans,public.players,public.profiles,public.quizzes to anon,authenticated;
