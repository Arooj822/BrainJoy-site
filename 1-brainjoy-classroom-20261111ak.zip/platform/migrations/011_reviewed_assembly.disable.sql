begin;
revoke execute on function public.bj_bank_assemble(uuid,uuid,text,jsonb),public.bj_bank_assemblies(uuid)from public,anon,authenticated;
commit;
-- Frozen assignments and scores are retained. Close submissions through the existing owner path if required.
