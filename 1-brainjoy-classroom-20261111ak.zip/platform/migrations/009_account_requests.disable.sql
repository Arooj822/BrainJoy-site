-- Source-only request endpoint close. No records deleted, exported or changed.
begin;
revoke all on function public.bj_request_create(text,text),public.bj_request_cancel(uuid,integer),public.bj_request_status(uuid,integer,text),public.bj_request_dashboard()from public,anon,authenticated;
commit;
