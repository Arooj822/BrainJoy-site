-- Disable only new entry points, retaining revisions, reviews, publications, assignments and scores.
begin;
revoke execute on function public.bj_bank_staff(uuid,uuid,text,boolean),public.bj_bank_accept(uuid,boolean),public.bj_bank_draft(uuid,uuid,integer,jsonb),public.bj_bank_review(uuid,integer,jsonb),public.bj_bank_publish(uuid,integer,text),public.bj_bank_dashboard()from public,anon,authenticated;
commit;
