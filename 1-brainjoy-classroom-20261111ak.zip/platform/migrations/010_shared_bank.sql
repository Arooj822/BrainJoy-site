-- SOURCE ONLY. No live install. Additive, existing classes/assignments and permissions retained.
begin;
create table brainjoy.bank_staff(id uuid primary key default gen_random_uuid(),class_id uuid not null references brainjoy.classes(id),user_id uuid not null references auth.users(id),role text not null check(role in('reviewer','publisher')),accepted boolean not null default false,revoked boolean not null default false,created_at timestamptz not null default now());
create unique index bank_staff_current on brainjoy.bank_staff(class_id,user_id,role) where not revoked;
create table brainjoy.bank_items(id uuid primary key default gen_random_uuid(),class_id uuid not null references brainjoy.classes(id),author_id uuid not null references auth.users(id),latest integer not null default 1);
create table brainjoy.bank_revisions(item_id uuid references brainjoy.bank_items(id),revision integer not null,content jsonb not null,created_at timestamptz not null default now(),primary key(item_id,revision));
create table brainjoy.bank_reviews(item_id uuid,revision integer,reviewer_id uuid not null references auth.users(id),grant_id uuid not null references brainjoy.bank_staff(id),created_at timestamptz not null default now(),primary key(item_id,revision),foreign key(item_id,revision) references brainjoy.bank_revisions(item_id,revision));
create table brainjoy.bank_publications(item_id uuid,revision integer,assignment_id uuid unique not null references brainjoy.assignments(id),publisher_id uuid not null references auth.users(id),title text not null,created_at timestamptz not null default now(),primary key(item_id,revision),foreign key(item_id,revision) references brainjoy.bank_reviews(item_id,revision));
alter table brainjoy.bank_staff enable row level security;alter table brainjoy.bank_items enable row level security;alter table brainjoy.bank_revisions enable row level security;alter table brainjoy.bank_reviews enable row level security;alter table brainjoy.bank_publications enable row level security;
revoke all on brainjoy.bank_staff,brainjoy.bank_items,brainjoy.bank_revisions,brainjoy.bank_reviews,brainjoy.bank_publications from public,anon,authenticated;
create function brainjoy.bank_owner(p_class uuid) returns boolean language sql stable security definer set search_path=pg_catalog as $$select auth.uid() is not null and exists(select 1 from brainjoy.classes where id=p_class and owner_id=auth.uid())$$;
create function brainjoy.bank_role(p_class uuid,p_role text) returns boolean language sql stable security definer set search_path=pg_catalog as $$select auth.uid() is not null and exists(select 1 from brainjoy.bank_staff where class_id=p_class and user_id=auth.uid() and role=p_role and accepted and not revoked)$$;
create function brainjoy.bank_validate(p jsonb) returns void language plpgsql set search_path=pg_catalog as $$
declare k text;v jsonb;
begin
 if jsonb_typeof(p) is distinct from 'object' or pg_column_size(p)>12000 or (select count(*) from jsonb_object_keys(p))<>11 or exists(select 1 from jsonb_object_keys(p) z where z not in('prompt','choices','answer','explanation','topic','prerequisites','audience','alignment','origin','source','rights')) then raise exception 'Invalid draft fields';end if;
 foreach k in array array['prompt','explanation','topic','audience','alignment','origin','source','rights'] loop
 if jsonb_typeof(p->k) is distinct from 'string' or length(trim(p->>k)) not between 1 and (case when k='prompt' then 600 when k='explanation' then 1200 when k='topic' then 60 when k='audience' then 120 when k='alignment' then 160 else 400 end) then raise exception 'Invalid draft text';end if;end loop;
 if p->>'origin' not in('original','imported','generated') or jsonb_typeof(p->'choices') is distinct from 'array' or jsonb_typeof(p->'prerequisites') is distinct from 'array' or jsonb_typeof(p->'answer') is distinct from 'number' or (p->>'answer') !~ '^[0-3]$' then raise exception 'Invalid draft choices';end if;
 if jsonb_array_length(p->'choices') not between 2 and 4 or (p->>'answer')::integer>=jsonb_array_length(p->'choices') or jsonb_array_length(p->'prerequisites')>8 then raise exception 'Invalid draft bounds';end if;
 for v in select value from jsonb_array_elements(p->'choices') loop if jsonb_typeof(v) is distinct from 'string' or length(trim(v#>>'{}')) not between 1 and 200 then raise exception 'Invalid choice';end if;end loop;
 if (select count(distinct lower(trim(value)))from jsonb_array_elements_text(p->'choices'))<>jsonb_array_length(p->'choices') then raise exception 'Duplicate choices';end if;
 for v in select value from jsonb_array_elements(p->'prerequisites') loop if jsonb_typeof(v) is distinct from 'string' or length(trim(v#>>'{}')) not between 1 and 60 then raise exception 'Invalid prerequisite';end if;end loop;
 if (select count(distinct value)from jsonb_array_elements_text(p->'prerequisites'))<>jsonb_array_length(p->'prerequisites')then raise exception 'Duplicate prerequisites';end if;
end $$;
create function public.bj_bank_staff(p_class uuid,p_user uuid,p_role text,p_revoke boolean) returns uuid language plpgsql security definer set search_path=pg_catalog as $$
declare v uuid;begin
 perform 1 from brainjoy.classes where id=p_class for update;
 if not brainjoy.bank_owner(p_class) then raise exception 'Class owner required';end if;
 if p_user is null or p_user=auth.uid() or p_role is null or p_role not in('reviewer','publisher') or p_revoke is null then raise exception 'Invalid exact staff grant';end if;
 if p_revoke then update brainjoy.bank_staff set revoked=true where class_id=p_class and user_id=p_user and role=p_role and not revoked returning id into v;return v;end if;
 select id into v from brainjoy.bank_staff where class_id=p_class and user_id=p_user and role=p_role and not revoked;if found then return v;end if;
 if (select count(*)from brainjoy.bank_staff where class_id=p_class)>=100 or (select count(*)from brainjoy.bank_staff where class_id=p_class and not revoked)>=20 then raise exception 'Staff grant limit';end if;
 insert into brainjoy.bank_staff(class_id,user_id,role)values(p_class,p_user,p_role)returning id into v;return v;
end $$;
create function public.bj_bank_accept(p_grant uuid,p_accept boolean) returns boolean language plpgsql security definer set search_path=pg_catalog as $$
declare c uuid;begin select class_id into c from brainjoy.bank_staff where id=p_grant;perform 1 from brainjoy.classes where id=c for update;
 if auth.uid() is null or p_accept is null then raise exception 'Sign in and choose';end if;
 update brainjoy.bank_staff set accepted=p_accept,revoked=not p_accept where id=p_grant and user_id=auth.uid() and not revoked;
 if not found then raise exception 'Grant unavailable';end if;return true;end $$;
create function public.bj_bank_draft(p_class uuid,p_item uuid,p_expected integer,p_content jsonb) returns jsonb language plpgsql security definer set search_path=pg_catalog as $$
declare i brainjoy.bank_items;v integer;old jsonb;begin
 perform 1 from brainjoy.classes where id=p_class for update;
 if not brainjoy.bank_owner(p_class) then raise exception 'Class owner required to author';end if;
 perform brainjoy.bank_validate(p_content);
 if p_item is null then
 if p_expected is distinct from 0 then raise exception 'New item revision must be zero';end if;
 if (select count(*)from brainjoy.bank_items where class_id=p_class)>=100 then raise exception 'Item limit';end if;
 insert into brainjoy.bank_items(class_id,author_id) values(p_class,auth.uid()) returning * into i;v:=1;
 else
 select * into i from brainjoy.bank_items where id=p_item and class_id=p_class;
 if not found or i.author_id<>auth.uid() then raise exception 'Item unavailable';end if;
 if p_expected is distinct from i.latest then raise exception 'Draft changed';end if;if i.latest>=20 then raise exception 'Revision limit';end if;
 select content into old from brainjoy.bank_revisions where item_id=i.id and revision=i.latest;
 if old->'origin' is distinct from p_content->'origin' or old->'source' is distinct from p_content->'source' then raise exception 'Retain original provenance';end if;
 v:=i.latest+1;update brainjoy.bank_items set latest=v where id=i.id;
 end if;
 insert into brainjoy.bank_revisions(item_id,revision,content)values(i.id,v,p_content);
 return jsonb_build_object('id',i.id,'revision',v);
end $$;
create function public.bj_bank_review(p_item uuid,p_revision integer,p_checks jsonb) returns boolean language plpgsql security definer set search_path=pg_catalog as $$
declare i brainjoy.bank_items;g uuid;begin
 select * into i from brainjoy.bank_items where id=p_item;perform 1 from brainjoy.classes where id=i.class_id for update;
 select * into i from brainjoy.bank_items where id=p_item;
 if auth.uid() is null or i.id is null or i.author_id=auth.uid() or i.latest is distinct from p_revision or not brainjoy.bank_role(i.class_id,'reviewer')then raise exception 'Current independent reviewer required';end if;
 if p_checks is distinct from '{"answer":true,"explanation":true,"rights":true,"audience":true}'::jsonb then raise exception 'Review all four checks';end if;
 select id into g from brainjoy.bank_staff where class_id=i.class_id and user_id=auth.uid() and role='reviewer' and accepted and not revoked;
 -- A revoked review is retained. A replacement review of that same revision needs a new draft, never overwrites history.
 insert into brainjoy.bank_reviews(item_id,revision,reviewer_id,grant_id)values(i.id,p_revision,auth.uid(),g);return true;
end $$;
create function public.bj_bank_publish(p_item uuid,p_revision integer,p_title text) returns uuid language plpgsql security definer set search_path=pg_catalog as $$
declare i brainjoy.bank_items;r brainjoy.bank_reviews;c jsonb;a uuid;begin
 select * into i from brainjoy.bank_items where id=p_item;perform 1 from brainjoy.classes where id=i.class_id for update;
 select * into i from brainjoy.bank_items where id=p_item;
 if auth.uid() is null or i.id is null or not(brainjoy.bank_owner(i.class_id) or brainjoy.bank_role(i.class_id,'publisher'))then raise exception 'Publisher required';end if;
 if p_revision is null or p_title is null or length(trim(p_title))not between 1 and 160 then raise exception 'Invalid publication';end if;
 select assignment_id into a from brainjoy.bank_publications where item_id=p_item and revision=p_revision;if found then return a;end if;
 if i.latest is distinct from p_revision then raise exception 'Draft changed';end if;
 select * into r from brainjoy.bank_reviews where item_id=p_item and revision=p_revision;
 if not found or not exists(select 1 from brainjoy.bank_staff where id=r.grant_id and accepted and not revoked and role='reviewer' and class_id=i.class_id and user_id=r.reviewer_id)then raise exception 'Current independent review required';end if;
 select content into c from brainjoy.bank_revisions where item_id=p_item and revision=p_revision;
 insert into brainjoy.assignments(class_id,title,questions) values(i.class_id,trim(p_title),jsonb_build_array(jsonb_build_object('type','mcq','text',c->>'prompt','options',c->'choices','correct',c->'answer'))) returning id into a;
 insert into brainjoy.bank_publications(item_id,revision,assignment_id,publisher_id,title)values(p_item,p_revision,a,auth.uid(),trim(p_title));return a;
end $$;
create function public.bj_bank_dashboard() returns jsonb language plpgsql security definer set search_path=pg_catalog as $$
declare u uuid:=auth.uid();begin if u is null then raise exception 'Sign in first';end if;
 return jsonb_build_object(
 'classes',coalesce((select jsonb_agg(jsonb_build_object('id',c.id,'title',c.title,'owner',c.owner_id=u,'reviewer',brainjoy.bank_role(c.id,'reviewer'),'publisher',brainjoy.bank_role(c.id,'publisher')))from brainjoy.classes c where c.owner_id=u or exists(select 1 from brainjoy.bank_staff s where s.class_id=c.id and s.user_id=u and s.accepted and not s.revoked)),'[]'::jsonb),
 'grants',coalesce((select jsonb_agg(jsonb_build_object('id',s.id,'class_id',s.class_id,'user_id',s.user_id,'role',s.role,'accepted',s.accepted,'mine',s.user_id=u))from brainjoy.bank_staff s join brainjoy.classes c on c.id=s.class_id where not s.revoked and (c.owner_id=u or s.user_id=u)),'[]'::jsonb),
 'items',coalesce((select jsonb_agg(jsonb_build_object('id',i.id,'class_id',i.class_id,'latest',i.latest,'revisions',(select jsonb_agg(jsonb_build_object('revision',v.revision,'content',v.content,'reviewed',exists(select 1 from brainjoy.bank_reviews r join brainjoy.bank_staff s on s.id=r.grant_id where r.item_id=v.item_id and r.revision=v.revision and s.accepted and not s.revoked),'review_recorded',exists(select 1 from brainjoy.bank_reviews r where r.item_id=v.item_id and r.revision=v.revision),'assignment_id',(select assignment_id from brainjoy.bank_publications p where p.item_id=v.item_id and p.revision=v.revision))order by v.revision)from brainjoy.bank_revisions v where v.item_id=i.id)))from brainjoy.bank_items i where exists(select 1 from brainjoy.classes c where c.id=i.class_id and c.owner_id=u) or brainjoy.bank_role(i.class_id,'reviewer') or brainjoy.bank_role(i.class_id,'publisher')),'[]'::jsonb));end $$;
revoke all on function brainjoy.bank_owner(uuid),brainjoy.bank_role(uuid,text),brainjoy.bank_validate(jsonb)from public,anon,authenticated;
revoke all on function public.bj_bank_staff(uuid,uuid,text,boolean),public.bj_bank_accept(uuid,boolean),public.bj_bank_draft(uuid,uuid,integer,jsonb),public.bj_bank_review(uuid,integer,jsonb),public.bj_bank_publish(uuid,integer,text),public.bj_bank_dashboard()from public,anon;
grant execute on function public.bj_bank_staff(uuid,uuid,text,boolean),public.bj_bank_accept(uuid,boolean),public.bj_bank_draft(uuid,uuid,integer,jsonb),public.bj_bank_review(uuid,integer,jsonb),public.bj_bank_publish(uuid,integer,text),public.bj_bank_dashboard()to authenticated;
commit;
