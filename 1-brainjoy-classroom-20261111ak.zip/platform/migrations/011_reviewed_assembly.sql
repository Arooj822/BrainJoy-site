-- SOURCE ONLY. Requires source010. No live application authorized.
begin;
create table brainjoy.bank_assemblies(id uuid primary key,class_id uuid not null references brainjoy.classes(id),title text not null,selection jsonb not null,assignment_id uuid unique not null references brainjoy.assignments(id),publisher_id uuid not null references auth.users(id),created_at timestamptz not null default now());
create table brainjoy.bank_assembly_items(assembly_id uuid references brainjoy.bank_assemblies(id),position integer not null check(position between 1 and 20),item_id uuid not null,revision integer not null,primary key(assembly_id,position),unique(assembly_id,item_id),foreign key(item_id,revision) references brainjoy.bank_reviews(item_id,revision));
alter table brainjoy.bank_assemblies enable row level security;alter table brainjoy.bank_assembly_items enable row level security;
revoke all on brainjoy.bank_assemblies,brainjoy.bank_assembly_items from public,anon,authenticated;
create function public.bj_bank_assemble(p_class uuid,p_request uuid,p_title text,p_selection jsonb) returns uuid language plpgsql security definer set search_path=pg_catalog as $$
declare old brainjoy.bank_assemblies;i brainjoy.bank_items;r brainjoy.bank_reviews;entry jsonb;c jsonb;qs jsonb:='[]';a uuid;pos integer:=0;v integer;v_item uuid;
begin
 perform 1 from brainjoy.classes where id=p_class for update;
 if auth.uid() is null or not(brainjoy.bank_owner(p_class) or brainjoy.bank_role(p_class,'publisher'))then raise exception 'Class publisher required';end if;
 if p_request is null or p_title is null or length(trim(p_title))not between 1 and 160 or jsonb_typeof(p_selection)is distinct from 'array' or pg_column_size(p_selection)>8000 then raise exception 'Invalid assembly';end if;
 if jsonb_array_length(p_selection)not between 1 and 20 then raise exception 'Select 1 to 20 reviewed questions';end if;
 -- Request identity binds exact actor/class/title/ordered revisions. A timeout retry returns the original receipt.
 select * into old from brainjoy.bank_assemblies where id=p_request;
 if found then
 if old.class_id<>p_class or old.publisher_id<>auth.uid() or old.title<>trim(p_title) or old.selection<>p_selection then raise exception 'Publication request already used with different contents';end if;
 return old.assignment_id;end if;
 if(select count(*)from brainjoy.bank_assemblies where class_id=p_class)>=100 then raise exception 'Assembly limit: 100 per class';end if;
 for entry in select value from jsonb_array_elements(p_selection) loop
 if jsonb_typeof(entry)is distinct from 'object' or (select count(*)from jsonb_object_keys(entry))<>2 or not(entry?'id' and entry?'revision') or exists(select 1 from jsonb_object_keys(entry)k where k not in('id','revision')) or jsonb_typeof(entry->'id')is distinct from 'string' or (entry->>'id')!~'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' or jsonb_typeof(entry->'revision')is distinct from 'number' or (entry->>'revision')!~'^([1-9]|1[0-9]|20)$' then raise exception 'Invalid exact revision selection';end if;
 v_item:=(entry->>'id')::uuid;v:=(entry->>'revision')::integer;
 if(select count(*)from jsonb_array_elements(p_selection)x where lower(x->>'id')=lower(entry->>'id'))<>1 then raise exception 'Duplicate item';end if;
 select * into i from brainjoy.bank_items where bank_items.id=v_item and class_id=p_class;
 if not found or i.latest<>v then raise exception 'Selected draft changed or is unavailable';end if;
 select * into r from brainjoy.bank_reviews where item_id=v_item and revision=v;
 if not found or r.reviewer_id=i.author_id or not exists(select 1 from brainjoy.bank_staff s where s.id=r.grant_id and s.accepted and not s.revoked and s.role='reviewer' and s.class_id=p_class and s.user_id=r.reviewer_id)then raise exception 'Selected revision needs current independent review';end if;
 select content into c from brainjoy.bank_revisions where item_id=v_item and revision=v;
 qs:=qs||jsonb_build_array(jsonb_build_object('type','mcq','text',c->>'prompt','options',c->'choices','correct',c->'answer'));
 end loop;
 insert into brainjoy.assignments(class_id,title,questions)values(p_class,trim(p_title),qs)returning assignments.id into a;
 insert into brainjoy.bank_assemblies(id,class_id,title,selection,assignment_id,publisher_id)values(p_request,p_class,trim(p_title),p_selection,a,auth.uid());
 for entry in select value from jsonb_array_elements(p_selection)loop pos:=pos+1;insert into brainjoy.bank_assembly_items values(p_request,pos,(entry->>'id')::uuid,(entry->>'revision')::integer);end loop;
 return a;
end $$;
create function public.bj_bank_assemblies(p_class uuid)returns jsonb language plpgsql security definer set search_path=pg_catalog as $$
begin if auth.uid()is null or not(brainjoy.bank_owner(p_class) or brainjoy.bank_role(p_class,'publisher'))then raise exception 'Class publisher required';end if;
 return coalesce((select jsonb_agg(jsonb_build_object('request_id',id,'assignment_id',assignment_id,'title',title,'selection',selection,'created_at',created_at)order by created_at)from brainjoy.bank_assemblies where class_id=p_class),'[]'::jsonb);end $$;
revoke all on function public.bj_bank_assemble(uuid,uuid,text,jsonb),public.bj_bank_assemblies(uuid)from public,anon;
grant execute on function public.bj_bank_assemble(uuid,uuid,text,jsonb),public.bj_bank_assemblies(uuid)to authenticated;
commit;
