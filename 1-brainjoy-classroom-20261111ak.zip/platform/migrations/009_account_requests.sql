-- SOURCE ONLY. NOT INSTALLED. Requests/status only: no exports, deletion, notifications or policy decisions.
begin;
create table brainjoy.account_requests(id uuid primary key default gen_random_uuid(),requester_id uuid not null references auth.users(id),kind text not null check(kind in ('export','removal','account_help')),category text not null check(category in ('account_data','account_access','sharing','technical')),status text not null default 'submitted' check(status in ('submitted','reviewing','needs_owner_decision','closed_without_action','cancelled')),revision integer not null default 1,created_at timestamptz not null default now(),updated_at timestamptz not null default now(),check((kind in ('export','removal')and category='account_data')or(kind='account_help'and category in ('account_access','sharing','technical'))));
create table brainjoy.account_request_events(request_id uuid not null references brainjoy.account_requests(id),revision integer not null,status text not null,actor_id uuid not null references auth.users(id),created_at timestamptz not null default now(),primary key(request_id,revision));
alter table brainjoy.account_requests enable row level security;alter table brainjoy.account_request_events enable row level security;
revoke all on brainjoy.account_requests,brainjoy.account_request_events from public,anon,authenticated;
create function public.bj_request_create(p_kind text,p_category text)returns jsonb language plpgsql security definer set search_path=pg_catalog as $$
declare u uuid:=auth.uid();r brainjoy.account_requests;begin
 if u is null then raise exception 'Sign in first';end if;
 if p_kind is null or p_category is null or not((p_kind in ('export','removal')and p_category='account_data')or(p_kind='account_help'and p_category in ('account_access','sharing','technical')))then raise exception 'Choose a supported request and category';end if;
 perform 1 from auth.users where id=u for update;
 select *into r from brainjoy.account_requests where requester_id=u and kind=p_kind and category=p_category and status not in ('cancelled','closed_without_action')order by created_at limit 1;
 if found then return jsonb_build_object('id',r.id,'already_open',true);end if;
 if(select count(*)from brainjoy.account_requests where requester_id=u)>=200 then raise exception 'Request storage limit reached. No new request was saved';end if;
 insert into brainjoy.account_requests(requester_id,kind,category)values(u,p_kind,p_category)returning *into r;
 insert into brainjoy.account_request_events values(r.id,1,'submitted',u,now());return jsonb_build_object('id',r.id,'already_open',false);
end $$;
create function public.bj_request_cancel(p_id uuid,p_revision integer)returns integer language plpgsql security definer set search_path=pg_catalog as $$
declare u uuid:=auth.uid();r brainjoy.account_requests;begin
 select *into r from brainjoy.account_requests where id=p_id and requester_id=u for update;
 if not found or u is null then raise exception 'Request not available';end if;
 if r.revision is distinct from p_revision then raise exception 'Request changed. Refresh before cancelling';end if;
 if r.status in ('cancelled','closed_without_action')then raise exception 'Request is already closed';end if;
 update brainjoy.account_requests set status='cancelled',revision=revision+1,updated_at=now()where id=r.id returning revision into r.revision;
 insert into brainjoy.account_request_events values(r.id,r.revision,'cancelled',u,now());return r.revision;
end $$;
create function public.bj_request_status(p_id uuid,p_revision integer,p_status text)returns integer language plpgsql security definer set search_path=pg_catalog as $$
declare u uuid:=auth.uid();r brainjoy.account_requests;begin
 -- Existing separately-approved platform membership only. No profile/selected/school role.
 perform 1 from brainjoy.admins where user_id=u for share;
 if not found or u is null then raise exception 'Support administration not available';end if;
 select *into r from brainjoy.account_requests where id=p_id for update;
 if not found or r.requester_id=u then raise exception 'Another account request is required';end if;
 if r.revision is distinct from p_revision then raise exception 'Request changed. Refresh before updating';end if;
 if p_status is null or p_status not in ('reviewing','needs_owner_decision','closed_without_action')or r.status in ('cancelled','closed_without_action')or p_status=r.status then raise exception 'Unsupported request status change';end if;
 update brainjoy.account_requests set status=p_status,revision=revision+1,updated_at=now()where id=r.id returning revision into r.revision;
 insert into brainjoy.account_request_events values(r.id,r.revision,p_status,u,now());return r.revision;
end $$;
create function public.bj_request_dashboard()returns jsonb language plpgsql security definer set search_path=pg_catalog as $$
declare u uuid:=auth.uid();a boolean;begin
 if u is null then raise exception 'Sign in first';end if;
 select exists(select 1 from brainjoy.admins where user_id=u)into a;
 return jsonb_build_object('support_admin',a,
 'own',coalesce((select jsonb_agg(jsonb_build_object('id',r.id,'kind',r.kind,'category',r.category,'status',r.status,'revision',r.revision,'created_at',r.created_at,'updated_at',r.updated_at,
 'history',coalesce((select jsonb_agg(jsonb_build_object('revision',e.revision,'status',e.status,'at',e.created_at,'actor',case when e.actor_id=r.requester_id then 'requester' else 'support_admin' end)order by e.revision)from brainjoy.account_request_events e where e.request_id=r.id),'[]'::jsonb))order by r.created_at desc,r.id)from brainjoy.account_requests r where r.requester_id=u),'[]'::jsonb),
 'queue',case when a then coalesce((select jsonb_agg(jsonb_build_object('id',r.id,'requester_id',r.requester_id,'kind',r.kind,'category',r.category,'status',r.status,'revision',r.revision,'created_at',r.created_at,'updated_at',r.updated_at)order by r.created_at,r.id)from(select *from brainjoy.account_requests where requester_id<>u and status not in ('cancelled','closed_without_action')order by created_at,id limit 100)r),'[]'::jsonb)else '[]'::jsonb end,
 'queue_limit',100,'queue_more',a and(select count(*)from brainjoy.account_requests where requester_id<>u and status not in ('cancelled','closed_without_action'))>100);
end $$;
revoke all on function public.bj_request_create(text,text),public.bj_request_cancel(uuid,integer),public.bj_request_status(uuid,integer,text),public.bj_request_dashboard()from public,anon;
grant execute on function public.bj_request_create(text,text),public.bj_request_cancel(uuid,integer),public.bj_request_status(uuid,integer,text),public.bj_request_dashboard()to authenticated;
commit;
