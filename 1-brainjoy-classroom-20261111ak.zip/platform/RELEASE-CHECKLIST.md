# BrainJoy release checklist

This is a finite release plan, not a claim that the whole requested platform is complete. Keep the existing site and content available until the replacement is accepted. Free tools and private classroom access are different release tracks.

## Track A: free tools, no account or paid provider

- [x] Write/import/export and play three supported question types, clearly distinguishing same-browser practice from cloud assignments.
- [x] Flashcards, worksheet with separate key, timed lesson plan, shared-screen review, classroom timer and picker.
- [x] Original particle mini-unit with separate student and teacher files, safe tool links and practice samples.
- [x] Editable topic-sequence guide with reviewed imports, local-save disclosure, portable backup and print. Not official alignment, mastery or an adaptive tutor.
- [x] Preserve original homepage cards and role buttons with accurate routing and limits.
- [x] Remove legacy mock-login bypass behavior; no role granted by chosen view or profile metadata.
- [x] Repair missing student/teacher entry routes; legacy parent/admin/landing/login do not claim queried metrics or send credentials.
- [x] Package only an explicit static allowlist. No credentials, test sessions, private migration files or development fixtures.
- [x] Automated packaged-page local-link audit, closed access flags and account-route guards.
- [x] Actual mobile/desktop checks of core tools and new sequence; worksheet/resource/sequence print checks.
- [x] Actual-keyboard Tab/Enter smoke for sample/save and sequence preview/apply; actual exported quiz round-trip through cards/worksheet/shared-screen. This is a bounded check, not a full accessibility certification.
- [x] Check all included simulations for loading and intended controls, including all ten preserved directory/lab pages. Full scientific/rights review is separate.
- [x] Final source/preview integrity and original-entry inventory check:105-file offline site candidate includes all44original HTML routes. Each legacy tool/bridge has bounded functional evidence; full article currency/science/audio/rights review is not implied.
- [ ] Owner acceptance and production deployment decision. The preview is not the public launch.

## Track B: existing-account private classroom pilot

- [x] Server-owned class membership, fixed assignments, immutable first scores and minimal owner roster.
- [x] Parent access requires an exact request and explicit student approval; revocation checked before export.
- [x] Admin membership separately approved; view/profile choices do not grant it.
- [x] Independent synthetic sessions: teacher publish, learner join and3/3, parent pending/approve/remove and stale-export denial.
- [x] Private live game: three question types, server score, realtime progression, hidden keys, outsider isolation and reconnect evidence.
- [x] Exact test-record/account cleanup and original-user preservation.
- [x] Local actual-route/session integration: classroom form -> owned game link -> reload -> classroom return; cross-window account changes, private-state purge and delayed-response denial.29browser suites. Synthetic local service only.
- [ ] Actual provider standalone navigation/token persistence/expiry/session acceptance using an authorized adult pilot. Isolated synthetic and local route tests are not this acceptance.
- [ ] Agree eligible audience, account provisioning, access/removal/support process and retention. No public signup is opened by this checklist.
- [ ] Owner acceptance and explicit access-release decision.

## Separate full-product work

These do not disappear because a manual alternative exists:

- AI tutor, AI generation/adaptive assessment: provider age/use conditions, privacy, quotas and operational approval, then actual implementation/evaluation.
- Account-linked goals/rewards: consent, data visibility, workflow and revocation requirements, then implementation. Game points are not real-world rewards.
- Screen-time enforcement: another device cannot be controlled by a normal website timer. Requires a supported device-management product and explicit scope.
- School imports, staff provisioning and district reports: identity/role and data-handling workflow, then implementation and authorization tests.
- Paid resources/subscriptions: rights, merchant eligibility, receiving-payment setup, fees, refund/support terms and owner approval before any sale.

## Repeatable checks

1. Run `python tests/run-local.py` from the project.
2. Run `python platform/scripts/package-preview.py`, then `python platform/scripts/audit-preview.py`.
3. Inspect the resulting preview at actual desktop/mobile size. Check printed output for affected pages.
4. Verify the published source archive and deployed changed files against their recorded hashes/bytes.
5. Confirm no temporary test pages, accounts or data remain. Keep all access flags closed until the corresponding decision and acceptance are complete.

The existing scholarship/article listings and original video are preserved content. Their availability, factual currency and rights are not implied by testing the new tools. The preserved video contains mole/molar-mass examples rather than the original atomic-structure page label; that mismatch is now stated alongside it. Full audio/content/alignment review remains open.

## Latest acceptance evidence

26 isolated local browser suites plus quiz-store units pass. All preserved lab inline scripts are syntax-checked. The old atomic-model quiz had invalid quotes and rendered no questions; fixed and checked six actual cards. Litmus stale timers/colors/reset are covered. CRT asset paths are repaired. Reaction graph fits390px. Range labels are associated and reduced-motion styles included. The mole calculator uses the exact SI constant, with rounded teaching values explicitly approximate and a BIPM reference. Full content/audio/scientific/rights review remains separate.

## Whole-site candidate (ab)

`platform/scripts/package-preview.py` also creates `/tmp/brainjoy-site-candidate.zip`, a105-file offline assembled site with actual homepage rather than the development directory. It is not a production deployment. The106-file testing preview retains its warning/directory. The reference original main commit is93324f26dc68af9932d410f3325a21a171503e9d, verified against current remote during assembly; all44original HTML entry routes are included. Original educational video/content and historical game-concept arrays are retained. Old score/publishing/marketplace/AI simulations are explicitly inactive or routed to real tools, not passed off as implemented products.

28real-time isolated browser suites plus quiz-store units and actual-keyboard smoke pass. The original wastewater page was truncated mid-script; restored as explicitly simplified fixed-step model, with no official authority, discharge or marine-safety claim. Pending dissociation reset is guarded. Original info-page mobile navigation/layout corrected. Narrow molar table scrolls horizontally within its own labeled region, not the whole page. These are bounded checks, not an accessibility or scientific certification.

## Standalone route/session acceptance (ad),2026-11-11

29isolated browser suites plus quiz-store units. Actual classroom entry/login form -> owned-assignment standalone game link -> reload -> classroom return tested with two same-origin windows and a loopback-only synthetic auth/RPC service. Cross-window account change/signout/sign-in clears previous private state and loads the current account. Delayed initial-session/dashboard/login responses cannot revive signed-out UI. Same-user token refresh preserves the account without duplicate dashboard reads; normal navigation never creates/joins a game. The prior ac source fails this new suite at cross-window game account switch. No real credentials, tokens, accounts or backend data in the fixture.

Classroom registers auth events before initial reads; both routes defer reads outside auth callbacks, track current account/startup revisions, clear old private outputs and forms immediately, and reload page-history restorations instead of reviving disconnected/stale state. Classroom dashboard refresh has a latest-request guard. Game and classroom use the same pinned SDK2.45.4. Source guidance: https://supabase.com/docs/reference/javascript/auth-onauthstatechange and https://supabase.com/kb/troubleshooting/why-is-my-supabase-api-call-not-returning-PGzXw0 .

This is local route integration evidence, not actual provider token persistence/expiry, hosted cross-tab behavior, password recovery, legal consent or authorized-adult acceptance. Ordinary access flags remain false. Test injection exists only in loopback test server, never distributable. Real provider/standalone acceptance remains a separate unchecked gate.


## Actual SDK contract check (ae),2026-11-11

30isolated browser suites plus quiz-store units pass. Added the actual unmodified pinned Supabase SDK2.45.4 locally, with its MIT notice and recorded hash, against an inert synthetic auth/RPC fetch interface. The real SDK signs in through the real app form, persists/restores a session across actual standalone route navigation/reload, handles explicit refresh and TOKEN_REFRESHED, and propagates account change/signout/sign-in via its real cross-window BroadcastChannel/storage logic. The former ac app fails this SDK-based suite on cross-window game account switching, while current ad app passes. No app changes were needed after ad.

All fake passwords/JWT-shaped/refresh strings are inert local fixtures with no authority on any provider. No actual email/account/credential/backend write is involved. Mocks/vendor are test-source only and excluded from both static packages. This checks SDK behavior, not real provider token validity/expiry/revocation/network failure or adult/guardian/release acceptance. Ordinary preview remains byte-identical ad, with all flags false.


## School/staff and roster preparation (af),2026-11-11

Source-only, disabled. Additive migration007 implements school owner, pending/exact-role accepted manager/teacher grants, removal/leave and class-owner-only association. School roles never inherit platform administration, class ownership, student roster/grade/answer access. Existing classroom RPCs unchanged. No migration installed or app deployed. CSV review prepares a local private review-only manifest for existing account IDs, with strict one-column schema, bounds, duplicate/self-ID/error checks, explicit confirmation and account/class/file/refresh invalidation. No account creation, email, invitation, enrollment, data-policy default or student permission is implied. Audience/age/guardian/retention fields remain null.

Disposable PostgreSQL authorization tests rolled back all fixtures and verified security-definer fixed paths/anonymous denial.31browser suites plus quiz-store/roster-import units pass, including source-only actual-page role/confirm/CSV/privacy/gating tests.390/1200px source-only pixels inspected, including narrow IDs and reviewed-file checkbox. School source is excluded from ordinary static packages; deployed ad bytes and all production/access/provider/payment state unchanged. Full details and remaining school/enrollment/district work are in SCHOOL-PREPARATION.md.


## Private study goals (ag),2026-11-11

Disabled/source-only student-owned goals and self-reported progress. Migration008 not installed, no page deployed. Private default; exact per-goal student sharing plus current approved-parent link required. Existing score-sharing grant never expands automatically. Parent/teacher/outsider writes denied; unlink clears grants permanently so relink cannot revive goal sharing. Reversible archive removes grants; restore stays private. Revision-checked counts,40active/200total bounds, no money/prize/obligation/mastery claims. Parent view read-only with current-server refresh/filter purge; hidden-page data cleared and checked on return. Audience/age/guardian/retention remain null.

32browser suites plus quiz-store/roster-import units pass. New actual-source UI and disposable rollback SQL authorization matrix pass; independent local concurrency yields one winner per revision and bounded last-slot create. One preexisting SDK INITIAL_SESSION wait timed out once; isolated rerun, five repeatedSDKchecks and subsequent full run passed, not claimed permanently fixed. Mobile390/desktop1200 pixels inspected. Ordinary ad candidate/preview bytes unchanged, no live-account/backend/provider/payment/production change. Details and open boundaries in STUDY-GOALS.md.


## Account request/status preparation (ah),2026-11-11

Disabled/source-only009, not installed or deployed. Categorical self-account export/removal/support requests with revisioned status history, duplicate-open reuse, cancellation, separately-approved-platform-admin oldest100other-account queue/truncation signal and minimal status controls. No free text/attachments, full export, deletion, emails, deadline or completed-service status. Current parent/school/selected roles grant nothing. Admin cannot handle own request. Self-only current-status receipt explicitly not account-data export/deletion. Audience/privacy/guardian/retention/support deadline unresolved/null.

33browser suites plus quiz-store/roster-import units pass; disposable rollback SQL covers isolation, revocation, limits, state/revision/event history and original account preservation. Local independent concurrent duplicate/cancel-status tests pass; exact fixtures cleaned.390/1200source pixels inspected, mobile status select shortened with full explanation below. Ordinary ad packages/deployment/access state unchanged; all new source excluded. Detailed remaining fulfillment/legal/operations work in ACCOUNT-REQUESTS.md.

