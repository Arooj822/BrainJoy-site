// Source-only local development. Not included in ordinary deployment packages.
window.BRAINJOY_BANK_CONFIG=Object.freeze({enabled:false,intendedAudience:'All ages, worldwide',releaseEligibility:null,guardianPolicy:null,retentionPolicy:null});
