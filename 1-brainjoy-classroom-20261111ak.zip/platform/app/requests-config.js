// Source only. No approved audience, retention, response deadline or deletion/export process inferred.
window.BRAINJOY_REQUESTS_CONFIG=Object.freeze({enabled:false,audience:null,studentAgeRange:null,guardianPolicy:null,retentionPolicy:null,supportDeadline:null});
