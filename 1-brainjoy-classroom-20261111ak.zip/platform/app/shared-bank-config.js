// Source only. No live migration installed or public release permission implied.
window.BRAINJOY_SHARED_BANK_CONFIG=Object.freeze({enabled:false,intendedAudience:'All ages, worldwide',eligibility:null,guardianPolicy:null,retentionPolicy:null});
