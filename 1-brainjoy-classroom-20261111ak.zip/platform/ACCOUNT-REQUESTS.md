# Account requests and support status preparation

Source-only, disabled. Migration009 and requests page are not deployed or linked from ordinary pages. No account data is deleted, retrieved for full export, emailed or otherwise sent. No policy or response time is invented.

## Implemented

- A signed-in account can create a categorical export question, removal question or support-topic request for itself. No arbitrary requester ID, parent delegation, chosen role, free-text message, attachment or credential field is accepted in request contents.
- Export/removal uses account-data category; support uses account-access/sharing/technical category. Mismatched/unrecognized values are rejected on the server.
- Duplicate open same-type/topic requests are reused, including concurrent creation.200stored records per account bounds request history; it is not a retention promise. Stored requester ID/type/category/times/status are disclosed to the requester and separately approved platform support admins only after eventual release authority.
- Immutable per-revision status-history events. Current requester sees own records/history; support-admin actor is shown as a role label, not its private account ID.
- User can explicitly cancel an open request, not delete its record. Terminal cancelled/closed-without-action states cannot be reopened. New request is possible within limits.
- Only existing separately approved `brainjoy.admins` membership can read a bounded oldest100open other-account queue and record `reviewing`, `needs_owner_decision` or `closed_without_action`. Queue truncation is explicitly signaled. No self-handling, self-selected support role, school/teacher/parent inheritance or status implying fulfilled export/deletion.
- Revision checks and request/account locks prevent lost updates/duplicate creates. Requester-cancel versus support-status race has exactly one revision winner. Status operation checks current server admin membership on every call; revocation removes access.
- Source UI confirms exact request/status changes, explains no action is being executed, defaults cancellation focus, shows own history and separate authorized queue. Narrow-screen status options are short with a separate full explanation, not clipped legal/action wording.
- Self-only status receipt JSON rechecks current dashboard before download. It is labeled `brainjoy-request-status-receipt`, has false account-data-export/deletion/message fields, null deadline and unresolved policy approval. It contains request status/history, not a full account-data export.
- Immediate account-change/signout purge, stale-read rejection, private view clear before refresh (including failure), and hidden-page purge/recheck on return. No network polling or automatic notifications. Closed feature flag prevents creating a service client or making an account/request call.

## Not implemented or implied

This is a request/status workflow, not deletion, full data portability, identity verification, customer-service operations, legal compliance, an appeals process or a completed support conversation. No automated account removal, record deletion, complete data inventory/export, backup erasure, legal hold, retention period, jurisdiction rule, guardian delegation, SLA or external message is implemented. A saved request does not mean anyone has read it or agreed to act. A support admin must not mark `reviewing` unless that status is true; the system does not simulate review.

`closed_without_action` explicitly does not certify completion. No completed-action status or unrestricted free-text response is available. Actual fulfillment would need its own reviewed evidence/authority and implementation rather than reusing a status control to claim it happened. User cancellation cannot undo an outside action or erase copies/history.

Parent links share only their explicit current scopes and never another person's account-request records. A parent seeking action for a child needs a separately designed/verified process, not a flag default. Student audience/age/country, support staffing, identity checks, handling/removal/retention/legal/guardian policies remain unresolved/null. Existing record preservation remains in force.

An open visible page is not a real-time remote-erasure mechanism. It rechecks on Refresh and returning from a hidden page; future server reads/status writes enforce current rights. Previously copied receipts/screenshots cannot be recalled.

## Proposed source/security boundaries

New RLS tables and four fixed-search-path security-definer RPCs; no direct authenticated/anonymous table access and no public/anon execute. No existing classroom, school, goal, Auth, parent-link or grade record is modified by creating/cancelling/handling requests. New disable script revokes request RPC execution without deleting records/history. School/goals/request source remains excluded from ordinary static package. No migration has been installed.

Before real release: decide authorized audience/support handling/privacy/guardian/retention and verified identity process; review collision/security/queue limits; test actual service integration/authorization/concurrency; agree how requests will actually be worked and funded; separately implement any actual data export/deletion safely; explicitly approve release. Passing preparation tests supplies none of those approvals.

## Evidence

- Disposable local PostgreSQL `tests/account-requests.sql`: self-only scope, no parent/outsider inheritance, exact approved-admin queue/status, minimal fields, actor privacy, duplicate reuse, invalid categories, stale revision, no fulfilled status, self-handling denial, cancellation/terminal state, revoked-admin/null/anon/table denial, original Auth records preserved,200stored and100queue bounds/truncation signal. All fixtures rollback.
- Local-only independent concurrency script: duplicate creates yield one request; requester cancel/support update same revision yields one success and exact two-event history. Exact fixture cleanup verified.
- Actual-source UI synthetic test: cancellation/confirmation, no sensitive-message fields, honest current status receipt, failed recheck cannot export, approved/revoked support UI, status revision, stale signout and default closed gate.
-33browser suites plus quiz-store/roster-import units pass.390px/1200px source-only pixels inspected. No real account cycle, live writes, messages, provider or payment changes.
