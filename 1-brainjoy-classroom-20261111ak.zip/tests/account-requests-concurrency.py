"""Disposable local PostgreSQL ONLY. Set BJ_REQUESTS_LOCAL_DB to a local disposable database.
Never accepts a host/network connection; no actual provider accounts used.
"""
import os,subprocess,json,uuid,concurrent.futures
DB=os.environ.get('BJ_REQUESTS_LOCAL_DB','bj_requests_20261111')
if not DB.startswith('bj_requests_'):raise SystemExit('Use a disposable bj_requests_ local database only')
def sql(text,check=True):
 return subprocess.run(['psql','-X','-v','ON_ERROR_STOP=1','-h','/tmp','-p','55432','-d',DB,'-At','-f','-'],input=text,capture_output=True,text=True,check=check)
u=str(uuid.uuid4());admin=str(uuid.uuid4())
try:
 sql(f"insert into auth.users(id)values('{u}'),('{admin}');insert into brainjoy.admins values('{admin}');")
 def create(_):return sql(f"begin;set local role authenticated;select set_config('request.jwt.claim.sub','{u}',true);select public.bj_request_create('removal','account_data');select pg_sleep(0.1);commit;",False)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:results=list(pool.map(create,[1,2]))
 assert all(r.returncode==0 for r in results),[r.stderr for r in results]
 assert sql(f"select count(*)from brainjoy.account_requests where requester_id='{u}'").stdout.strip()=='1'
 rid=sql(f"select id from brainjoy.account_requests where requester_id='{u}'").stdout.strip();uuid.UUID(rid)
 def mutate(who):
  call=f"public.bj_request_cancel('{rid}',1)" if who==u else f"public.bj_request_status('{rid}',1,'reviewing')"
  return sql(f"begin;set local role authenticated;select set_config('request.jwt.claim.sub','{who}',true);select {call};select pg_sleep(0.1);commit;",False)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:results=list(pool.map(mutate,[u,admin]))
 assert sum(r.returncode==0 for r in results)==1,[(r.returncode,r.stderr)for r in results]
 assert any('Request changed' in r.stderr for r in results if r.returncode)
 assert sql(f"select count(*)from brainjoy.account_request_events where request_id='{rid}'").stdout.strip()=='2'
 print('PASS local concurrent duplicate creates reuse one request; requester cancel vs support update has one revision winner and two history events')
finally:
 sql(f"delete from brainjoy.account_request_events where request_id in(select id from brainjoy.account_requests where requester_id='{u}');delete from brainjoy.account_requests where requester_id='{u}';delete from brainjoy.admins where user_id='{admin}';delete from auth.users where id in('{u}','{admin}');",False)
