-- Disposable local DB only. Requests never execute an export or deletion.
begin;
do $$
declare u uuid:=gen_random_uuid();p uuid:=gen_random_uuid();a uuid:=gen_random_uuid();x uuid:=gen_random_uuid();id uuid;ownid uuid;r jsonb;k text;v integer;denied boolean;i integer;
begin
 insert into auth.users(id)values(u),(p),(a),(x);insert into brainjoy.admins values(a);
 perform set_config('role','authenticated',true);perform set_config('request.jwt.claim.sub',u::text,true);
 id:=(public.bj_request_create('removal','account_data')->>'id')::uuid;
 r:=public.bj_request_create('removal','account_data');if not(r->>'already_open')::boolean or(r->>'id')::uuid<>id then raise exception 'FAIL duplicate open request';end if;
 r:=public.bj_request_dashboard();if jsonb_array_length(r->'own')<>1 or r->'queue'<>'[]' or(r->>'support_admin')::boolean then raise exception 'FAIL self scope';end if;
 denied:=false;begin perform public.bj_request_create('removal','sharing');exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL mismatched category';end if;
 denied:=false;begin perform public.bj_request_status(id,1,'reviewing');exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL requester promotes support';end if;
 k:=public.bj_parent_code();perform set_config('request.jwt.claim.sub',p::text,true);perform public.bj_link_parent(k);perform set_config('request.jwt.claim.sub',u::text,true);perform public.bj_approve_parent(p);
 perform set_config('request.jwt.claim.sub',p::text,true);r:=public.bj_request_dashboard();if r->'own'<>'[]' or r->'queue'<>'[]' then raise exception 'FAIL parent inherited privacy request';end if;
 denied:=false;begin perform public.bj_request_cancel(id,1);exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL parent cancels';end if;
 perform set_config('request.jwt.claim.sub',a::text,true);r:=public.bj_request_dashboard();if not(r->>'support_admin')::boolean or jsonb_array_length(r->'queue')<>1 then raise exception 'FAIL approved support queue';end if;
 if r->'queue'->0 ?| array['email','answers','scores','parent_id','history'] then raise exception 'FAIL excessive queue disclosure';end if;
 v:=public.bj_request_status(id,1,'reviewing');
 denied:=false;begin perform public.bj_request_status(id,1,'needs_owner_decision');exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL stale support write';end if;
 denied:=false;begin perform public.bj_request_status(id,v,'completed');exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL invented fulfillment';end if;
 ownid:=(public.bj_request_create('export','account_data')->>'id')::uuid;
 denied:=false;begin perform public.bj_request_status(ownid,1,'reviewing');exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL self support handling';end if;
 perform set_config('request.jwt.claim.sub',u::text,true);r:=public.bj_request_dashboard();if r->'own'->0->>'status'<>'reviewing' or jsonb_array_length(r->'own'->0->'history')<>2 then raise exception 'FAIL visible status history';end if;
 if (r->'own'->0->'history')::text like '%'||a::text||'%' then raise exception 'FAIL admin identity leaked';end if;
 v:=public.bj_request_cancel(id,v);
 perform set_config('request.jwt.claim.sub',a::text,true);denied:=false;begin perform public.bj_request_status(id,v,'reviewing');exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL cancelled request reopened';end if;
 perform set_config('request.jwt.claim.sub',u::text,true);id:=(public.bj_request_create('removal','account_data')->>'id')::uuid;
 perform set_config('request.jwt.claim.sub',a::text,true);v:=public.bj_request_status(id,1,'closed_without_action');
 perform set_config('request.jwt.claim.sub',u::text,true);denied:=false;begin perform public.bj_request_cancel(id,v);exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL closed request mutation';end if;
 perform set_config('request.jwt.claim.sub',x::text,true);denied:=false;begin select count(*)into i from brainjoy.account_requests;exception when insufficient_privilege then denied:=true;end;if not denied then raise exception 'FAIL direct table access';end if;
 perform set_config('request.jwt.claim.sub','',true);denied:=false;begin perform public.bj_request_dashboard();exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL null identity';end if;
 perform set_config('role','none',true);delete from brainjoy.admins where user_id=a;perform set_config('role','authenticated',true);perform set_config('request.jwt.claim.sub',a::text,true);r:=public.bj_request_dashboard();if r->'queue'<>'[]' or(r->>'support_admin')::boolean then raise exception 'FAIL revoked admin queue';end if;
 denied:=false;begin perform public.bj_request_status(ownid,1,'reviewing');exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL revoked admin writes';end if;
 perform set_config('role','none',true);if(select count(*)from auth.users au where au.id in(u,p,a,x))<>4 then raise exception 'FAIL request deleted accounts';end if;
 perform set_config('role','anon',true);denied:=false;begin perform public.bj_request_dashboard();exception when insufficient_privilege then denied:=true;end;if not denied then raise exception 'FAIL anon';end if;perform set_config('role','none',true);
end $$;
do $$
declare u uuid:=gen_random_uuid();a uuid:=gen_random_uuid();v uuid;i integer;r jsonb;denied boolean;
begin
 insert into auth.users values(u),(a);insert into brainjoy.admins values(a);perform set_config('role','authenticated',true);perform set_config('request.jwt.claim.sub',u::text,true);
 for i in 1..200 loop v:=(public.bj_request_create('account_help','technical')->>'id')::uuid;perform public.bj_request_cancel(v,1);end loop;
 denied:=false;begin perform public.bj_request_create('account_help','technical');exception when raise_exception then denied:=true;end;if not denied then raise exception 'FAIL stored bound';end if;
 perform set_config('role','none',true);
 for i in 1..101 loop v:=gen_random_uuid();insert into auth.users values(v);insert into brainjoy.account_requests(requester_id,kind,category)values(v,'export','account_data');end loop;
 perform set_config('role','authenticated',true);perform set_config('request.jwt.claim.sub',a::text,true);r:=public.bj_request_dashboard();if jsonb_array_length(r->'queue')<>100 or not(r->>'queue_more')::boolean then raise exception 'FAIL queue bound or truncation signal';end if;perform set_config('role','none',true);
end $$;
rollback;
select 'PASS self-only requests/history, approved-admin bounded queue/status, no parent/outsider/role escalation, duplicate reuse/revisions/cancel/closed/revocation, no fulfilled status/account mutation/table/anon access; rollback' result;
