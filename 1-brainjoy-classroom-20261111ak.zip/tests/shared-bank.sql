-- Disposable database only. No real users. Entire test rolls back.
begin;
create function pg_temp.denied(p text)returns void language plpgsql as $$begin execute p;raise exception 'NOT DENIED';exception when others then if sqlerrm='NOT DENIED' then raise exception 'FAIL expected denial: %',p;end if;end$$;
do $$
declare o uuid:=gen_random_uuid();r uuid:=gen_random_uuid();p uuid:=gen_random_uuid();s uuid:=gen_random_uuid();x uuid:=gen_random_uuid();par uuid:=gen_random_uuid();c jsonb;other jsonb;g uuid;pg uuid;i uuid;v jsonb;a uuid;b uuid;j jsonb;before integer;checks jsonb:='{"answer":true,"explanation":true,"rights":true,"audience":true}';content jsonb:='{"prompt":"What is 7 + 5?","choices":["10","12","14"],"answer":1,"explanation":"Seven plus five is twelve.","topic":"addition","prerequisites":[],"audience":"Early practice; educator review needed","alignment":"Not verified","origin":"original","source":"Original sample","rights":"Original wording"}';
begin
 insert into auth.users(id)values(o),(r),(p),(s),(x),(par);insert into brainjoy.admins values(x);
 perform set_config('role','authenticated',true);perform set_config('request.jwt.claim.sub',o::text,true);c:=public.bj_create_class('Bank class');other:=public.bj_create_class('Other class');
 perform pg_temp.denied(format('select public.bj_bank_staff(%L,%L,%L,false)',c->>'id',o,'reviewer'));
 g:=public.bj_bank_staff((c->>'id')::uuid,r,'reviewer',false);pg:=public.bj_bank_staff((c->>'id')::uuid,p,'publisher',false);
 v:=public.bj_bank_draft((c->>'id')::uuid,null,0,content);i:=(v->>'id')::uuid;
 perform pg_temp.denied(format('select public.bj_bank_review(%L,1,%L)',i,checks));perform pg_temp.denied(format('select public.bj_bank_publish(%L,1,%L)',i,'Premature'));
 perform set_config('request.jwt.claim.sub',r::text,true);j:=public.bj_bank_dashboard();if jsonb_array_length(j->'items')<>0 or jsonb_array_length(j->'grants')<>1 then raise exception 'FAIL pending disclosure';end if;
 perform pg_temp.denied(format('select public.bj_bank_review(%L,1,%L)',i,checks));perform pg_temp.denied(format('select public.bj_bank_accept(%L,true)',pg));perform public.bj_bank_accept(g,true);
 j:=public.bj_bank_dashboard();if j->'items'->0->'revisions'->0->'content'->'answer'<>'1'::jsonb then raise exception 'FAIL reviewer needs key';end if;
 perform pg_temp.denied(format('select public.bj_bank_review(%L,1,%L)',i,'{"answer":true}'));perform public.bj_bank_review(i,1,checks);
 perform pg_temp.denied(format('select public.bj_bank_publish(%L,1,%L)',i,'Reviewer not publisher'));
 perform pg_temp.denied(format('select public.bj_bank_draft(%L,%L,1,%L)',c->>'id',i,content));
 perform set_config('request.jwt.claim.sub',p::text,true);perform pg_temp.denied(format('select public.bj_bank_publish(%L,1,%L)',i,'Pending publisher'));perform public.bj_bank_accept(pg,true);a:=public.bj_bank_publish(i,1,'Reviewed addition');b:=public.bj_bank_publish(i,1,'Ignored duplicate title');if a<>b then raise exception 'FAIL duplicate assignment';end if;perform pg_temp.denied(format('select public.bj_get_assignment(%L)',a));if jsonb_array_length(public.bj_dashboard()->'results')<>0 then raise exception 'FAIL publisher student data';end if;
 perform set_config('request.jwt.claim.sub',s::text,true);perform public.bj_join_class(c->>'join_code');j:=public.bj_bank_dashboard();if jsonb_array_length(j->'items')<>0 or jsonb_array_length(j->'classes')<>0 then raise exception 'FAIL learner bank key leak';end if;
 j:=public.bj_get_assignment(a);if j::text like '%correct%' or j::text like '%answer%' or j::text like '%explanation%' or j::text like '%Original sample%' then raise exception 'FAIL learner key metadata leak';end if;
 j:=public.bj_submit(a,'[1]');if j->>'score'<>'1' then raise exception 'FAIL server grade';end if;j:=public.bj_submit(a,'[0]');if j->>'score'<>'1' then raise exception 'FAIL immutable first score';end if;
 perform pg_temp.denied(format('select public.bj_bank_review(%L,1,%L)',i,checks));perform pg_temp.denied(format('select public.bj_bank_publish(%L,1,%L)',i,'Learner'));perform pg_temp.denied('select * from brainjoy.bank_revisions');
 perform set_config('role','none',true);insert into brainjoy.parent_links values(s,par);perform set_config('role','authenticated',true);perform set_config('request.jwt.claim.sub',par::text,true);j:=public.bj_bank_dashboard();if jsonb_array_length(j->'items')<>0 then raise exception 'FAIL parent access';end if;perform pg_temp.denied(format('select public.bj_get_assignment(%L)',a));
 perform set_config('request.jwt.claim.sub',x::text,true);j:=public.bj_bank_dashboard();if jsonb_array_length(j->'items')<>0 then raise exception 'FAIL admin inherited';end if;perform pg_temp.denied(format('select public.bj_bank_staff(%L,%L,%L,false)',c->>'id',x,'reviewer'));perform pg_temp.denied(format('select public.bj_get_assignment(%L)',a));
 perform set_config('request.jwt.claim.sub',o::text,true);v:=public.bj_bank_draft((c->>'id')::uuid,i,1,jsonb_set(content,'{prompt}','"Compute 7 + 5."'));if v->>'revision'<>'2' then raise exception 'FAIL next revision';end if;
 perform pg_temp.denied(format('select public.bj_bank_draft(%L,%L,1,%L)',c->>'id',i,content));perform pg_temp.denied(format('select public.bj_bank_draft(%L,%L,2,%L)',other->>'id',i,content));perform pg_temp.denied(format('select public.bj_bank_draft(%L,%L,2,%L)',c->>'id',i,jsonb_set(content,'{source}','"erased"')));perform pg_temp.denied(format('select public.bj_bank_publish(%L,2,%L)',i,'No current review'));
 perform set_config('request.jwt.claim.sub',r::text,true);perform pg_temp.denied(format('select public.bj_bank_review(%L,1,%L)',i,checks));perform public.bj_bank_review(i,2,checks);
 perform set_config('request.jwt.claim.sub',o::text,true);perform public.bj_bank_staff((c->>'id')::uuid,r,'reviewer',true);perform pg_temp.denied(format('select public.bj_bank_publish(%L,2,%L)',i,'Revoked reviewer'));g:=public.bj_bank_staff((c->>'id')::uuid,r,'reviewer',false);
 perform set_config('request.jwt.claim.sub',r::text,true);perform public.bj_bank_accept(g,true);perform set_config('request.jwt.claim.sub',o::text,true);perform pg_temp.denied(format('select public.bj_bank_publish(%L,2,%L)',i,'Relink must not revive review'));
 perform public.bj_bank_draft((c->>'id')::uuid,i,2,content);perform set_config('request.jwt.claim.sub',r::text,true);perform public.bj_bank_review(i,3,checks);perform set_config('request.jwt.claim.sub',p::text,true);b:=public.bj_bank_publish(i,3,'Third revision');if a=b then raise exception 'FAIL revision snapshot reused';end if;
 perform set_config('request.jwt.claim.sub',o::text,true);perform public.bj_bank_staff((c->>'id')::uuid,p,'publisher',true);perform set_config('request.jwt.claim.sub',p::text,true);perform pg_temp.denied(format('select public.bj_bank_publish(%L,3,%L)',i,'Revoked publisher'));j:=public.bj_bank_dashboard();if jsonb_array_length(j->'items')<>0 then raise exception 'FAIL revoked keys';end if;
 perform set_config('request.jwt.claim.sub',s::text,true);j:=public.bj_submit(a,'[0]');if j->>'score'<>'1' then raise exception 'FAIL old score altered';end if;
 perform set_config('role','none',true);if(select count(*)from brainjoy.bank_publications)<>2 or(select count(*)from brainjoy.bank_revisions)<>3 or(select count(*)from brainjoy.bank_reviews)<>3 then raise exception 'FAIL preserved history';end if;
 perform set_config('role','anon',true);perform pg_temp.denied('select public.bj_bank_dashboard()');perform set_config('role','none',true);perform set_config('role','authenticated',true);perform set_config('request.jwt.claim.sub','',true);perform pg_temp.denied('select public.bj_bank_dashboard()');perform set_config('role','none',true);
end$$;
do $$
declare o uuid:=gen_random_uuid();c jsonb;v jsonb;i uuid;u uuid;users uuid[]:='{}';k integer;content jsonb:='{"prompt":"One?","choices":["Yes","No"],"answer":0,"explanation":"Yes.","topic":"one","prerequisites":[],"audience":"Check suitability","alignment":"Unknown","origin":"original","source":"Original sample","rights":"Original"}';
begin
 insert into auth.users(id)values(o);for k in 1..21 loop u:=gen_random_uuid();users:=array_append(users,u);insert into auth.users(id)values(u);end loop;
 perform set_config('role','authenticated',true);perform set_config('request.jwt.claim.sub',o::text,true);c:=public.bj_create_class('Bank limits');
 for k in 1..100 loop v:=public.bj_bank_draft((c->>'id')::uuid,null,0,content);if k=1 then i:=(v->>'id')::uuid;end if;end loop;
 perform pg_temp.denied(format('select public.bj_bank_draft(%L,null,0,%L)',c->>'id',content));
 for k in 1..19 loop perform public.bj_bank_draft((c->>'id')::uuid,i,k,content);end loop;
 perform pg_temp.denied(format('select public.bj_bank_draft(%L,%L,20,%L)',c->>'id',i,content));
 perform pg_temp.denied(format('select public.bj_bank_draft(%L,null,0,%L)',c->>'id',content||'{"reviewed":true}'::jsonb));
 perform pg_temp.denied(format('select public.bj_bank_draft(%L,null,0,%L)',c->>'id',jsonb_set(content,'{answer}','99')));
 for k in 1..20 loop perform public.bj_bank_staff((c->>'id')::uuid,users[k],'reviewer',false);end loop;
 perform pg_temp.denied(format('select public.bj_bank_staff(%L,%L,%L,false)',c->>'id',users[21],'reviewer'));
 for k in 1..20 loop perform public.bj_bank_staff((c->>'id')::uuid,users[k],'reviewer',true);end loop;
 for k in 21..100 loop perform public.bj_bank_staff((c->>'id')::uuid,users[1],'reviewer',false);perform public.bj_bank_staff((c->>'id')::uuid,users[1],'reviewer',true);end loop;
 perform pg_temp.denied(format('select public.bj_bank_staff(%L,%L,%L,false)',c->>'id',users[1],'reviewer'));
 perform set_config('role','none',true);
end$$;
rollback;
select 'PASS owner authors / exact accepted reviewer-publisher grants / independent review / immutable revisions / revoked-review relink denial / authorized one-question class publication / learner key-free delivery and server scoring / parent-outsider-admin isolation / preserved original scores / anonymous denial; rolled back' result;
