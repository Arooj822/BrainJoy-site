"""Disposable local SQL concurrency checks. No remote/database URI accepted."""
import os,subprocess,uuid,json,concurrent.futures
DB=os.environ.get('BJ_BANK_LOCAL_DB','bj_bank_20261111')
if not DB.startswith('bj_bank_'):raise SystemExit('Disposable bj_bank_ database required')
def sql(s,check=True):return subprocess.run(['psql','-X','-v','ON_ERROR_STOP=1','-h','/tmp','-p','55432','-d',DB,'-At','-f','-'],input='set jit=off;\n'+s,capture_output=True,text=True,check=check)
def asuser(u,s,check=True):return sql(f"begin;set local role authenticated;select set_config('request.jwt.claim.sub','{u}',true);{s};commit;",check)
def result(r):return [x for x in r.stdout.splitlines()if x.startswith('{') or (len(x)==36 and x.count('-')==4)][-1]
o,r,p=[str(uuid.uuid4())for _ in range(3)];c=None
content=json.dumps(dict(prompt='What is 7 + 5?',choices=['10','12','14'],answer=1,explanation='Twelve.',topic='addition',prerequisites=[],audience='Review needed',alignment='Unknown',origin='original',source='Original sample',rights='Original text'))
checks=json.dumps(dict(answer=True,explanation=True,rights=True,audience=True))
try:
 sql(f"insert into auth.users(id)values('{o}'),('{r}'),('{p}')")
 c=json.loads(result(asuser(o,"select public.bj_create_class('Concurrent bank class')")))['id']
 g=result(asuser(o,f"select public.bj_bank_staff('{c}','{r}','reviewer',false)"));pg=result(asuser(o,f"select public.bj_bank_staff('{c}','{p}','publisher',false)"));asuser(r,f"select public.bj_bank_accept('{g}',true)");asuser(p,f"select public.bj_bank_accept('{pg}',true)")
 i=json.loads(result(asuser(o,f"select public.bj_bank_draft('{c}',null,0,'{content}')")))['id'];asuser(r,f"select public.bj_bank_review('{i}',1,'{checks}')")
 request=str(uuid.uuid4());selection=json.dumps([dict(id=i,revision=1)])
 def assembly(_):return asuser(p,f"select public.bj_bank_assemble('{c}','{request}','Concurrent assembly','{selection}');select pg_sleep(0.08)",False)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:ars=list(pool.map(assembly,[1,2]))
 assert all(x.returncode==0 for x in ars),[x.stderr for x in ars]
 assert sql(f"select count(*)from brainjoy.bank_assemblies where class_id='{c}'").stdout.splitlines()[-1]=='1'
 print('PASS concurrent exact assembly request creates one frozen assignment/receipt')
 def publish(_):return asuser(p,f"select public.bj_bank_publish('{i}',1,'One immutable assignment');select pg_sleep(0.08)",False)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:rs=list(pool.map(publish,[1,2]))
 assert all(x.returncode==0 for x in rs),[x.stderr for x in rs]
 assert sql(f"select count(*)from brainjoy.bank_publications where item_id='{i}'").stdout.splitlines()[-1]=='1'
 # Concurrent latest-revision edits: exactly one may append revision2.
 def edit(_):return asuser(o,f"select public.bj_bank_draft('{c}','{i}',1,'{content}');select pg_sleep(0.08)",False)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:rs=list(pool.map(edit,[1,2]))
 assert sum(x.returncode==0 for x in rs)==1,[x.stderr for x in rs]
 assert any('Draft changed' in x.stderr for x in rs if x.returncode)
 asuser(r,f"select public.bj_bank_review('{i}',2,'{checks}')")
 # Revocation and publication share class lock. Either publication wins before revocation,
 # or it is denied. It cannot create an assignment after seeing a revoked grant.
 def race(kind):
  return asuser(o,f"select public.bj_bank_staff('{c}','{r}','reviewer',true);select pg_sleep(0.08)",False) if kind=='revoke' else asuser(p,f"select public.bj_bank_publish('{i}',2,'Race assignment');select pg_sleep(0.08)",False)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:rs=list(pool.map(race,['revoke','publish']))
 assert rs[0].returncode==0,rs[0].stderr
 assert rs[1].returncode==0 or 'Current independent review required' in rs[1].stderr,rs[1].stderr
 assert 'Current independent review required' in asuser(p,f"select public.bj_bank_publish('{i}',2,'After revoke')",False).stderr or rs[1].returncode==0
 # A fresh revision can never reuse revoked review.
 asuser(o,f"select public.bj_bank_draft('{c}','{i}',2,'{content}')")
 denied=asuser(p,f"select public.bj_bank_publish('{i}',3,'Unreviewed')",False)
 assert denied.returncode and 'Current independent review required' in denied.stderr
 print('PASS concurrent duplicate publication one assignment; stale draft edits one winner; reviewer revocation/publication serialized; no revoked-review inheritance')
finally:
 if c:
  sql(f"delete from brainjoy.bank_assembly_items where assembly_id in(select id from brainjoy.bank_assemblies where class_id='{c}');delete from brainjoy.bank_assemblies where class_id='{c}';delete from brainjoy.bank_publications where item_id in(select id from brainjoy.bank_items where class_id='{c}');delete from brainjoy.bank_reviews where item_id in(select id from brainjoy.bank_items where class_id='{c}');delete from brainjoy.bank_revisions where item_id in(select id from brainjoy.bank_items where class_id='{c}');delete from brainjoy.bank_items where class_id='{c}';delete from brainjoy.bank_staff where class_id='{c}';delete from brainjoy.assignments where class_id='{c}';delete from brainjoy.classes where id='{c}';",False)
 sql(f"delete from auth.users where id in('{o}','{r}','{p}')",False)
