"""Run synthetic browser/unit suites against an ephemeral loopback-only server.
Requires google-chrome, node and the websocket-client Python package. Does not sign in or call a real backend.
SQL/realtime independent-session verification is separate.
"""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from functools import partial
import os, re, subprocess, tempfile, threading, json, time, urllib.request, shutil, signal
import websocket
ROOT=Path(__file__).resolve().parents[1]
class Quiet(SimpleHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_GET(self):
        if self.path.split('?')[0]=='/tests/home-fixture.html':
            html=(ROOT/'index.html').read_text()
            html=html.replace('<head>','<head><base href="/"><script>window.__authCalls=0;window.supabase={createClient:()=>{window.__authCalls++;throw Error("Must stay gated");}};</script>',1)
            html=re.sub(r'<script[^>]+src="https:[^>]*></script>','',html)
            data=html.encode();self.send_response(200);self.send_header('Content-Type','text/html');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
        if self.path.split('?')[0]=='/tests/classroom-route-fixture.html':
            html=(ROOT/'platform/app/classroom.html').read_text()
            mock=(ROOT/'tests/classroom-route-mock.js').read_text()
            html=re.sub(r'<script defer src="[^"]+"></script>',lambda m:m[0] if 'classroom.js' in m[0] else '',html)
            html=html.replace('<head>','<head><base href="/platform/app/"><script>'+mock+'</script>',1)
            data=html.encode();self.send_response(200);self.send_header('Content-Type','text/html');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
        if self.path.split('?')[0]=='/tests/live-route-fixture.html':
            html=(ROOT/'live-game.html').read_text()
            mock=(ROOT/'tests/live-route-mock.js').read_text()
            html=re.sub(r'<script defer src="[^"]+"></script>',lambda m:m[0] if 'live-game.js' in m[0] else '',html)
            html=html.replace('<head>','<head><base href="/"><script>'+mock+'</script>',1)
            data=html.encode();self.send_response(200);self.send_header('Content-Type','text/html');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
        if self.path.split('?')[0]=='/tests/parent-route-fixture.html':
            html=(ROOT/'platform/app/classroom.html').read_text()
            mock=(ROOT/'tests/parent-route-mock.js').read_text()
            html=re.sub(r'<script defer src="[^"]+"></script>',lambda m:m[0] if 'classroom.js' in m[0] else '',html)
            html=html.replace('<head>','<head><base href="/platform/app/"><script>'+mock+'</script>',1)
            data=html.encode();self.send_response(200);self.send_header('Content-Type','text/html');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
        if self.path.split('?')[0]=='/tests/teacher-filter-fixture.html':
            html=(ROOT/'platform/app/classroom.html').read_text()
            mock=(ROOT/'tests/teacher-filter-mock.js').read_text()
            html=re.sub(r'<script defer src="[^"]+"></script>',lambda m:m[0] if 'classroom.js' in m[0] else '',html)
            html=html.replace('<head>','<head><base href="/platform/app/"><script>'+mock+'</script>',1)
            data=html.encode();self.send_response(200);self.send_header('Content-Type','text/html');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);return
        return super().do_GET()
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(ROOT)))
threading.Thread(target=server.serve_forever,daemon=True).start()
failed=[]
# Parse every shipped inline script, including historical quizzes in separate script blocks.
for page in ROOT.glob('*.html'):
    source=page.read_text()
    if '<script' in source and source.count('<script')!=source.count('</script>'):
        failed.append(page.name+' unclosed script')
    for i,m in enumerate(re.finditer(r'<script\b([^>]*)>(.*?)</script>',page.read_text(),re.S)):
        if 'src=' in m[1] or 'application/' in m[1]:continue
        with tempfile.NamedTemporaryFile(mode='w',suffix='.js') as script:
            script.write(m[2]);script.flush()
            result=subprocess.run(['node','--check',script.name],capture_output=True,text=True)
        if result.returncode:
            failed.append(page.name+' script '+str(i));print(result.stderr)

try:
    for test in ['extra-lessons-ui','assembly-ui','roundtrip-ui','preserved-simulations-ui','simulations-ui','curriculum-ui','legacy-entry-ui','quiz-http','classroom-ui','role-routing-ui','parent-ui','teacher-filters-ui','assignment-races-ui','roster-ui','tools-ui','library-ui','flashcards-ui','lesson-ui','home-ui','review-ui','practice-ui','recovery-ui','worksheet-ui','live-game-ui','live-host-ui','live-routing-ui','live-gated-ui','resource-pack-ui']:
        with tempfile.TemporaryDirectory(prefix='bj-synthetic-') as profile:
            proc=subprocess.Popen(['google-chrome','--headless','--no-sandbox','--disable-gpu','--disable-dev-shm-usage','--no-proxy-server','--remote-debugging-port=0','--remote-allow-origins=*','--user-data-dir='+profile],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
            result='FAIL: browser did not report a result'
            ws=None
            try:
                active=Path(profile)/'DevToolsActivePort'
                for _ in range(200):
                    if active.exists():break
                    time.sleep(.025)
                debug=active.read_text().splitlines()[0]
                request=urllib.request.Request('http://127.0.0.1:'+debug+'/json/new?about:blank',method='PUT')
                tab=json.load(urllib.request.urlopen(request))
                ws=websocket.create_connection(tab['webSocketDebuggerUrl']);seq=0
                def cdp(method,params):
                    global seq
                    seq+=1;ws.send(json.dumps({'id':seq,'method':method,'params':params}))
                    while True:
                        reply=json.loads(ws.recv())
                        if reply.get('id')==seq:return reply.get('result',{})
                cdp('Page.navigate',{'url':f'http://127.0.0.1:{server.server_port}/tests/{test}.html'})
                for _ in range(300):
                    evaluation=cdp('Runtime.evaluate',{'expression':"document.querySelector('#result')?.textContent",'returnByValue':True})
                    value=evaluation.get('result',{}).get('value')
                    if value and value!='Running':result=value;break
                    time.sleep(.05)
            except Exception as e:result='FAIL: '+str(e)
            finally:
                if ws:ws.close()
                os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=10)
                time.sleep(.1)
        print(test+': '+result,flush=True)
        if not result.startswith('PASS:'):failed.append(test)
    unit=subprocess.run(['node','tests/quiz-store.test.cjs'],cwd=ROOT,check=False)
    if unit.returncode:failed.append('quiz-store units')
finally:server.shutdown();server.server_close()
if failed:raise SystemExit('FAILED: '+', '.join(failed))
print('PASS: 28 browser suites plus quiz-store units. Mocks/local tools only; not live integration/release proof.')
