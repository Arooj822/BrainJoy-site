## Three-session hosted pilot and cleanup, 2026-11-11 02:11 Asia/Dubai
Supersedes pending roster/parent pilot statements below. Three isolated, no-email synthetic sessions exercised actual deployed classroom UI: teacher class creation and quiz publication; learner private-code join and MCQ/true-false/short submission with server3/3; teacher owner-only roster showing one member and its submission. Parent dashboard had no shared results before approval or while pending. Learner approved the exact synthetic parent account through an on-page confirmation; parent saw only that learner's3/3. After learner revoked access, a parent export refreshed permission, cleared the stale result and produced no new export. Parent was denied private assignment/game/roster/admin reads; learner denied teacher roster. A separate live game progressed through all three question types and server-scored3points over realtime, then both sessions showed finished. This is bounded synthetic evidence, not real-child consent, legal guardianship, an owner acceptance test or public-release approval. Full navigation across standalone production routes was not verified by the isolated session container.

A native confirmation stalled the automated pilot page. Classroom confirmations are now accessible on-page dialogs with Cancel as initial focus, Escape cancellation, focus return, and account-change cancellation. The actual hosted approval/removal dialogs were visually inspected and exercised. The same dialog pattern now protects live-game end, with fixed game-ID validation; this latter change has local browser coverage but was not separately hosted-session retested after fixture cleanup.21local browser suites plus quiz units pass, including actual cancel/confirm controls.

Exact-created-fixture transaction removed the game, signals/members/answers, class/assignment/member/attempt, parent code/request/link and all three synthetic Auth users. Readback: users3/classes0/games0/attempts0/links0. Fresh Auth page showed exactly the original three users and no synthetic rows. All three memory-only sessions signed out/cleared; all three temporary saved credentials deleted and absence rechecked. Ordinary44-file preview restored, all three access flags false, no test container included, deployed classroom JS/CSS exact-byte checked. Main site, DNS, public signup, AI and payments unchanged.

Engineering still open: production route/login integration QA; a coherent owner acceptance path; incomplete curriculum planning, tutor, reward and screen-time entries; final mobile/accessibility and security review; support/operating documentation. Some named AI/enforcement features cannot honestly be replaced by local manual tools without keeping that distinction visible. Owner decisions before public/minor use: eligible audience and account provisioning; guardian/privacy/retention/support policies. Optional AI provider, merchant/licensing/refund commitments remain separate and should not block a truthful free, non-AI adult pilot.

> Current status, 2026-11-11 00:27 Asia/Dubai: migration005 is installed after exact-source hosted rollback tests. Independent synthetic teacher/learner browser sessions verified classroom publication and server 3/3, realtime game join/start/answer/reveal/next/finish for MCQ/true-false/short answer, hidden player keys/scores during questions, outsider game/signal/private-table isolation, and finished-game reconnect. A channel reuse issue found on actual resume was fixed with unique per-connection names and pagehide cleanup, then retested live. All synthetic fixtures, two Auth users, auth sessions, vault credentials and temporary preview harness removed; baseline3 existing users retained. Ordinary frontend enabled=false/liveEnabled=false. Main site/DNS/payment/signup settings unchanged. Historical source-only sections below describe earlier checkpoints, not current install status. Public release, owner pilot and role/onboarding work remain incomplete.

# BrainJoy platform security gates

Do not enable cloud mode until all gates pass on the existing database.

1. Inventory existing tables, policies, grants and auth settings read-only. Do not replace existing schemas or users.
2. Add new namespaced tables only after reviewing collisions and dependencies.
3. Teachers can read/write only their owned content. Changing a profile or selecting a UI role must never grant teacher/admin authority.
4. Students can see question text and options, never answer keys before submitting. Server-side grading owns scores. Repeated submissions must not duplicate points.
5. Teacher access to attempts requires ownership of the corresponding assignment/class. Parent access requires an explicit verified link, not guessing a student's email or ID.
6. New user profiles cannot set admin roles. Administrative access comes from a separately verified owner grant.
7. No service-role keys in browser code, Git history, previews or logs. Public/publishable keys do not bypass RLS.
8. All generated HTML uses escaped text or textContent. Validate question types, lengths and count on the server as well as client.
9. Test authorization with synthetic fixtures in a transaction that is rolled back. No real-student signups, private record mutation or payment tests.
10. Publish no multiuser claims until two independent authenticated sessions and unauthorized-access negative tests pass.

Money and safety: no payment activation, seller commitments, subscription upgrades or AI quota calls without source-grounded authority. All learning resources must be original or properly licensed. Do not claim NWEA/MAP-equivalent validation or guaranteed learning growth.

## Existing database inventory, Nov 10 2026
- Project restored from paused Free state, data retained.
- Public tables: lesson_plans, profiles, quizzes, arenas, players, all with RLS.
- quizzes: id UUID PK, title/subject/difficulty text, questions JSONB, created_by UUID FK to auth.users(id), created_at timestamptz. Exactly 0 quiz rows at preflight.
- profiles: id UUID, email/full_name/avatar_url/role text, created_at timestamptz. Exactly 0 profile rows; 3 auth users, no private row data read.
- Original quiz policy: all actions to PUBLIC where auth.role()='authenticated', no ownership. Narrowed live to authenticated creator only (001).
- Profiles owner ALL policy checks auth.uid()=id; role column is user-editable. Never trust it for administrative authorization.
- Other 3 public tables have no policies, so RLS should deny normal API access despite broad default grants. Confirm actual API behavior before enabling features.

## Installed classroom milestone, 22:34 Dubai
Migration002 applied after exact-source MD5 verification, schema dry-run and live rollback-only synthetic authorization tests. Eight private RLS tables and checked RPC functions. Direct client table access revoked; anonymous dashboard RPC denied. Parent requests need specific student approval, single-use/expiring codes, rejection/removal. No real-student fixtures retained. Migration003 removed only client TRUNCATE grants, preserving ordinary CRUD and records.

Frontend remains disabled. Independent authenticated teacher/learner session tests passed on synthetic fixtures, then fixtures were removed. Adult pilot and public minor onboarding/consent remain release gates. See QA-20261110.md. Local UI mocks are not authenticated-session evidence. Owner email source evidence recovered from authenticated WhatsApp Nov3 07:35. Fresh unique confirmed match verified and migration004 applied to that owner only; read-back admins=1, verified_owner_admins=1. No profile role is trusted. Existing profile.role is never trusted. Static preview does not enable payment, signup or cloud classrooms.

Source-only migration staging brainjoy_build was verified against both original source-bundle hashes and removed with RESTRICT, not CASCADE, after install.

## Private live games, ordinary access closed
Migration005 is installed and independent synthetic teacher/learner realtime tests passed as described in the current-status block. Uses three private RLS tables, checked authenticated RPCs and a public ID/revision-only signal table guarded by membership/host and expiry RLS. Answer keys and player scoreboard are absent during active questions. Server clock, row locks and unique constraints own deadlines/first submission. No speed bonuses or classroom-grade mutation. Realtime publication must exist or migration rolls back. Emergency disable revokes RPC/signal access and unpublishes signals while retaining data. Network delivery/reconnect have synthetic-session evidence. Abuse controls, owner pilot and ordinary account/minor release gates remain before public use.

## Hosted roster006 installed, 2026-11-11 01:50 Dubai
Supersedes the earlier source-only006 status. Fresh name collision preflight: absent,3existing Auth users,0membership rows. Atomic rollback suite created006 temporarily and proved owner-only class membership and submission IDs, denial for member students/approved parents/outsiders/anonymous/no identity, class isolation and minimal fields. Suite rolled back; separate readback function absent/users3/members0. Installed only additive checked function and execute grants. Exact source accepted by normal keystroke UI input in180char chunks, each prefix verified before continuing; Monaco auto-closing suffixes removed through normal keys then reverified. Final complete input matched source before Run. No unverified/truncated input was executed.

Installed source is whitespace-normalized006; exact prosrc MD5a66b86126a418dd88da5cb009c8b70f9 verified live, security-definer true, anonymous execute false, authenticated execute true; ownership check remains in body. No table/policy/global role-membership or retained record changes. No credentials/Auth signups used in this rollback-only run. Independent authenticated-session roster/pilot integration remains pending. rosterEnabled,enabled,liveEnabled all stay false in ordinary source; no preview/main-site/signup/payment changes this block.
